/**
 * Merge utilities: union-merge 3 tool tiers with priority,
 * plus security tier classification.
 */
import type { Tool, SecurityTier } from '../types';
/**
 * Union-merge tool sets from all 3 discovery tiers.
 * Priority: native > declarative > inferred (by name collision).
 */
export declare function mergeToolSets(nativeTools: readonly Tool[], declarativeTools: readonly Tool[], inferredTools: readonly Tool[]): Tool[];
/**
 * Compute the security tier for a tool based on category and name.
 *
 * Tier 0 (Safe): page-state, media (read ops)
 * Tier 1 (Navigation): navigation, search, schema-org search
 * Tier 2 (Mutation): form, auth, ecommerce, richtext, file-upload, social-action
 */
export declare function getSecurityTier(tool: Tool): SecurityTier;
