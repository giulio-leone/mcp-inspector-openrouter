/**
 * AI Classifier — sends low-confidence tools to an LLM for refined
 * categorisation.  Communicates with the background service worker
 * via chrome.runtime messages (AI_CLASSIFY action).
 */
import type { Tool, AIClassifierPageContext } from '../types';
export declare class AIClassifier {
    private readonly cache;
    /**
     * Classify a batch of ambiguous tools via AI.
     * Returns enhanced tools with AI-refined metadata.
     */
    classifyElements(tools: Tool[], pageContext: AIClassifierPageContext): Promise<Tool[]>;
    private classifyBatch;
    private buildPrompt;
    private parseResponse;
    private cacheKey;
}
