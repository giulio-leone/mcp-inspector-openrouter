/**
 * SPA navigation detection — patches History API and listens for
 * popstate events so the extension re-scans on client-side navigations.
 */
export declare function initSpaDetection(callback: () => void): void;
