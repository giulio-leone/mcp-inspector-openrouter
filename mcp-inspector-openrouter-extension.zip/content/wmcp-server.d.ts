/**
 * WmcpServer — IWmcpServerPort implementation via DOM injection.
 *
 * Exposes the MCP manifest to external tools by:
 * 1. Injecting a <script type="application/wmcp+json" id="wmcp-manifest"> element
 * 2. Listening for CustomEvent('wmcp-request') and responding with
 *    CustomEvent('wmcp-response') containing the manifest JSON
 */
import type { IWmcpServerPort } from '../ports/wmcp-server.port';
export declare class WmcpServer implements IWmcpServerPort {
    private scriptEl;
    private requestListener;
    exposeManifest(json: string): void;
    onRequest(handler: (url: string) => string): void;
    dispose(): void;
}
