import type { IVideoPlayer, PlayerCapabilities, PlayerPlatform, PlayerState } from './types';
export declare abstract class BasePlayer implements IVideoPlayer {
    readonly id: string;
    readonly platform: PlayerPlatform;
    readonly capabilities: PlayerCapabilities;
    abstract readonly anchorElement: Element | null;
    constructor(id: string, platform: PlayerPlatform, capabilities: PlayerCapabilities);
    abstract play(): Promise<void>;
    abstract pause(): Promise<void>;
    abstract seek(time: number): Promise<void>;
    abstract setVolume(level: number): Promise<void>;
    abstract mute(): Promise<void>;
    abstract unmute(): Promise<void>;
    abstract getState(): Promise<PlayerState>;
    nextTrack(): Promise<void>;
    previousTrack(): Promise<void>;
    shuffle(): Promise<void>;
    isAlive(): boolean;
    dispose(): void;
    protected clampVolume(level: number): number;
    protected clampSeek(time: number, duration: number): number;
    protected readElementTitle(el: Element | null): string;
}
