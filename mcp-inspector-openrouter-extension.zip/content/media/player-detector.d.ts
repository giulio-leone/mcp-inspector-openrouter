import type { IVideoPlayer } from './types';
export declare class PlayerDetector {
    detect(root: Document | Element | ShadowRoot): IVideoPlayer[];
    private detectAudioEmbeds;
    private detectVimeo;
    private detectDailymotion;
    private detectTwitch;
    private detectIframeByPredicate;
    private detectYouTube;
    private detectNative;
    private detectCustomPlayers;
    private detectCustomBySelector;
    private queryAll;
    private makeId;
    private slugify;
    private isYouTubeEmbed;
    private isVimeoEmbed;
    private isDailymotionEmbed;
    private isTwitchEmbed;
    private isSpotifyEmbed;
    private isSoundCloudEmbed;
    private isBandcampEmbed;
}
