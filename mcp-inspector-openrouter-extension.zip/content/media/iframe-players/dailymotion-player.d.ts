import { BasePlayer } from '../base-player';
import type { PlayerCapabilities, PlayerState } from '../types';
export declare class DailymotionPlayer extends BasePlayer {
    readonly id: string;
    private readonly iframe;
    readonly platform: "dailymotion";
    readonly capabilities: PlayerCapabilities;
    readonly anchorElement: Element;
    private readonly targetOrigin;
    private readonly snapshot;
    private disposed;
    private lastNonZeroVolume;
    private readonly messageListener;
    constructor(id: string, iframe: HTMLIFrameElement);
    play(): Promise<void>;
    pause(): Promise<void>;
    seek(time: number): Promise<void>;
    setVolume(level: number): Promise<void>;
    mute(): Promise<void>;
    unmute(): Promise<void>;
    getState(): Promise<PlayerState>;
    isAlive(): boolean;
    dispose(): void;
    private postCommand;
    private parsePayload;
    private resolveTargetOrigin;
    private readString;
}
