import type { IVideoPlayer } from './types';
export declare class PlayerRegistry {
    private readonly detector;
    private playersById;
    refresh(root?: Document | Element | ShadowRoot): IVideoPlayer[];
    getById(id: string): IVideoPlayer | null;
    getAll(): IVideoPlayer[];
    dispose(): void;
}
export declare function getPlayerRegistry(): PlayerRegistry;
