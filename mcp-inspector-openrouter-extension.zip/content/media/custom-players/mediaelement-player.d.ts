import { BaseCustomNativePlayer } from './base-custom-native-player';
export declare class MediaElementPlayer extends BaseCustomNativePlayer {
    readonly platform: "mediaelement";
    constructor(id: string, mediaElement: HTMLMediaElement, rootElement: Element);
}
