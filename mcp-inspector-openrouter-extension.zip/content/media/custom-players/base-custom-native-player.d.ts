import { BasePlayer } from '../base-player';
import type { PlayerCapabilities, PlayerPlatform, PlayerState } from '../types';
export declare abstract class BaseCustomNativePlayer extends BasePlayer {
    readonly id: string;
    protected readonly mediaElement: HTMLMediaElement;
    protected readonly rootElement: Element;
    readonly capabilities: PlayerCapabilities;
    protected constructor(id: string, platform: PlayerPlatform, mediaElement: HTMLMediaElement, rootElement: Element);
    get anchorElement(): Element;
    play(): Promise<void>;
    pause(): Promise<void>;
    seek(time: number): Promise<void>;
    setVolume(level: number): Promise<void>;
    mute(): Promise<void>;
    unmute(): Promise<void>;
    getState(): Promise<PlayerState>;
    isAlive(): boolean;
}
