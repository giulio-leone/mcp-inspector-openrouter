import { BaseCustomNativePlayer } from './base-custom-native-player';
export declare class VideoJsPlayer extends BaseCustomNativePlayer {
    readonly platform: "videojs";
    constructor(id: string, mediaElement: HTMLMediaElement, rootElement: Element);
}
