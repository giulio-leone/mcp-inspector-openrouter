import { BaseCustomNativePlayer } from './base-custom-native-player';
export declare class PlyrPlayer extends BaseCustomNativePlayer {
    readonly platform: "plyr";
    constructor(id: string, mediaElement: HTMLMediaElement, rootElement: Element);
}
