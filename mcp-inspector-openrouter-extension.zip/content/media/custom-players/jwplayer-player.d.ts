import { BaseCustomNativePlayer } from './base-custom-native-player';
export declare class JWPlayerAdapter extends BaseCustomNativePlayer {
    readonly platform: "jwplayer";
    constructor(id: string, mediaElement: HTMLMediaElement, rootElement: Element);
}
