import { BasePlayer } from './base-player';
import type { PlayerCapabilities, PlayerState } from './types';
export declare class NativePlayerAdapter extends BasePlayer {
    readonly id: string;
    private readonly mediaElement;
    readonly platform: "native";
    readonly capabilities: PlayerCapabilities;
    constructor(id: string, mediaElement: HTMLMediaElement);
    get anchorElement(): Element;
    play(): Promise<void>;
    pause(): Promise<void>;
    seek(time: number): Promise<void>;
    setVolume(level: number): Promise<void>;
    mute(): Promise<void>;
    unmute(): Promise<void>;
    getState(): Promise<PlayerState>;
    isAlive(): boolean;
}
