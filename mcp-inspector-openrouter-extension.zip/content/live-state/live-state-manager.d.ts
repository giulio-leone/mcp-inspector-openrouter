/**
 * LiveStateManager — singleton orchestrator for live page state collection.
 *
 * Registers IStateProvider instances, collects snapshots on demand,
 * and caches the latest result. Polling is deferred to Phase 3.
 */
import type { IStateProvider, LiveStateCategory, LiveStateSnapshot } from '../../types/live-state.types';
/**
 * Orchestrates live-state collection across all registered providers.
 * Use `getLiveStateManager()` to obtain the singleton instance.
 */
export declare class LiveStateManager {
    private readonly providers;
    private latestSnapshot;
    private running;
    /** Register a provider for a specific live-state category */
    registerProvider(provider: IStateProvider<unknown>): void;
    /** Return the first registered provider matching a given category */
    getProviderByCategory(category: LiveStateCategory): IStateProvider<unknown> | undefined;
    /** Synchronously collect a full snapshot from all registered providers */
    collectSnapshot(root?: Document | Element): LiveStateSnapshot;
    /** Return the most recently collected snapshot, or null if none exists */
    getLatestSnapshot(): LiveStateSnapshot | null;
    /** Mark the manager as running (polling deferred to Phase 3) */
    start(): void;
    /** Stop the manager */
    stop(): void;
    /** Whether the manager is currently running */
    isRunning(): boolean;
    /** Dispose all providers and reset internal state */
    dispose(): void;
}
/** Get (or create) the singleton LiveStateManager instance */
export declare function getLiveStateManager(): LiveStateManager;
