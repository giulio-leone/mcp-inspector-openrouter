/**
 * PollingEngine — adaptive interval-based polling for live-state collection.
 *
 * Uses setInterval (not requestAnimationFrame) since this runs in an
 * extension content script. Switches between idle and active polling
 * rates based on user activity, and triggers immediate (debounced)
 * snapshots on DOM mutations.
 */
import type { LiveStateManagerConfig } from '../../types/live-state.types';
import type { LiveStateManager } from './live-state-manager';
export declare class PollingEngine {
    private readonly manager;
    private readonly config;
    private timerId;
    private mutationObserver;
    private mutationDebounceId;
    private lastActivityTs;
    private running;
    /** Bound handler references for clean removal */
    private readonly onActivity;
    constructor(manager: LiveStateManager, config: LiveStateManagerConfig);
    start(): void;
    stop(): void;
    dispose(): void;
    isRunning(): boolean;
    private scheduleTimer;
    private clearTimer;
    /** Reschedule the timer when switching between idle/active rates */
    private reschedule;
    private isActive;
    /** Single poll tick: refresh async providers then collect a snapshot */
    private tick;
    private addActivityListeners;
    private removeActivityListeners;
    private startMutationObserver;
    private stopMutationObserver;
    private debouncedMutationTick;
    private clearMutationDebounce;
}
