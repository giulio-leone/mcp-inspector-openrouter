/**
 * NavigationStateProvider — collects live state for page navigation.
 *
 * Reports the current URL, scroll position, visible heading section,
 * active ARIA tab, and breadcrumb trail.
 */
import type { IStateProvider, NavigationLiveState } from '../../../types/live-state.types';
export declare class NavigationStateProvider implements IStateProvider<NavigationLiveState> {
    readonly category: "navigation";
    collect(root: Document | Element): NavigationLiveState;
    dispose(): void;
}
