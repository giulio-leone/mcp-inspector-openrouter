/**
 * MediaStateProvider — collects live state for media players on the page.
 *
 * Uses the PlayerRegistry to discover players and caches their async state
 * so that the synchronous collect() contract of IStateProvider is satisfied.
 */
import type { IStateProvider, MediaLiveState } from '../../../types/live-state.types';
export declare class MediaStateProvider implements IStateProvider<MediaLiveState> {
    readonly category: "media";
    private cache;
    collect(_root: Document | Element): MediaLiveState[];
    /**
     * Asynchronously refresh the cache by awaiting getState() on each player.
     * Call this before collectSnapshot() when an up-to-date read is needed.
     */
    refreshAsync(root?: Document | Element): Promise<void>;
    dispose(): void;
}
