/**
 * InteractiveStateProvider — collects live state for interactive UI widgets.
 *
 * Detects open modals, expanded accordions, open dropdowns,
 * active tooltips, and visible notifications.
 */
import type { IStateProvider, InteractiveLiveState } from '../../../types/live-state.types';
export declare class InteractiveStateProvider implements IStateProvider<InteractiveLiveState> {
    readonly category: "interactive";
    collect(root: Document | Element): InteractiveLiveState;
    dispose(): void;
}
