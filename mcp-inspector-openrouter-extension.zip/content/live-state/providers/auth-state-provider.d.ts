/**
 * AuthStateProvider — collects live state for authentication indicators.
 *
 * Uses DOM heuristics to detect login forms, logout controls,
 * and the currently visible user name.
 */
import type { IStateProvider, AuthLiveState } from '../../../types/live-state.types';
export declare class AuthStateProvider implements IStateProvider<AuthLiveState> {
    readonly category: "auth";
    collect(root: Document | Element): AuthLiveState;
    dispose(): void;
}
