/**
 * FormStateProvider — collects live state for forms on the page.
 *
 * Enumerates all <form> elements, counts fields, detects dirty/invalid
 * state, and computes a completion percentage.
 */
import type { IStateProvider, FormLiveState } from '../../../types/live-state.types';
export declare class FormStateProvider implements IStateProvider<FormLiveState> {
    readonly category: "form";
    collect(root: Document | Element): FormLiveState[];
    dispose(): void;
}
