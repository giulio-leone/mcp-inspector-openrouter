/**
 * VisibilityStateProvider — collects live state for DOM visibility context.
 *
 * Detects overlays (cookie banners, popups blocking content) and
 * loading indicators (spinners, skeleton screens).
 */
import type { IStateProvider, VisibilityLiveState } from '../../../types/live-state.types';
export declare class VisibilityStateProvider implements IStateProvider<VisibilityLiveState> {
    readonly category: "visibility";
    collect(root: Document | Element): VisibilityLiveState;
    dispose(): void;
}
