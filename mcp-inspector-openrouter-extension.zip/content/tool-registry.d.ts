/**
 * ToolRegistry — owns scanner/executor registries, 3-tier tool
 * discovery, schema enrichment, DOM observation, and result caching.
 *
 * Supports an optional IToolCachePort for persistent cross-session
 * caching of tool manifests per site (WebMCP cache layer).
 */
import type { Tool, CleanTool } from '../types';
import { ExecutorRegistry } from './executors';
import type { IToolCachePort } from '../ports/tool-cache.port';
import type { IToolManifestPort } from '../ports/tool-manifest.port';
import type { IManifestPersistencePort } from '../ports/manifest-persistence.port';
export declare class ToolRegistry {
    private scannerRegistry;
    readonly executorRegistry: ExecutorRegistry;
    private aiClassifier;
    /** Inferred tools keyed by name — used for execution routing */
    readonly inferredToolsMap: Map<string, Tool>;
    private domObserver;
    private domObserverDebounce;
    private scannerCacheTime;
    private scannerCacheResult;
    /** Optional persistent tool cache (IndexedDB) */
    private toolCache;
    /** Optional tool manifest for MCP JSON export */
    private toolManifest;
    /** Track if a background diff is already running to avoid duplicates */
    private diffInProgress;
    /** Callback invoked after manifest updates */
    private manifestUpdateCallback;
    /** Optional persistent manifest storage (IndexedDB) */
    private manifestPersistence;
    constructor();
    /** Inject a persistent tool cache adapter. */
    setToolCache(cache: IToolCachePort): void;
    /** Inject a tool manifest adapter. */
    setToolManifest(manifest: IToolManifestPort): void;
    /** Inject a manifest persistence adapter. */
    setManifestPersistence(persistence: IManifestPersistencePort): void;
    /** Get the tool manifest port (for message handler access). */
    getToolManifest(): IToolManifestPort | null;
    /** Register a callback invoked after each manifest update. */
    onManifestUpdate(callback: () => void): void;
    /**
     * Load persisted manifest into the in-memory adapter on startup.
     * Call after setToolManifest and setManifestPersistence.
     */
    loadPersistedManifest(): Promise<void>;
    /** Update manifest and persist in background. */
    private updateManifestAndPersist;
    invalidateCache(): void;
    listToolsAlwaysAugment(): Promise<CleanTool[]>;
    /**
     * Schedules a background diff: scans DOM and compares with cached tools.
     * If differences found, updates the cache and broadcasts updated tools.
     */
    private scheduleBackgroundDiff;
    /** Run full 3-tier scan and return clean tools (no caching side effects). */
    private fullScan;
    startDomObserver(): void;
    stopDomObserver(): void;
    normalizeToolArgs(toolName: string, inputArgs: string | Record<string, unknown>): string;
    private enrichToolSchemas;
    private static extractFormSchema;
}
