/**
 * Page context extraction — collects structured information about the
 * current page for the sidebar / AI layer.
 */
import type { PageContext } from '../types';
export declare function extractPageContext(): PageContext;
