/**
 * Interactive Scanner — discovers buttons, tabs, toggles, dropdowns.
 * Runs AFTER social-action, richtext, and file-upload scanners so that
 * _claimedElements dedup prevents double-counting.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class InteractiveScanner extends BaseScanner {
    readonly category: "interactive";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
