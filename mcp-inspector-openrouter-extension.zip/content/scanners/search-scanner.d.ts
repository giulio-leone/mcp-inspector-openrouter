/**
 * Search Scanner — discovers search inputs (type="search", role="search", etc.).
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class SearchScanner extends BaseScanner {
    readonly category: "search";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
