/**
 * Schema.org Scanner — discovers potentialAction entries in JSON-LD.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class SchemaOrgScanner extends BaseScanner {
    readonly category: "schema-org";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
