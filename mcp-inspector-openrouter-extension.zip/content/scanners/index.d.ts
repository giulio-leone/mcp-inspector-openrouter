/**
 * Scanner Registry — registers all 13 category scanners, runs them
 * in priority order, deduplicates results, and supports cache invalidation.
 */
import type { Tool, ToolCategory } from '../../types';
import { BaseScanner } from './base-scanner';
export { BaseScanner, collectShadowRoots } from './base-scanner';
export { claimElement, isElementClaimed, isSocialKeyword } from './base-scanner';
export declare class ScannerRegistry {
    private readonly scanners;
    constructor();
    /**
     * Run all 13 scanners on a root node (+ open Shadow DOM roots).
     * Deduplicates by tool name, keeping the highest-confidence entry.
     */
    scanAll(root?: Document | Element | ShadowRoot): Tool[];
    /** Get a specific scanner by category */
    getScanner(category: ToolCategory): BaseScanner | undefined;
}
