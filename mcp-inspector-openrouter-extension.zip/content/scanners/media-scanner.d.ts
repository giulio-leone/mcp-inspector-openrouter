/**
 * Media Scanner — unified semantic media tool discovery.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class MediaScanner extends BaseScanner {
    readonly category: "media";
    scan(root: Document | Element | ShadowRoot): Tool[];
    private createMediaTool;
    private getPlayerLabel;
    private getActionSchema;
    private getActionAnnotations;
    private getActionText;
    private supportsAction;
    /** Return a live-state hint suffix for the tool description, or empty string. */
    private getLiveStateHint;
    private fmtTimeSec;
}
