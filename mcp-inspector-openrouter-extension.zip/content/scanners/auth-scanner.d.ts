/**
 * Auth Scanner — discovers login forms (password inputs) and logout links/buttons.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class AuthScanner extends BaseScanner {
    readonly category: "auth";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
