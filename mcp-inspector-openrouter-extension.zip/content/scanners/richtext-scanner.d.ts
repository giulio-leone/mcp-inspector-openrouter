/**
 * Rich Text Scanner — discovers contenteditable surfaces, WYSIWYG editors,
 * social media post composers, and role="textbox" outside <form>.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class RichTextScanner extends BaseScanner {
    readonly category: "richtext";
    scan(root: Document | Element | ShadowRoot): Tool[];
    private isEditableSurface;
    private isLikelyEditorTrigger;
    private buildSemanticText;
}
