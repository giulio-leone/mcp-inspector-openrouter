/**
 * E-commerce Scanner — discovers add-to-cart buttons and quantity inputs.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class EcommerceScanner extends BaseScanner {
    readonly category: "ecommerce";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
