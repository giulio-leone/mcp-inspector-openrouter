/**
 * Navigation Scanner — discovers ALL clickable links on the page as navigation tools.
 * Groups links by semantic page section (header, nav, main, sidebar, footer, etc.).
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class NavigationScanner extends BaseScanner {
    readonly category: "navigation";
    protected readonly maxTools = 200;
    scan(root: Document | Element | ShadowRoot): Tool[];
    /** Detect the semantic section a link belongs to */
    private detectSection;
}
