/**
 * Social Action Scanner — discovers social media actions across platforms
 * (Facebook, Instagram, WhatsApp, X, LinkedIn, Threads, etc.).
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class SocialScanner extends BaseScanner {
    readonly category: "social-action";
    scan(root: Document | Element | ShadowRoot): Tool[];
    /** Classify a candidate element into a social action type */
    private classify;
    private socialAnnotations;
    private detectPlatform;
    private resolveTestId;
}
