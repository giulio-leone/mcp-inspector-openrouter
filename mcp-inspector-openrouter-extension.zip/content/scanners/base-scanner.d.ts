/**
 * Abstract base class for all DOM scanners.
 * Provides shared helpers: confidence scoring, MCP-compliant naming,
 * visibility checks, label extraction, and element deduplication.
 */
import type { Tool, ToolCategory, ToolInputSchema, ToolAnnotations, ToolParameter, ConfidenceSignals } from '../../types';
/** Claim an element so no other scanner can emit it */
export declare function claimElement(el: Element): void;
/** Check whether an element has already been claimed */
export declare function isElementClaimed(el: Element): boolean;
/** Test if a label indicates a social action (like, share, follow, comment) */
export declare function isSocialKeyword(label: string): boolean;
/** Recursively collect open Shadow DOM roots from a root element */
export declare function collectShadowRoots(root: Document | Element | ShadowRoot, maxDepth?: number): ShadowRoot[];
export declare abstract class BaseScanner {
    abstract readonly category: ToolCategory;
    /** Scan a root node and return discovered tools */
    abstract scan(root: Document | Element | ShadowRoot): Tool[];
    /** Per-category cap */
    protected readonly maxTools: number;
    /** Compute a confidence score from discrete signals */
    protected computeConfidence(signals: ConfidenceSignals): number;
    /** Build a Tool object with MCP-compliant naming */
    protected createTool(name: string, description: string, el: Element | null, schema: ToolInputSchema, confidence: number, opts?: {
        title?: string;
        annotations?: ToolAnnotations;
        form?: HTMLFormElement | null;
        schemaAction?: Record<string, unknown>;
    }): Tool;
    /** Slugify text for MCP-compliant tool name segments */
    protected slugify(text: string): string;
    /** Check if an element is visible in the viewport */
    protected isVisible(el: Element): boolean;
    /** Check if an element has meaningful size (skips tiny/hidden utility buttons) */
    protected hasMeaningfulSize(el: Element, minW?: number, minH?: number): boolean;
    /** Extract a human-readable label from an element */
    protected getLabel(el: Element): string;
    /** Build an MCP-compliant inputSchema from a list of parameters */
    protected makeInputSchema(fields: ToolParameter[]): ToolInputSchema;
    /** Build MCP-compliant annotations */
    protected makeAnnotations(hints?: {
        readOnly?: boolean;
        destructive?: boolean;
        idempotent?: boolean;
        openWorld?: boolean;
    }): ToolAnnotations;
    /** Claim an element for cross-scanner dedup */
    protected claim(el: Element): void;
    /** Check if an element has already been claimed */
    protected isClaimed(el: Element): boolean;
}
