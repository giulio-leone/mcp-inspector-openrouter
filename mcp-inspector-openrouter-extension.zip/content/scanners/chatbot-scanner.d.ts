/**
 * Chatbot Scanner — discovers AI chatbot input fields (ChatGPT, Claude, Gemini, Grok, etc.)
 * and their associated send buttons.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class ChatbotScanner extends BaseScanner {
    readonly category: "chatbot";
    scan(root: Document | Element | ShadowRoot): Tool[];
    /** Derive a human-friendly site name from the hostname */
    private getSiteName;
    /** Find the send button closest to a chatbot input */
    private findSendButton;
}
