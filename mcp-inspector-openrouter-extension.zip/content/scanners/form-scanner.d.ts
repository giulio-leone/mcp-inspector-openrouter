/**
 * Form Scanner — discovers non-WMCP-native forms and their fields.
 * Only infers from forms that don't already have a `toolname` attribute.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class FormScanner extends BaseScanner {
    readonly category: "form";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
