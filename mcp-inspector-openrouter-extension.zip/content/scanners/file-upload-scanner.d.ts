/**
 * File Upload Scanner — discovers file inputs and drag-drop zones.
 * Does NOT use overbroad aria-label selectors (foto/photo/image)
 * which falsely matched profile images and photo buttons.
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class FileUploadScanner extends BaseScanner {
    readonly category: "file-upload";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
