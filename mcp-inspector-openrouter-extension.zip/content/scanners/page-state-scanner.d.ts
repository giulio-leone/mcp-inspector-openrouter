/**
 * Page State Scanner — discovers scroll, print, theme toggle controls.
 * Always emits scroll-to-top and scroll-to-bottom (virtual tools).
 */
import type { Tool } from '../../types';
import { BaseScanner } from './base-scanner';
export declare class PageStateScanner extends BaseScanner {
    readonly category: "page-state";
    scan(root: Document | Element | ShadowRoot): Tool[];
}
