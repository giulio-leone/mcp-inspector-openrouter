/**
 * Content script entry — thin orchestrator.
 *
 * Wires together ToolRegistry, message handling, SPA detection,
 * custom page events, and the LiveState polling engine.
 */
export {};
