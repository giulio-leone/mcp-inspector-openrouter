/**
 * Message handler — chrome.runtime.onMessage dispatcher for the
 * content script. Owns YOLO-mode cache and pending confirmations.
 */
import type { ToolRegistry } from './tool-registry';
export declare function createMessageHandler(registry: ToolRegistry): void;
