/**
 * Social-action executor: like, share, follow, comment clicks.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class SocialExecutor extends BaseExecutor {
    readonly category: "social-action";
    execute(tool: Tool): Promise<ExecutionResult>;
    private parseAction;
}
