/**
 * E-commerce executor: add-to-cart, set quantity, checkout clicks.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class EcommerceExecutor extends BaseExecutor {
    readonly category: "ecommerce";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
}
