/**
 * Media executor: unified media command execution through player adapters.
 *
 * Performs live-state pre-checks before executing actions to avoid
 * redundant operations (e.g. playing an already-playing video).
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class MediaExecutor extends BaseExecutor {
    readonly category: "media";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    /** Retrieve cached live state for a specific player */
    private getMediaLiveState;
    /**
     * Pre-check: return an early result if the action is redundant.
     * Returns `null` when the action should proceed normally.
     */
    private preCheckAction;
    private parseTool;
    private parseLegacyToolName;
    private resolvePlayer;
    private executeAction;
    private toFiniteNumber;
    private extractTranscript;
    private wait;
    private fmtTimeSec;
}
