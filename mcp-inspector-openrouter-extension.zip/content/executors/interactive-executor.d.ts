/**
 * Interactive executor: button clicks, toggles, tab switches, combobox selection.
 *
 * Uses live state to provide informative response messages about
 * the resulting state of interactive elements.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class InteractiveExecutor extends BaseExecutor {
    readonly category: "interactive";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    /** Enrich click responses with current interactive state context */
    private buildClickMessage;
}
