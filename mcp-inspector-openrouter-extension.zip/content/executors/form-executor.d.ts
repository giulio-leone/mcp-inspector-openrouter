/**
 * Form executor: fills fields, handles select/checkbox/radio, submits.
 *
 * Supports two tool prefixes:
 * - `form.submit-*` — fills all fields of a <form> and submits
 * - `form.fill-*`   — fills a single standalone input field
 *
 * Uses native value setter for React/Vue compatibility.
 * Submits via submit button click > form.submit() > submit event.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class FormExecutor extends BaseExecutor {
    readonly category: "form";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    /** Set the value of a single form field with React/Vue-compatible native setters. */
    private setFieldValue;
    private toBoolean;
}
