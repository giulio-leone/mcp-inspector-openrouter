/**
 * Executor registry: maps tool categories to their executor instances.
 */
import type { Tool, ToolCategory } from '../../types';
import { type ExecutionResult } from './base-executor';
import type { BaseExecutor } from './base-executor';
export { type ExecutionResult } from './base-executor';
export { BaseExecutor } from './base-executor';
export declare class ExecutorRegistry {
    private executors;
    constructor();
    /** Execute a tool using the matching category executor */
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    /** Get the executor for a specific category */
    getExecutor(category: ToolCategory): BaseExecutor | undefined;
}
