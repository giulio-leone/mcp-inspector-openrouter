/**
 * Navigation executor: clicks links, navigates to URLs.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class NavigationExecutor extends BaseExecutor {
    readonly category: "navigation";
    execute(tool: Tool): Promise<ExecutionResult>;
}
