/**
 * File-upload executor: triggers file input click or drop zone click.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class FileUploadExecutor extends BaseExecutor {
    readonly category: "file-upload";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
}
