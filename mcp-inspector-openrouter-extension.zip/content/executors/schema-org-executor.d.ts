/**
 * Schema.org executor: resolves action URL template and navigates.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class SchemaOrgExecutor extends BaseExecutor {
    readonly category: "schema-org";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
}
