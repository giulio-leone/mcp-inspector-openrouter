/**
 * Page-state executor: scroll (absolute & incremental), theme toggle, back-to-top.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class PageStateExecutor extends BaseExecutor {
    readonly category: "page-state";
    execute(tool: Tool): Promise<ExecutionResult>;
}
