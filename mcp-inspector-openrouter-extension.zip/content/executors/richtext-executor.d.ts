/**
 * Rich-text executor: Quill, Draft.js, ProseMirror, generic contenteditable.
 * Uses paste simulation for React-based editors to keep internal state in sync.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class RichTextExecutor extends BaseExecutor {
    readonly category: "richtext";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    /** Resolve or activate the editable element */
    private resolveEditor;
    /** Quill: build <p> elements directly (Quill's MutationObserver syncs) */
    private insertQuill;
    /** Paste simulation for Draft.js, ProseMirror, Slate, etc. */
    private insertPaste;
    /** Last-resort fallback: innerHTML with <p> tags */
    private fallbackInsert;
    private delay;
}
