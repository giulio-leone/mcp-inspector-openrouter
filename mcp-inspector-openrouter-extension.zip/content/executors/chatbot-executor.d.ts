/**
 * Chatbot executor: types prompts into AI chatbot inputs and clicks send buttons.
 *
 * Handles both contenteditable divs (Claude, Gemini) and textareas (ChatGPT, Grok)
 * using framework-compatible value setting.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class ChatbotExecutor extends BaseExecutor {
    readonly category: "chatbot";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
    private typePrompt;
    private sendMessage;
}
