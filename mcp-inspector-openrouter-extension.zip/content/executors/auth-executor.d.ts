/**
 * Auth executor: login form fill + submit, logout click.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class AuthExecutor extends BaseExecutor {
    readonly category: "auth";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
}
