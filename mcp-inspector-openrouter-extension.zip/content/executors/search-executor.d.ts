/**
 * Search executor: fills search input, submits form or simulates Enter.
 *
 * Uses the native InputEvent setter to bypass React/framework value traps,
 * then submits via form.submit() (bypasses JS handlers that may preventDefault),
 * with fallback to submit button click, then form submit event, then Enter key.
 */
import type { Tool } from '../../types';
import { BaseExecutor, type ExecutionResult } from './base-executor';
export declare class SearchExecutor extends BaseExecutor {
    readonly category: "search";
    execute(tool: Tool, args: Record<string, unknown>): Promise<ExecutionResult>;
}
