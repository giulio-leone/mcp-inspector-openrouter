/**
 * IInstagramPort — contract for Instagram platform interactions.
 * Provides methods for stories, feed, reels, DMs, profile, and navigation.
 */
export type InstagramSection = 'feed' | 'stories' | 'reels' | 'profile' | 'explore' | 'dm' | 'unknown';
export interface IInstagramPort {
    viewStory(username: string): Promise<void>;
    nextStory(): Promise<void>;
    previousStory(): Promise<void>;
    replyToStory(message: string): Promise<void>;
    likePost(): Promise<void>;
    unlikePost(): Promise<void>;
    savePost(): Promise<void>;
    unsavePost(): Promise<void>;
    commentOnPost(text: string): Promise<void>;
    sharePost(username: string): Promise<void>;
    scrollFeed(direction: 'up' | 'down'): Promise<void>;
    likeReel(): Promise<void>;
    commentOnReel(text: string): Promise<void>;
    nextReel(): Promise<void>;
    shareReel(username: string): Promise<void>;
    swipeToNextReel(): Promise<void>;
    swipeToPreviousReel(): Promise<void>;
    scrollReels(count?: number): Promise<void>;
    swipeNextStory(): Promise<void>;
    swipePreviousStory(): Promise<void>;
    openCommentComposer(): Promise<void>;
    replyToComment(text: string): Promise<void>;
    loadMoreComments(): Promise<void>;
    sendDM(username: string, message: string): Promise<void>;
    openConversation(username: string): Promise<void>;
    followUser(username: string): Promise<void>;
    unfollowUser(username: string): Promise<void>;
    goToExplore(): Promise<void>;
    goToReels(): Promise<void>;
    goToProfile(username?: string): Promise<void>;
    searchUser(query: string): Promise<void>;
    isOnInstagram(): boolean;
    getCurrentSection(): InstagramSection;
}
