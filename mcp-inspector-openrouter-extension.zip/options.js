/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/services/adapters/chrome-messenger.adapter.ts":
/*!***********************************************************!*\
  !*** ./src/services/adapters/chrome-messenger.adapter.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChromeMessengerAdapter: () => (/* binding */ ChromeMessengerAdapter)
/* harmony export */ });
/**
 * Chrome Messenger adapter — implements IMessenger using chrome.runtime / chrome.tabs.
 */
class ChromeMessengerAdapter {
    async sendToBackground(message) {
        return chrome.runtime.sendMessage(message);
    }
    async sendToTab(tabId, message) {
        return chrome.tabs.sendMessage(tabId, message);
    }
    onMessage(handler) {
        chrome.runtime.onMessage.addListener((message, sender, _sendResponse) => {
            handler(message, sender);
        });
    }
}


/***/ }),

/***/ "./src/services/adapters/chrome-storage.adapter.ts":
/*!*********************************************************!*\
  !*** ./src/services/adapters/chrome-storage.adapter.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChromeStorageAdapter: () => (/* binding */ ChromeStorageAdapter)
/* harmony export */ });
/**
 * Chrome Storage adapter — implements IStorage using chrome.storage.local.
 */
class ChromeStorageAdapter {
    async get(key) {
        const result = await chrome.storage.local.get(key);
        return result[key] ?? null;
    }
    async set(key, value) {
        await chrome.storage.local.set({ [key]: value });
    }
    async remove(key) {
        await chrome.storage.local.remove(key);
    }
}


/***/ }),

/***/ "./src/services/adapters/index.ts":
/*!****************************************!*\
  !*** ./src/services/adapters/index.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthenticationError: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.AuthenticationError),
/* harmony export */   ChromeMessengerAdapter: () => (/* reexport safe */ _chrome_messenger_adapter__WEBPACK_IMPORTED_MODULE_2__.ChromeMessengerAdapter),
/* harmony export */   ChromeStorageAdapter: () => (/* reexport safe */ _chrome_storage_adapter__WEBPACK_IMPORTED_MODULE_1__.ChromeStorageAdapter),
/* harmony export */   ModelError: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.ModelError),
/* harmony export */   OpenRouterAdapter: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.OpenRouterAdapter),
/* harmony export */   OpenRouterChat: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.OpenRouterChat),
/* harmony export */   OpenRouterError: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.OpenRouterError),
/* harmony export */   RateLimitError: () => (/* reexport safe */ _openrouter__WEBPACK_IMPORTED_MODULE_0__.RateLimitError)
/* harmony export */ });
/* harmony import */ var _openrouter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./openrouter */ "./src/services/adapters/openrouter/index.ts");
/* harmony import */ var _chrome_storage_adapter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chrome-storage.adapter */ "./src/services/adapters/chrome-storage.adapter.ts");
/* harmony import */ var _chrome_messenger_adapter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chrome-messenger.adapter */ "./src/services/adapters/chrome-messenger.adapter.ts");
/**
 * Re-export all adapters.
 */





/***/ }),

/***/ "./src/services/adapters/openrouter/adapter.ts":
/*!*****************************************************!*\
  !*** ./src/services/adapters/openrouter/adapter.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OpenRouterAdapter: () => (/* binding */ OpenRouterAdapter)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api-client */ "./src/services/adapters/openrouter/api-client.ts");
/**
 * OpenRouter AI provider adapter — implements IAIProvider.
 */


class OpenRouterAdapter {
    apiKey;
    model;
    constructor(config) {
        this.apiKey = config.apiKey;
        this.model = config.model ?? _utils_constants__WEBPACK_IMPORTED_MODULE_0__.DEFAULT_MODEL;
    }
    async sendMessage(messages, tools) {
        const body = {
            model: this.model,
            messages,
        };
        if (tools && tools.length > 0) {
            body.tools = (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.formatToolDeclarations)(tools);
        }
        const res = await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.fetchWithBackoff)(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_CHAT_ENDPOINT, {
            method: 'POST',
            headers: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.buildHeaders)(this.apiKey),
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.throwApiError)(res);
        }
        return (await res.json());
    }
    async listModels() {
        const res = await fetch(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_MODELS_ENDPOINT, {
            headers: { Authorization: `Bearer ${this.apiKey}` },
        });
        if (!res.ok) {
            await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.throwApiError)(res);
        }
        const data = (await res.json());
        return data.data;
    }
}


/***/ }),

/***/ "./src/services/adapters/openrouter/api-client.ts":
/*!********************************************************!*\
  !*** ./src/services/adapters/openrouter/api-client.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_MAX_INPUT_TOKENS: () => (/* binding */ DEFAULT_MAX_INPUT_TOKENS),
/* harmony export */   DEFAULT_MAX_TOKENS: () => (/* binding */ DEFAULT_MAX_TOKENS),
/* harmony export */   DEFAULT_TEMPERATURE: () => (/* binding */ DEFAULT_TEMPERATURE),
/* harmony export */   MAX_HISTORY_MESSAGES: () => (/* binding */ MAX_HISTORY_MESSAGES),
/* harmony export */   buildHeaders: () => (/* binding */ buildHeaders),
/* harmony export */   delay: () => (/* binding */ delay),
/* harmony export */   fetchWithBackoff: () => (/* binding */ fetchWithBackoff),
/* harmony export */   formatFunctionDeclarations: () => (/* binding */ formatFunctionDeclarations),
/* harmony export */   formatToolDeclarations: () => (/* binding */ formatToolDeclarations),
/* harmony export */   safeParseArguments: () => (/* binding */ safeParseArguments),
/* harmony export */   throwApiError: () => (/* binding */ throwApiError)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./src/services/adapters/openrouter/errors.ts");


// ── Constants ──
const DEFAULT_TEMPERATURE = 0.7;
const DEFAULT_MAX_TOKENS = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS;
const DEFAULT_MAX_INPUT_TOKENS = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_DEFAULT_MAX_INPUT_TOKENS;
const MAX_HISTORY_MESSAGES = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_MAX_HISTORY_MESSAGES;
const RATE_LIMIT_BASE_DELAY_MS = 1000;
const RATE_LIMIT_MAX_RETRIES = 3;
// ── Helpers ──
function buildHeaders(apiKey) {
    return {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': _utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_REFERER,
        'X-Title': _utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_TITLE,
    };
}
function formatToolDeclarations(tools) {
    return tools.map((t) => ({
        type: 'function',
        function: {
            name: t.name,
            description: t.description,
            parameters: typeof t.inputSchema === 'string'
                ? JSON.parse(t.inputSchema)
                : t.inputSchema,
        },
    }));
}
function formatFunctionDeclarations(decls) {
    return decls.map((t) => ({
        type: 'function',
        function: {
            name: t.name,
            description: t.description,
            parameters: t.parametersJsonSchema,
        },
    }));
}
/** Parse a raw API error body and throw a typed error */
async function throwApiError(res) {
    let body;
    try {
        body = (await res.json());
    }
    catch {
        // If JSON parsing fails, fall through to generic error
    }
    const message = body?.error?.message ?? res.statusText;
    if (res.status === 429) {
        const retryAfter = res.headers.get('retry-after');
        const retryMs = retryAfter ? parseInt(retryAfter, 10) * 1000 : undefined;
        throw new _errors__WEBPACK_IMPORTED_MODULE_1__.RateLimitError(message, retryMs);
    }
    if (res.status === 401 || res.status === 403) {
        throw new _errors__WEBPACK_IMPORTED_MODULE_1__.AuthenticationError(message, res.status);
    }
    const errorType = body?.error?.type ?? '';
    if (res.status === 400 ||
        errorType.includes('model') ||
        errorType.includes('context')) {
        throw new _errors__WEBPACK_IMPORTED_MODULE_1__.ModelError(message, res.status);
    }
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.OpenRouterError(message, res.status);
}
/** Safe JSON.parse for tool call arguments; returns empty object on failure */
function safeParseArguments(raw, toolCallId, fnName) {
    if (!raw || raw.trim() === '') {
        console.warn(`[OpenRouter] Tool call ${toolCallId} (${fnName}) has empty arguments, defaulting to {}`);
        return {};
    }
    try {
        return JSON.parse(raw);
    }
    catch (e) {
        console.error(`[OpenRouter] Failed to parse arguments for tool call ${toolCallId} (${fnName}):`, raw, e);
        return {};
    }
}
function delay(ms) {
    return new Promise((r) => setTimeout(r, ms));
}
/** Execute a fetch with exponential backoff on rate-limit errors */
async function fetchWithBackoff(url, init) {
    for (let attempt = 0; attempt < RATE_LIMIT_MAX_RETRIES; attempt++) {
        const res = await fetch(url, init);
        if (res.status !== 429)
            return res;
        const retryAfter = res.headers.get('retry-after');
        const waitMs = retryAfter
            ? parseInt(retryAfter, 10) * 1000
            : RATE_LIMIT_BASE_DELAY_MS * Math.pow(2, attempt);
        console.warn(`[OpenRouter] Rate limited (429), retrying in ${waitMs}ms (attempt ${attempt + 1}/${RATE_LIMIT_MAX_RETRIES})`);
        if (attempt === RATE_LIMIT_MAX_RETRIES - 1)
            return res;
        await delay(waitMs);
    }
    // Should not reach here, but return last attempt
    return fetch(url, init);
}


/***/ }),

/***/ "./src/services/adapters/openrouter/client.ts":
/*!****************************************************!*\
  !*** ./src/services/adapters/openrouter/client.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OpenRouterChat: () => (/* binding */ OpenRouterChat)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api-client */ "./src/services/adapters/openrouter/api-client.ts");
/* harmony import */ var _streaming__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./streaming */ "./src/services/adapters/openrouter/streaming.ts");
/**
 * OpenRouterChat — stateful chat with history and streaming support.
 */



const TOKEN_ESTIMATE_CHARS_PER_TOKEN = 4;
const RETRY_HISTORY_TARGET = 40;
function estimateContentTokens(content) {
    if (typeof content === 'string') {
        return Math.ceil(content.length / TOKEN_ESTIMATE_CHARS_PER_TOKEN);
    }
    let chars = 0;
    for (const part of content) {
        if (part.type === 'text') {
            chars += part.text.length;
        }
        else if (part.type === 'image_url') {
            chars += part.image_url.url.length;
        }
    }
    return Math.ceil(chars / TOKEN_ESTIMATE_CHARS_PER_TOKEN);
}
function estimateMessageTokens(message) {
    let tokens = estimateContentTokens(message.content);
    if (message.tool_calls?.length) {
        for (const toolCall of message.tool_calls) {
            tokens += Math.ceil((toolCall.function.name.length + toolCall.function.arguments.length) /
                TOKEN_ESTIMATE_CHARS_PER_TOKEN);
        }
    }
    if (message.tool_call_id) {
        tokens += Math.ceil(message.tool_call_id.length / TOKEN_ESTIMATE_CHARS_PER_TOKEN);
    }
    return Math.max(tokens, 1);
}
class OpenRouterChat {
    apiKey;
    model;
    history;
    constructor(apiKey, model) {
        this.apiKey = apiKey;
        this.model = model;
        this.history = [];
    }
    /**
     * Trim history to keep the last N user/assistant/tool messages,
     * preventing unbounded token growth.
     */
    trimHistory(maxMessages = _api_client__WEBPACK_IMPORTED_MODULE_1__.MAX_HISTORY_MESSAGES) {
        if (this.history.length <= maxMessages)
            return;
        const trimmed = this.history.length - maxMessages;
        this.history = this.history.slice(-maxMessages);
        console.debug(`[OpenRouter] Trimmed ${trimmed} messages from history, keeping last ${maxMessages}`);
    }
    trimHistoryByInputBudget(maxInputTokens) {
        const targetBudget = Math.max(1, Math.floor(maxInputTokens));
        if (this.history.length === 0)
            return;
        let total = this.history.reduce((sum, msg) => sum + estimateMessageTokens(msg), 0);
        let removed = 0;
        while (this.history.length > 1 && total > targetBudget) {
            const dropped = this.history.shift();
            if (!dropped)
                break;
            total -= estimateMessageTokens(dropped);
            removed += 1;
        }
        if (removed > 0) {
            console.debug(`[OpenRouter] Trimmed ${removed} messages to respect input budget ~${targetBudget} tokens`);
        }
    }
    resolveMaxInputTokens(config) {
        const raw = config?.maxInputTokens;
        if (typeof raw !== 'number' || !Number.isFinite(raw) || raw <= 0) {
            return _api_client__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MAX_INPUT_TOKENS;
        }
        return Math.max(1, Math.floor(raw));
    }
    /** Append user or tool messages to history based on message type */
    appendIncomingMessages(message) {
        if (typeof message === 'string') {
            this.history.push({ role: 'user', content: message });
        }
        else if (Array.isArray(message) && message.length > 0 && 'type' in message[0]) {
            this.history.push({ role: 'user', content: message });
        }
        else if (Array.isArray(message)) {
            for (const m of message) {
                if (m.functionResponse) {
                    this.history.push({
                        role: 'tool',
                        tool_call_id: m.functionResponse.tool_call_id,
                        content: JSON.stringify(m.functionResponse.response.result ??
                            m.functionResponse.response.error),
                    });
                }
            }
        }
    }
    /** Build the request body for the API call */
    buildRequestBody(config, stream = false) {
        const systemMessage = config?.systemInstruction
            ? { role: 'system', content: config.systemInstruction.join('\n') }
            : null;
        const functionDecls = config?.tools?.[0]?.functionDeclarations ?? [];
        const body = {
            model: this.model,
            messages: systemMessage
                ? [systemMessage, ...this.history]
                : this.history,
            temperature: config?.temperature ?? _api_client__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_TEMPERATURE,
            max_tokens: config?.maxTokens ?? _api_client__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MAX_TOKENS,
        };
        if (stream) {
            body.stream = true;
        }
        if (functionDecls.length > 0) {
            body.tools = (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.formatFunctionDeclarations)(functionDecls);
        }
        return body;
    }
    async sendMessage(params) {
        const { message, config } = params;
        const maxInputTokens = this.resolveMaxInputTokens(config);
        this.appendIncomingMessages(message);
        this.trimHistory(_api_client__WEBPACK_IMPORTED_MODULE_1__.MAX_HISTORY_MESSAGES);
        this.trimHistoryByInputBudget(maxInputTokens);
        const body = this.buildRequestBody(config);
        console.debug(`[OpenRouter] Request: model=${this.model}, messages=${body.messages.length}, tools=${(config?.tools?.[0]?.functionDeclarations ?? []).length}`);
        // Retry logic for empty responses
        let data;
        for (let attempt = 0; attempt < _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_MAX_RETRIES; attempt++) {
            const res = await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.fetchWithBackoff)(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_CHAT_ENDPOINT, {
                method: 'POST',
                headers: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.buildHeaders)(this.apiKey),
                body: JSON.stringify(body),
            });
            if (!res.ok) {
                await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.throwApiError)(res);
            }
            data = (await res.json());
            if (data.choices &&
                data.choices.length > 0 &&
                data.choices[0].message) {
                break;
            }
            console.warn(`[OpenRouter] Empty response on attempt ${attempt + 1}/${_utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_MAX_RETRIES}, retrying...`);
            if (attempt < _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_MAX_RETRIES - 1) {
                await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.delay)(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_RETRY_DELAY_MS);
            }
        }
        if (!data?.choices?.length || !data.choices[0].message) {
            throw new Error('OpenRouter returned no response after multiple attempts.');
        }
        // Log token usage when available
        if (data.usage) {
            console.debug(`[OpenRouter] Usage: prompt=${data.usage.prompt_tokens}, completion=${data.usage.completion_tokens}, total=${data.usage.total_tokens}`);
        }
        const assistantMessage = data.choices[0].message;
        // Ensure content is never null in stored history
        const historyEntry = {
            ...assistantMessage,
            content: assistantMessage.content ?? '',
        };
        this.history.push(historyEntry);
        // Parse function calls with safe argument parsing
        const functionCalls = assistantMessage.tool_calls?.map((tc) => ({
            name: tc.function.name,
            args: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.safeParseArguments)(tc.function.arguments, tc.id, tc.function.name),
            id: tc.id,
        }));
        // Merge text and tool_calls: some models return both
        const textContent = typeof assistantMessage.content === 'string'
            ? assistantMessage.content
            : '';
        const reasoning = typeof assistantMessage.reasoning === 'string'
            ? assistantMessage.reasoning
            : '';
        const finishReason = data.choices[0].finish_reason;
        if (finishReason === 'length' && !textContent && reasoning) {
            console.warn('[OpenRouter] Model ran out of tokens — reasoning consumed all output. Consider increasing max_tokens.');
        }
        // Retry once if finish_reason is 'length' with empty content and no function calls
        if (finishReason === 'length' && !textContent && (!functionCalls || functionCalls.length === 0)) {
            console.warn('[OpenRouter] Empty content with finish_reason=length, retrying with trimmed history and increased max_tokens.');
            this.trimHistory(Math.min(RETRY_HISTORY_TARGET, _api_client__WEBPACK_IMPORTED_MODULE_1__.MAX_HISTORY_MESSAGES));
            this.trimHistoryByInputBudget(maxInputTokens);
            const retryBody = this.buildRequestBody(config);
            const currentMaxTokens = retryBody.max_tokens ?? _api_client__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MAX_TOKENS;
            retryBody.max_tokens = Math.max(currentMaxTokens, _api_client__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MAX_TOKENS);
            const retryRes = await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.fetchWithBackoff)(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_CHAT_ENDPOINT, {
                method: 'POST',
                headers: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.buildHeaders)(this.apiKey),
                body: JSON.stringify(retryBody),
            });
            if (retryRes.ok) {
                const retryData = (await retryRes.json());
                if (retryData.choices?.length && retryData.choices[0].message) {
                    const retryMsg = retryData.choices[0].message;
                    const retryText = typeof retryMsg.content === 'string' ? retryMsg.content : '';
                    const retryReasoning = typeof retryMsg.reasoning === 'string' ? retryMsg.reasoning : '';
                    const retryFinishReason = retryData.choices[0].finish_reason;
                    const retryFunctionCalls = retryMsg.tool_calls?.map((tc) => ({
                        name: tc.function.name,
                        args: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.safeParseArguments)(tc.function.arguments, tc.id, tc.function.name),
                        id: tc.id,
                    }));
                    // Update history with retry response
                    this.history[this.history.length - 1] = {
                        ...retryMsg,
                        content: retryMsg.content ?? '',
                    };
                    return {
                        text: retryText,
                        reasoning: retryReasoning || undefined,
                        finishReason: retryFinishReason,
                        functionCalls: retryFunctionCalls,
                        candidates: retryData.choices,
                    };
                }
            }
        }
        return {
            text: textContent,
            reasoning: reasoning || undefined,
            finishReason,
            functionCalls,
            candidates: data.choices,
        };
    }
    /**
     * Send a message and stream the response token-by-token via SSE.
     * Yields StreamChunk objects; the final chunk has `done: true`.
     */
    async *sendMessageStreaming(params) {
        const { message, config } = params;
        const maxInputTokens = this.resolveMaxInputTokens(config);
        this.appendIncomingMessages(message);
        this.trimHistory(_api_client__WEBPACK_IMPORTED_MODULE_1__.MAX_HISTORY_MESSAGES);
        this.trimHistoryByInputBudget(maxInputTokens);
        const body = this.buildRequestBody(config, true);
        console.debug(`[OpenRouter] Streaming request: model=${this.model}, messages=${body.messages.length}`);
        const res = await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.fetchWithBackoff)(_utils_constants__WEBPACK_IMPORTED_MODULE_0__.OPENROUTER_CHAT_ENDPOINT, {
            method: 'POST',
            headers: (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.buildHeaders)(this.apiKey),
            body: JSON.stringify(body),
        });
        if (!res.ok) {
            await (0,_api_client__WEBPACK_IMPORTED_MODULE_1__.throwApiError)(res);
        }
        const reader = res.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable for streaming');
        }
        yield* (0,_streaming__WEBPACK_IMPORTED_MODULE_2__.parseSSEStream)(reader, this.history);
    }
}


/***/ }),

/***/ "./src/services/adapters/openrouter/errors.ts":
/*!****************************************************!*\
  !*** ./src/services/adapters/openrouter/errors.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthenticationError: () => (/* binding */ AuthenticationError),
/* harmony export */   ModelError: () => (/* binding */ ModelError),
/* harmony export */   OpenRouterError: () => (/* binding */ OpenRouterError),
/* harmony export */   RateLimitError: () => (/* binding */ RateLimitError)
/* harmony export */ });
/** Base class for OpenRouter API errors */
class OpenRouterError extends Error {
    statusCode;
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'OpenRouterError';
    }
}
/** Thrown when the API key is invalid or missing (401/403) */
class AuthenticationError extends OpenRouterError {
    constructor(message, statusCode) {
        super(message, statusCode);
        this.name = 'AuthenticationError';
    }
}
/** Thrown when rate-limited by the API (429) */
class RateLimitError extends OpenRouterError {
    retryAfterMs;
    constructor(message, retryAfterMs) {
        super(message, 429);
        this.retryAfterMs = retryAfterMs;
        this.name = 'RateLimitError';
    }
}
/** Thrown for model-specific errors (invalid model, context length exceeded) */
class ModelError extends OpenRouterError {
    constructor(message, statusCode) {
        super(message, statusCode);
        this.name = 'ModelError';
    }
}


/***/ }),

/***/ "./src/services/adapters/openrouter/index.ts":
/*!***************************************************!*\
  !*** ./src/services/adapters/openrouter/index.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthenticationError: () => (/* reexport safe */ _errors__WEBPACK_IMPORTED_MODULE_2__.AuthenticationError),
/* harmony export */   ModelError: () => (/* reexport safe */ _errors__WEBPACK_IMPORTED_MODULE_2__.ModelError),
/* harmony export */   OpenRouterAdapter: () => (/* reexport safe */ _adapter__WEBPACK_IMPORTED_MODULE_0__.OpenRouterAdapter),
/* harmony export */   OpenRouterChat: () => (/* reexport safe */ _client__WEBPACK_IMPORTED_MODULE_1__.OpenRouterChat),
/* harmony export */   OpenRouterError: () => (/* reexport safe */ _errors__WEBPACK_IMPORTED_MODULE_2__.OpenRouterError),
/* harmony export */   RateLimitError: () => (/* reexport safe */ _errors__WEBPACK_IMPORTED_MODULE_2__.RateLimitError)
/* harmony export */ });
/* harmony import */ var _adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./adapter */ "./src/services/adapters/openrouter/adapter.ts");
/* harmony import */ var _client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./client */ "./src/services/adapters/openrouter/client.ts");
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors */ "./src/services/adapters/openrouter/errors.ts");
/**
 * OpenRouter adapter module — re-exports all public API.
 */





/***/ }),

/***/ "./src/services/adapters/openrouter/streaming.ts":
/*!*******************************************************!*\
  !*** ./src/services/adapters/openrouter/streaming.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   parseSSEStream: () => (/* binding */ parseSSEStream)
/* harmony export */ });
/* harmony import */ var _api_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api-client */ "./src/services/adapters/openrouter/api-client.ts");

/**
 * Parse an SSE stream from the OpenRouter API, yielding StreamChunk objects.
 * Appends the final assistant message to the provided history array.
 */
async function* parseSSEStream(reader, history) {
    const decoder = new TextDecoder();
    let fullText = '';
    let buffer = '';
    const accumulatedToolCalls = new Map();
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() ?? '';
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || !trimmed.startsWith('data: '))
                    continue;
                const payload = trimmed.slice(6);
                if (payload === '[DONE]') {
                    let functionCalls;
                    if (accumulatedToolCalls.size > 0) {
                        functionCalls = [];
                        for (const tc of accumulatedToolCalls.values()) {
                            functionCalls.push({
                                name: tc.name,
                                args: (0,_api_client__WEBPACK_IMPORTED_MODULE_0__.safeParseArguments)(tc.arguments, tc.id, tc.name),
                                id: tc.id,
                            });
                        }
                    }
                    history.push({ role: 'assistant', content: fullText });
                    yield { text: '', done: true, functionCalls };
                    return;
                }
                try {
                    const chunk = JSON.parse(payload);
                    const delta = chunk.choices?.[0]?.delta;
                    if (!delta)
                        continue;
                    if (delta.content) {
                        fullText += delta.content;
                        yield { text: delta.content, done: false };
                    }
                    if (delta.tool_calls) {
                        for (const tc of delta.tool_calls) {
                            const existing = accumulatedToolCalls.get(tc.index);
                            if (existing) {
                                if (tc.function?.arguments) {
                                    existing.arguments += tc.function.arguments;
                                }
                            }
                            else {
                                accumulatedToolCalls.set(tc.index, {
                                    id: tc.id ?? '',
                                    name: tc.function?.name ?? '',
                                    arguments: tc.function?.arguments ?? '',
                                });
                            }
                        }
                    }
                }
                catch {
                    // Skip malformed SSE lines
                }
            }
        }
    }
    finally {
        reader.releaseLock();
    }
    // Fallback: if stream ended without [DONE]
    history.push({ role: 'assistant', content: fullText });
    let functionCalls;
    if (accumulatedToolCalls.size > 0) {
        functionCalls = [];
        for (const tc of accumulatedToolCalls.values()) {
            functionCalls.push({
                name: tc.name,
                args: (0,_api_client__WEBPACK_IMPORTED_MODULE_0__.safeParseArguments)(tc.arguments, tc.id, tc.name),
                id: tc.id,
            });
        }
    }
    yield { text: '', done: true, functionCalls };
}


/***/ }),

/***/ "./src/utils/constants.ts":
/*!********************************!*\
  !*** ./src/utils/constants.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AI_CLASSIFIER_CONFIG: () => (/* binding */ AI_CLASSIFIER_CONFIG),
/* harmony export */   AI_CLASSIFIER_TITLE: () => (/* binding */ AI_CLASSIFIER_TITLE),
/* harmony export */   AI_CONFIDENCE_THRESHOLD: () => (/* binding */ AI_CONFIDENCE_THRESHOLD),
/* harmony export */   AI_MAX_RETRIES: () => (/* binding */ AI_MAX_RETRIES),
/* harmony export */   AI_RETRY_DELAY_MS: () => (/* binding */ AI_RETRY_DELAY_MS),
/* harmony export */   CONTENT_SCRIPTS: () => (/* binding */ CONTENT_SCRIPTS),
/* harmony export */   DEFAULT_CLASSIFIER_MODEL: () => (/* binding */ DEFAULT_CLASSIFIER_MODEL),
/* harmony export */   DEFAULT_MODEL: () => (/* binding */ DEFAULT_MODEL),
/* harmony export */   DOM_OBSERVER_DEBOUNCE_MS: () => (/* binding */ DOM_OBSERVER_DEBOUNCE_MS),
/* harmony export */   INFERENCE_CACHE_TTL: () => (/* binding */ INFERENCE_CACHE_TTL),
/* harmony export */   MAX_PAGE_CONTEXT_PRODUCTS: () => (/* binding */ MAX_PAGE_CONTEXT_PRODUCTS),
/* harmony export */   MAX_TOOLS_PER_CATEGORY: () => (/* binding */ MAX_TOOLS_PER_CATEGORY),
/* harmony export */   MIN_CONFIDENCE: () => (/* binding */ MIN_CONFIDENCE),
/* harmony export */   OPENROUTER_BASE_URL: () => (/* binding */ OPENROUTER_BASE_URL),
/* harmony export */   OPENROUTER_CHAT_ENDPOINT: () => (/* binding */ OPENROUTER_CHAT_ENDPOINT),
/* harmony export */   OPENROUTER_DEFAULT_MAX_INPUT_TOKENS: () => (/* binding */ OPENROUTER_DEFAULT_MAX_INPUT_TOKENS),
/* harmony export */   OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS: () => (/* binding */ OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS),
/* harmony export */   OPENROUTER_MAX_HISTORY_MESSAGES: () => (/* binding */ OPENROUTER_MAX_HISTORY_MESSAGES),
/* harmony export */   OPENROUTER_MODELS_ENDPOINT: () => (/* binding */ OPENROUTER_MODELS_ENDPOINT),
/* harmony export */   OPENROUTER_REFERER: () => (/* binding */ OPENROUTER_REFERER),
/* harmony export */   OPENROUTER_TITLE: () => (/* binding */ OPENROUTER_TITLE),
/* harmony export */   SCANNER_CATEGORIES: () => (/* binding */ SCANNER_CATEGORIES),
/* harmony export */   SECURITY_TIERS: () => (/* binding */ SECURITY_TIERS),
/* harmony export */   SHADOW_DOM_MAX_DEPTH: () => (/* binding */ SHADOW_DOM_MAX_DEPTH),
/* harmony export */   SPA_NAVIGATION_DEBOUNCE_MS: () => (/* binding */ SPA_NAVIGATION_DEBOUNCE_MS),
/* harmony export */   STORAGE_KEY_API_KEY: () => (/* binding */ STORAGE_KEY_API_KEY),
/* harmony export */   STORAGE_KEY_CONVERSATIONS: () => (/* binding */ STORAGE_KEY_CONVERSATIONS),
/* harmony export */   STORAGE_KEY_LOCK_MODE: () => (/* binding */ STORAGE_KEY_LOCK_MODE),
/* harmony export */   STORAGE_KEY_MODEL: () => (/* binding */ STORAGE_KEY_MODEL),
/* harmony export */   STORAGE_KEY_ORCHESTRATOR_MODE: () => (/* binding */ STORAGE_KEY_ORCHESTRATOR_MODE),
/* harmony export */   STORAGE_KEY_PLAN_MODE: () => (/* binding */ STORAGE_KEY_PLAN_MODE),
/* harmony export */   STORAGE_KEY_SCREENSHOT_ENABLED: () => (/* binding */ STORAGE_KEY_SCREENSHOT_ENABLED),
/* harmony export */   STORAGE_KEY_YOLO_MODE: () => (/* binding */ STORAGE_KEY_YOLO_MODE),
/* harmony export */   SecurityTierLevel: () => (/* binding */ SecurityTierLevel)
/* harmony export */ });
/**
 * Constants extracted from the JS source files.
 * Single source of truth for magic numbers, strings, and configuration.
 */
// ── Inference Engine ──
/** Maximum number of tools a single category scanner can emit */
const MAX_TOOLS_PER_CATEGORY = 15;
/** Inference cache TTL in milliseconds (30 seconds) */
const INFERENCE_CACHE_TTL = 30_000;
/** Confidence threshold: below this tools are sent to AI classifier */
const AI_CONFIDENCE_THRESHOLD = 0.7;
/** Minimum confidence: below this tools are discarded entirely */
const MIN_CONFIDENCE = 0.5;
// ── Security Tiers ──
/** Security tier metadata definitions */
const SECURITY_TIERS = {
    0: { label: 'Safe', autoExecute: true },
    1: { label: 'Navigation', autoExecute: true },
    2: { label: 'Mutation', autoExecute: false },
};
/** Security tier enum values for convenience */
const SecurityTierLevel = {
    SAFE: 0,
    NAVIGATION: 1,
    MUTATION: 2,
};
// ── Scanner Categories ──
/** All 13 scanner categories in priority order (specialized before generic) */
const SCANNER_CATEGORIES = [
    'form',
    'navigation',
    'search',
    'richtext',
    'social-action',
    'file-upload',
    'interactive',
    'media',
    'ecommerce',
    'auth',
    'page-state',
    'schema-org',
    'chatbot',
];
// ── AI Classifier ──
/** Default AI classifier configuration */
const AI_CLASSIFIER_CONFIG = {
    confidenceThreshold: 0.65,
    batchSize: 15,
    model: 'google/gemini-2.0-flash-lite-001',
    cacheTTL: 5 * 60 * 1000, // 5 minutes
};
// ── OpenRouter API ──
/** OpenRouter API base URL */
const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';
/** OpenRouter chat completions endpoint */
const OPENROUTER_CHAT_ENDPOINT = `${OPENROUTER_BASE_URL}/chat/completions`;
/** OpenRouter models list endpoint */
const OPENROUTER_MODELS_ENDPOINT = `${OPENROUTER_BASE_URL}/models`;
/** Default model for chat interactions */
const DEFAULT_MODEL = 'google/gemini-2.0-flash-001';
/** Default model for AI classifier (lightweight) */
const DEFAULT_CLASSIFIER_MODEL = 'google/gemini-2.0-flash-lite-001';
/** Default max output tokens for chat completions */
const OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS = 65_000;
/** Internal input budget cap used for local history trimming */
const OPENROUTER_DEFAULT_MAX_INPUT_TOKENS = 1_000_000;
/** Max retained messages in chat history before additional input-budget trimming */
const OPENROUTER_MAX_HISTORY_MESSAGES = 200;
// ── Storage Keys ──
/** localStorage key for conversation data */
const STORAGE_KEY_CONVERSATIONS = 'wmcp_conversations';
/** localStorage key for lock mode state */
const STORAGE_KEY_LOCK_MODE = 'wmcp_lock_mode';
/** localStorage key for OpenRouter API key */
const STORAGE_KEY_API_KEY = 'openrouter_api_key';
/** localStorage key for selected model */
const STORAGE_KEY_MODEL = 'openrouter_model';
/** Storage key for screenshot toggle */
const STORAGE_KEY_SCREENSHOT_ENABLED = 'wmcp_screenshot_enabled';
/** Storage key for plan mode toggle */
const STORAGE_KEY_PLAN_MODE = 'wmcp_plan_mode';
/** Key for YOLO mode (auto-execute all tools without confirmation) */
const STORAGE_KEY_YOLO_MODE = 'wmcp_yolo_mode';
/** Key for orchestrator mode (use hexagonal AgentOrchestrator instead of legacy tool-loop) */
const STORAGE_KEY_ORCHESTRATOR_MODE = 'wmcp_orchestrator_mode';
// ── Timing ──
/** Debounce delay for DOM mutation observer (ms) */
const DOM_OBSERVER_DEBOUNCE_MS = 300;
/** Debounce delay for SPA navigation detection (ms) */
const SPA_NAVIGATION_DEBOUNCE_MS = 500;
/** Max retry attempts for empty AI responses */
const AI_MAX_RETRIES = 3;
/** Delay between AI retry attempts (ms) */
const AI_RETRY_DELAY_MS = 1000;
// ── HTTP Headers ──
/** HTTP-Referer header for OpenRouter requests */
const OPENROUTER_REFERER = 'https://github.com/miguelspizza/webmcp';
/** X-Title header for OpenRouter requests */
const OPENROUTER_TITLE = 'Model Context Tool Inspector (OpenRouter)';
/** X-Title header for AI classifier requests */
const AI_CLASSIFIER_TITLE = 'WMCP AI Classifier';
// ── Content Script ──
/** Content scripts injected on install (bundled into single file by webpack) */
const CONTENT_SCRIPTS = [
    'content.js',
];
/** Max products to extract from page context */
const MAX_PAGE_CONTEXT_PRODUCTS = 20;
/** Shadow DOM max traversal depth */
const SHADOW_DOM_MAX_DEPTH = 5;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/options/index.ts ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _services_adapters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/adapters */ "./src/services/adapters/index.ts");
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/**
 * Options page controller.
 * Manages API key, model selection, and connection testing.
 */


// ── DOM refs ──
const $ = (id) => document.getElementById(id);
const apiKeyInput = $('apiKey');
const saveTestBtn = $('saveTestBtn');
const connectionStatus = $('connectionStatus');
const modelSelect = $('modelSelect');
const modelList = $('modelList');
const versionLabel = $('versionLabel');
const screenshotToggle = $('screenshotToggle');
const yoloToggle = $('yoloToggle');
// ── Load saved settings ──
async function loadSettings() {
    const result = await chrome.storage.local.get([
        _utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_API_KEY,
        _utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL,
        _utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_SCREENSHOT_ENABLED,
        _utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_YOLO_MODE,
    ]);
    const savedKey = result[_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_API_KEY] ?? '';
    const savedModel = result[_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL] ?? _utils_constants__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MODEL;
    if (savedKey)
        apiKeyInput.value = savedKey;
    modelSelect.value = savedModel;
    screenshotToggle.checked = !!result[_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_SCREENSHOT_ENABLED];
    yoloToggle.checked = result[_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_YOLO_MODE] !== false; // Default: true
    // Load version from manifest
    const manifest = chrome.runtime.getManifest();
    versionLabel.textContent = manifest.version;
    // If we have a key, try to populate models
    if (savedKey) {
        void populateModels(savedKey);
    }
}
// ── Populate model datalist ──
async function populateModels(apiKey) {
    try {
        const adapter = new _services_adapters__WEBPACK_IMPORTED_MODULE_0__.OpenRouterAdapter({ apiKey });
        const models = await adapter.listModels();
        modelList.innerHTML = '';
        for (const model of models) {
            const option = document.createElement('option');
            option.value = model.id;
            modelList.appendChild(option);
        }
    }
    catch {
        /* silently fail — models will use defaults */
    }
}
// ── Save & Test ──
saveTestBtn.onclick = async () => {
    const apiKey = apiKeyInput.value.trim();
    const model = modelSelect.value.trim() || _utils_constants__WEBPACK_IMPORTED_MODULE_1__.DEFAULT_MODEL;
    if (!apiKey) {
        connectionStatus.textContent = '❌ Add your OpenRouter key';
        connectionStatus.className = 'status-message status-error';
        return;
    }
    connectionStatus.textContent = '⏳ Checking connection...';
    connectionStatus.className = 'status-message';
    saveTestBtn.disabled = true;
    try {
        const testAdapter = new _services_adapters__WEBPACK_IMPORTED_MODULE_0__.OpenRouterAdapter({ apiKey });
        const models = await testAdapter.listModels();
        await chrome.storage.local.set({
            [_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_API_KEY]: apiKey,
            [_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL]: model,
        });
        // Also update localStorage for backward compatibility
        localStorage.setItem(_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_API_KEY, apiKey);
        localStorage.setItem(_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL, model);
        // Populate model datalist with fetched models
        modelList.innerHTML = '';
        for (const m of models) {
            const option = document.createElement('option');
            option.value = m.id;
            modelList.appendChild(option);
        }
        connectionStatus.textContent =
            '✅ Connected. Preferences saved.';
        connectionStatus.className = 'status-message status-success';
    }
    catch (error) {
        connectionStatus.textContent = `❌ Connection failed: ${error.message}`;
        connectionStatus.className = 'status-message status-error';
    }
    finally {
        saveTestBtn.disabled = false;
    }
};
// ── Save model on change ──
modelSelect.addEventListener('input', () => {
    const model = modelSelect.value.trim();
    if (model) {
        void chrome.storage.local.set({ [_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL]: model });
        localStorage.setItem(_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_MODEL, model);
    }
});
// ── Screenshot toggle ──
screenshotToggle.addEventListener('change', () => {
    void chrome.storage.local.set({
        [_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_SCREENSHOT_ENABLED]: screenshotToggle.checked,
    });
});
// ── YOLO mode toggle ──
yoloToggle.addEventListener('change', () => {
    void chrome.storage.local.set({
        [_utils_constants__WEBPACK_IMPORTED_MODULE_1__.STORAGE_KEY_YOLO_MODE]: yoloToggle.checked,
    });
});
// ── Init ──
void loadSettings();

})();

/******/ })()
;
//# sourceMappingURL=options.js.map