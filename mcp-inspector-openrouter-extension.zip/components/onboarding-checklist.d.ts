import { BaseElement } from './base-element';
interface OnboardingState {
    message: boolean;
    advanced: boolean;
    preferences: boolean;
    dismissed: boolean;
}
export declare class OnboardingChecklist extends BaseElement {
    static properties: {
        _state: {
            state: boolean;
        };
    };
    _state: OnboardingState;
    constructor();
    createRenderRoot(): this;
    connectedCallback(): void;
    markMessageSent(): void;
    markAdvancedOpened(): void;
    markPreferencesOpened(): void;
    private _loadState;
    private _saveState;
    private _markStep;
    private _dismiss;
    private _completedSteps;
    private _allDone;
    private _dispatch;
    private _onFocusInput;
    private _onOpenAdvanced;
    private _onOpenOptions;
    private _renderStep;
    render(): unknown;
}
export {};
