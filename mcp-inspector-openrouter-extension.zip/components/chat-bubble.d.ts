import { BaseElement } from './base-element';
import type { MessageRole } from '../types';
import './reasoning-accordion';
export declare class ChatBubble extends BaseElement {
    static properties: {
        role: {
            type: StringConstructor;
        };
        content: {
            type: StringConstructor;
        };
        timestamp: {
            type: NumberConstructor;
        };
        toolName: {
            type: StringConstructor;
            attribute: string;
        };
        toolArgs: {
            type: ObjectConstructor;
            attribute: string;
        };
        reasoning: {
            type: StringConstructor;
        };
        editable: {
            type: BooleanConstructor;
        };
        index: {
            type: NumberConstructor;
        };
        _editing: {
            type: BooleanConstructor;
            state: boolean;
        };
    };
    role: MessageRole;
    content: string;
    timestamp: number;
    toolName: string;
    toolArgs: Record<string, unknown>;
    reasoning: string;
    editable: boolean;
    index: number;
    _editing: boolean;
    constructor();
    /** Light DOM — inherits chat.css styles */
    createRenderRoot(): this;
    protected updated(changedProperties: Map<string, unknown>): void;
    connectedCallback(): void;
    private _saveEdit;
    private _cancelEdit;
    private _startEdit;
    private _handleDelete;
    protected render(): unknown;
    private _friendlyName;
    private _describeAction;
    private _describeResult;
}
