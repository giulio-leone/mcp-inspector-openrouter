/**
 * <manifest-dashboard> — MCP manifest viewer for the sidebar.
 *
 * Lit 3.3.2 component (NON-decorator, Light DOM) showing:
 * - Current site origin, tool count, page count, last updated
 * - Expandable tool list with name, description, inputSchema preview
 * - Filter/search by tool name
 * - "Copy JSON" and "Refresh" buttons
 */
import { BaseElement } from './base-element';
export declare class ManifestDashboard extends BaseElement {
    static properties: {
        manifestJson: {
            type: StringConstructor;
        };
        loading: {
            type: BooleanConstructor;
        };
        error: {
            type: StringConstructor;
        };
        _filter: {
            type: StringConstructor;
            state: boolean;
        };
        _expandedTools: {
            type: ObjectConstructor;
            state: boolean;
        };
        _copyFeedback: {
            type: BooleanConstructor;
            state: boolean;
        };
    };
    manifestJson: string;
    loading: boolean;
    error: string;
    _filter: string;
    _expandedTools: Set<string>;
    _copyFeedback: boolean;
    constructor();
    createRenderRoot(): this;
    private _parsed;
    private _filteredTools;
    private _formatTime;
    render(): unknown;
    private _renderTool;
    private _toggleTool;
    private _onFilterChange;
    private _onCopy;
    private _onRefresh;
}
