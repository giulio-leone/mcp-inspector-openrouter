import { BaseElement } from './base-element';
import type { CleanTool } from '../types';
export declare class ToolTable extends BaseElement {
    static properties: {
        tools: {
            type: ArrayConstructor;
        };
        statusMessage: {
            type: StringConstructor;
        };
        loading: {
            type: BooleanConstructor;
        };
        pageUrl: {
            type: StringConstructor;
        };
        prettify: {
            type: BooleanConstructor;
        };
        _selectedTool: {
            type: StringConstructor;
            state: boolean;
        };
        _inputArgs: {
            type: StringConstructor;
            state: boolean;
        };
        _toolResults: {
            type: StringConstructor;
            state: boolean;
        };
    };
    tools: CleanTool[];
    statusMessage: string;
    loading: boolean;
    pageUrl: string;
    prettify: boolean;
    _selectedTool: string;
    _inputArgs: string;
    _toolResults: string;
    _instanceId: string;
    constructor();
    createRenderRoot(): this;
    private _grouped;
    private _updateInputArgsFromTool;
    private _elId;
    private _renderStatus;
    private _renderEmptyState;
    private _renderCategoryHeader;
    private _renderNavigationSubgroups;
    private _renderToolRow;
    private _renderTable;
    private _renderToolOption;
    private _renderManualExecution;
    render(): unknown;
    willUpdate(changed: Map<string, unknown>): void;
    /** Set tool results text (called from outside after execution). */
    setToolResults(text: string): void;
    private _onTogglePrettify;
    private _onCopy;
    private _onCopyScript;
    private _onCopyJson;
    private _onExportManifest;
    private _onToolChange;
    private _onInputArgsChange;
    private _onExecute;
    /** Get clipboard text for a given format. */
    getClipboardText(format: 'script' | 'json'): string;
}
