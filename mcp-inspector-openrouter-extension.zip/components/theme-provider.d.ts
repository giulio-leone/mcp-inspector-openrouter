/**
 * ThemeProvider — <theme-provider> Web Component.
 * Manages dark/light/auto theme with CSS custom properties.
 * Auto-detect respects prefers-color-scheme.
 * Persists preference in chrome.storage.local.
 */
import { LitElement } from 'lit';
type Theme = 'light' | 'dark' | 'auto';
export declare class ThemeProvider extends LitElement {
    static properties: {
        theme: {
            type: StringConstructor;
            reflect: boolean;
        };
    };
    theme: Theme;
    private mediaQuery;
    private mediaHandler;
    constructor();
    static styles: import("lit").CSSResult;
    connectedCallback(): void;
    disconnectedCallback(): void;
    private loadSavedTheme;
    setTheme(newTheme: Theme): Promise<void>;
    private getResolvedTheme;
    applyTheme(): void;
    protected render(): unknown;
}
export {};
