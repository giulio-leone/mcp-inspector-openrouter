/**
 * BaseElement — shared base for all Lit Web Components.
 * Provides theme-aware CSS custom properties and utility methods.
 */
import { LitElement } from 'lit';
/** Shared design tokens as CSS */
export declare const sharedStyles: import("lit").CSSResult;
export declare class BaseElement extends LitElement {
}
