import { BaseElement } from './base-element';
import type { Message } from '../types';
import './chat-bubble';
export declare class ChatContainer extends BaseElement {
    static properties: {
        messages: {
            type: ArrayConstructor;
        };
        editable: {
            type: BooleanConstructor;
        };
    };
    messages: Message[];
    editable: boolean;
    constructor();
    /** Light DOM — inherits chat.css styles */
    createRenderRoot(): this;
    connectedCallback(): void;
    /** Append a single message and scroll to bottom */
    appendMessage(msg: Message): Promise<void>;
    /** Remove all messages */
    clear(): void;
    /** Replace all messages at once (used by renderConversation / renderConversationWithActions) */
    setMessages(msgs: Message[], editable?: boolean): void;
    /** Scroll to the bottom of this container */
    scrollToBottom(): void;
    private _onBubbleEdit;
    private _onBubbleDelete;
    protected render(): unknown;
    /** Merge consecutive tool_call + tool_result/tool_error into a single resolved step */
    private _mergeToolPairs;
}
