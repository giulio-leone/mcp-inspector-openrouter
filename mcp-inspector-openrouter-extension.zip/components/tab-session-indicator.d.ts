import { BaseElement } from './base-element';
export interface SessionInfo {
    tabId: number;
    title: string;
    active: boolean;
}
export declare class TabSessionIndicator extends BaseElement {
    static properties: {
        sessions: {
            type: ArrayConstructor;
        };
        sessionActive: {
            type: BooleanConstructor;
            attribute: string;
        };
    };
    sessions: SessionInfo[];
    sessionActive: boolean;
    constructor();
    createRenderRoot(): this;
    get activeSession(): SessionInfo | undefined;
    get sessionCount(): number;
    render(): unknown;
}
