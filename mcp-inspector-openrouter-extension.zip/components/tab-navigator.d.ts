import { BaseElement } from './base-element';
export interface TabConfig {
    id: string;
    label: string;
    icon: string;
}
export declare class TabNavigator extends BaseElement {
    static properties: {
        activeTab: {
            type: StringConstructor;
        };
        tabs: {
            type: ArrayConstructor;
        };
    };
    activeTab: string;
    tabs: TabConfig[];
    constructor();
    /** Light DOM — inherits existing CSS */
    createRenderRoot(): this;
    render(): unknown;
    /** Validate icon string starts with '<svg' before using unsafeHTML. */
    private _renderIcon;
    private _onTabClick;
}
