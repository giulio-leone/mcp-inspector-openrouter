import { BaseElement } from './base-element';
import type { Plan, PlanStepStatus } from '../types';
export declare class PlanViewer extends BaseElement {
    static properties: {
        plan: {
            type: ObjectConstructor;
        };
        collapsed: {
            type: BooleanConstructor;
        };
    };
    plan: Plan | null;
    collapsed: boolean;
    constructor();
    createRenderRoot(): this;
    /** Update a step's status/detail and trigger re-render with auto-computed overall status. */
    updateStep(stepId: string, status: PlanStepStatus, detail?: string): void;
    private _findStep;
    private _computeOverallStatus;
    private _collectStatuses;
    private _toggleCollapse;
    private _renderStep;
    protected render(): unknown;
}
