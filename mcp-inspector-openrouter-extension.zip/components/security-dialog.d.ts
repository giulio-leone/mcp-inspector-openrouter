/**
 * <security-dialog> — Light DOM Lit component for security confirmation
 * before executing tier 1/2 tool calls.
 */
import { LitElement } from 'lit';
export declare class SecurityDialog extends LitElement {
    static properties: {
        open: {
            type: BooleanConstructor;
            reflect: boolean;
        };
        toolName: {
            type: StringConstructor;
            attribute: string;
        };
        action: {
            type: StringConstructor;
        };
        securityTier: {
            type: NumberConstructor;
            attribute: string;
        };
        details: {
            type: StringConstructor;
        };
    };
    open: boolean;
    toolName: string;
    action: string;
    securityTier: number;
    details: string;
    constructor();
    /** Light DOM — inherits existing sidebar CSS */
    createRenderRoot(): this;
    /**
     * Open the dialog with the given configuration.
     */
    show(config: {
        toolName: string;
        action?: string;
        securityTier?: number;
        details?: string;
    }): void;
    private _approve;
    private _deny;
    private _close;
    private _handleCancel;
    protected render(): unknown;
}
