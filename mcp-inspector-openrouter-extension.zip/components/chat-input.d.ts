import { BaseElement } from './base-element';
export declare class ChatInput extends BaseElement {
    static properties: {
        disabled: {
            type: BooleanConstructor;
        };
        placeholder: {
            type: StringConstructor;
        };
        presets: {
            type: ArrayConstructor;
        };
        _hasContent: {
            type: BooleanConstructor;
            state: boolean;
        };
    };
    disabled: boolean;
    placeholder: string;
    presets: string[];
    _hasContent: boolean;
    constructor();
    /** Light DOM — inherits existing CSS */
    createRenderRoot(): this;
    connectedCallback(): void;
    /** Returns the raw textarea value. */
    get value(): string;
    /** Sets the textarea value. */
    set value(v: string);
    /** Sync _hasContent from current textarea value — call after batch value changes. */
    syncState(): void;
    /** Focuses the textarea. */
    focus(): void;
    setPresets(presets: string[]): void;
    /** Clears the textarea and resets state. */
    clear(): void;
    render(): unknown;
    private _onInput;
    private _onKeydown;
    private _onSend;
    private _onPresetClick;
}
