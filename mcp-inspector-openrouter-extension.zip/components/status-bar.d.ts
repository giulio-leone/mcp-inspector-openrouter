import { BaseElement } from './base-element';
export declare class StatusBar extends BaseElement {
    static properties: {
        message: {
            type: StringConstructor;
        };
        type: {
            type: StringConstructor;
        };
    };
    message: string;
    type: 'info' | 'success' | 'error' | 'warning';
    constructor();
    createRenderRoot(): this;
    render(): unknown;
}
