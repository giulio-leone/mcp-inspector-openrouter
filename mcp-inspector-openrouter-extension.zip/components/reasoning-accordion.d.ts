import { BaseElement } from './base-element';
export declare class ReasoningAccordion extends BaseElement {
    static properties: {
        content: {
            type: StringConstructor;
        };
    };
    content: string;
    constructor();
    /** Light DOM — inherits chat.css styles */
    createRenderRoot(): this;
    protected render(): unknown;
}
