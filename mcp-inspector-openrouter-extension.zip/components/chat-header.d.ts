import { BaseElement } from './base-element';
import type { ConversationSummary } from '../types';
export declare class ChatHeader extends BaseElement {
    static properties: {
        conversations: {
            type: ArrayConstructor;
        };
        activeConversationId: {
            type: StringConstructor;
        };
        planActive: {
            type: BooleanConstructor;
        };
        showApiKeyHint: {
            type: BooleanConstructor;
        };
    };
    conversations: ConversationSummary[];
    activeConversationId: string;
    planActive: boolean;
    showApiKeyHint: boolean;
    constructor();
    /** Light DOM — inherits existing CSS */
    createRenderRoot(): this;
    connectedCallback(): void;
    /** Update the dropdown options and active selection. */
    setConversations(conversations: ConversationSummary[], activeId: string | null): void;
    /** Show or hide the API key hint banner. */
    setApiKeyHint(show: boolean): void;
    /** Sync the <select> value after Lit re-renders to avoid stale selectedIndex. */
    updated(): void;
    private _renderToolbar;
    render(): unknown;
    private _onConversationChange;
    private _onNewChat;
    private _onDeleteChat;
    private _onTogglePlan;
    private _onToggleAdvanced;
    private _onOpenOptions;
}
