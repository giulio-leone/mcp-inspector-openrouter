/**
 * plan-manager.ts — Manages plan state, step tracking, and plan tool handling.
 */
import type { Plan, PlanStep, ToolResponse } from '../types';
import type { PlanViewer } from '../components/plan-viewer';
import type { IResettable } from './state-manager';
import '../components/plan-viewer';
export interface ActivePlan {
    plan: Plan;
    element: PlanViewer;
    currentStepIdx: number;
}
export declare class PlanManager implements IResettable {
    private readonly chatContainer;
    activePlan: ActivePlan | null;
    planModeEnabled: boolean;
    private _batchStepIdx;
    constructor(chatContainer: HTMLElement, initialPlanMode?: boolean);
    resetOnConversationChange(): void;
    getCurrentPlanStep(): PlanStep | null;
    advancePlanStep(): void;
    markRemainingStepsDone(): void;
    private _markStepsDoneRecursive;
    handlePlanTool(name: string, args: Record<string, unknown>, id: string): ToolResponse;
    /** Mark a step as in-progress in the plan UI. */
    markStepInProgress(): void;
    /** Mark the current step as done with optional detail. */
    markStepDone(detail?: string): void;
    /** Mark the current step as failed with optional detail. */
    markStepFailed(detail?: string): void;
}
