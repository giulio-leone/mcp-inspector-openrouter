/**
 * conversation-controller.ts — Manages conversation CRUD and DOM wiring.
 */
import type { MessageRole } from '../types';
import type { OpenRouterChat } from '../services/adapters';
import type { ChatHeader } from '../components/chat-header';
import type { StateManager } from './state-manager';
export interface ConversationState {
    currentSite: string;
    currentConvId: string | null;
    chat: OpenRouterChat | undefined;
    trace: unknown[];
}
export declare class ConversationController {
    private readonly chatContainer;
    private readonly chatHeader;
    private readonly stateManager;
    state: ConversationState;
    constructor(chatContainer: HTMLElement, chatHeader: ChatHeader, initialState: ConversationState, stateManager?: StateManager);
    refreshConversationList(): void;
    switchToConversation(convId: string): void;
    ensureConversation(): void;
    createNewConversation(): void;
    deleteConversation(): void;
    /** Handle site change (tab navigation / switch). Resets state if site changed. */
    handleSiteChange(newSite: string): boolean;
    /** Load conversations for the current site, opening the first one if any exist. */
    loadConversations(): void;
    /** Edit a message and truncate conversation after it */
    editMessage(index: number, newContent: string): void;
    /** Delete a message and all messages after it */
    deleteMessage(index: number): void;
    /** Rebuild OpenRouter chat history from stored messages */
    private rebuildChatHistory;
    /** Add a message and render it in the chat.
     *  When `pinned` is provided, the message is stored against that
     *  site/convId regardless of the current mutable state — this prevents
     *  cross-tab routing bugs when the user switches tabs mid-request.
     */
    addAndRender(role: MessageRole, content: string, meta?: Record<string, unknown>, pinned?: {
        site: string;
        convId: string;
    }): void;
}
