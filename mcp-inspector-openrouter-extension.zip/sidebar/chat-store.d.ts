/**
 * chat-store.ts — Conversation persistence layer.
 * Stores conversations in localStorage, organized by site hostname.
 * Converted from: chat-store.js
 */
import type { Conversation, ConversationSummary, Message, MessageRole } from '../types';
/** Get site key from URL (hostname only — all pages on same site share conversations) */
export declare function siteKey(url: string): string;
/** List all conversations for a site */
export declare function listConversations(site: string): ConversationSummary[];
/** Get a specific conversation by id */
export declare function getConversation(site: string, id: string): Conversation | null;
/** Create a new conversation, returns the conversation object */
export declare function createConversation(site: string, title?: string): Conversation;
/** Add a message to a conversation */
export declare function addMessage(site: string, convId: string, msg: {
    role: MessageRole;
    content: string;
} & Record<string, unknown>): void;
/** Delete a conversation */
export declare function deleteConversation(site: string, convId: string): void;
/** Replace message at index and truncate all messages after it */
export declare function editMessageAt(site: string, convId: string, index: number, newContent: string): Message[];
/** Delete message at index and all messages after it */
export declare function deleteMessageAt(site: string, convId: string, index: number): Message[];
/** Get all messages for a conversation */
export declare function getMessages(site: string, convId: string): Message[];
