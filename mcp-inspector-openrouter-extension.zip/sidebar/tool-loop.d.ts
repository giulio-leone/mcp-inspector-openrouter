/**
 * tool-loop.ts — Executes the AI tool-call loop until a final text response
 * or the iteration / timeout limit is reached.
 */
import type { CleanTool, PageContext, ChatSendResponse, MessageRole } from '../types';
import type { OpenRouterChat } from '../services/adapters';
import type { ChatConfig } from '../services/adapters/openrouter';
import type { PlanManager } from './plan-manager';
export declare function isNavigationTool(toolName: string): boolean;
export declare function waitForPageAndRescan(tabId: number, currentTools: CleanTool[]): Promise<{
    pageContext: PageContext | null;
    tools: CleanTool[];
}>;
export interface ToolLoopParams {
    chat: OpenRouterChat;
    tabId: number;
    /** The original tab where the sidebar is open (for cross-tab focus management) */
    originTabId?: number;
    initialResult: ChatSendResponse;
    pageContext: PageContext | null;
    currentTools: CleanTool[];
    planManager: PlanManager;
    trace: unknown[];
    addMessage: (role: MessageRole, content: string, meta?: Record<string, unknown>) => void;
    getConfig: (ctx: PageContext | null) => ChatConfig;
    onToolsUpdated: (tools: CleanTool[]) => void;
    /** Max tool-loop iterations (0 = unlimited, default: 0). */
    maxIterations?: number;
    /** Tool-loop timeout in ms (0 = unlimited, default: 0). */
    loopTimeoutMs?: number;
}
export interface ToolLoopResult {
    pageContext: PageContext | null;
    currentTools: CleanTool[];
}
export declare function executeToolLoop(params: ToolLoopParams): Promise<ToolLoopResult>;
