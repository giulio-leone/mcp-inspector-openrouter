/**
 * chat-ui.ts — Chat bubble rendering and conversation selector UI.
 * Delegates entirely to <chat-container> Lit component for rendering.
 */
import type { Message, MessageRole } from '../types';
import '../components/chat-container';
/** Clear all bubbles from the chat container */
export declare function clearChat(container: HTMLElement): void;
/** Add a bubble to the chat UI and scroll */
export declare function appendBubble(container: HTMLElement, role: MessageRole, content: string, meta?: Partial<Message>): void;
/** Render all messages from a conversation */
export declare function renderConversation(container: HTMLElement, messages: readonly Message[]): void;
export interface MessageActions {
    onEdit: (index: number, newContent: string) => void;
    onDelete: (index: number) => void;
}
/** Render conversation with edit/delete actions on each message */
export declare function renderConversationWithActions(container: HTMLElement, messages: readonly Message[], actions: MessageActions): void;
