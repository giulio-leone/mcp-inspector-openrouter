/** Sidebar entry — thin controller wiring up all modules. */
import '../components/theme-provider';
import '../components/tab-session-indicator';
import '../components/chat-container';
import '../components/chat-header';
import '../components/chat-input';
import '../components/onboarding-checklist';
import '../components/status-bar';
import '../components/tool-table';
import '../components/manifest-dashboard';
import '../components/security-dialog';
