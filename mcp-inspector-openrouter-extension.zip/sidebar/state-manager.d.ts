/**
 * state-manager.ts — Centralized per-conversation state reset.
 *
 * Components that hold per-conversation state implement IResettable
 * and register themselves here. On conversation switch/create/delete
 * a single call to resetConversationState() atomically resets all of them.
 */
/** Anything that holds per-conversation state. */
export interface IResettable {
    resetOnConversationChange(): void;
}
export declare class StateManager {
    private readonly resettables;
    register(resettable: IResettable): void;
    unregister(resettable: IResettable): void;
    /** Atomically reset all registered per-conversation state. */
    resetConversationState(): void;
}
