/**
 * config-builder.ts — Builds the ChatConfig (system prompt + function declarations)
 * for the AI chat, including plan management tools.
 */
import type { CleanTool, PageContext } from '../types';
import type { ChatConfig } from '../services/adapters/openrouter';
export interface JsonSchema {
    type?: string;
    properties?: Record<string, JsonSchema>;
    items?: JsonSchema;
    const?: unknown;
    oneOf?: JsonSchema[];
    default?: unknown;
    examples?: unknown[];
    enum?: string[];
    format?: string;
    minimum?: number;
    [key: string]: unknown;
}
export declare function generateTemplateFromSchema(schema: JsonSchema): unknown;
interface MentionContext {
    tabId: number;
    title: string;
    context: PageContext;
}
export declare function buildChatConfig(pageContext: PageContext | null | undefined, currentTools: readonly CleanTool[], planModeEnabled: boolean, mentionContexts?: MentionContext[]): ChatConfig;
export {};
