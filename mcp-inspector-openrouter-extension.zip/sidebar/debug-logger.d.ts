/**
 * debug-logger.ts — Centralized debug logging with file export.
 * Logs are collected in memory and can be downloaded as timestamped files.
 * Each session gets a unique ID based on date+time.
 */
type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
interface LogEntry {
    timestamp: string;
    level: LogLevel;
    category: string;
    message: string;
    data?: unknown;
}
export declare const logger: {
    debug: (cat: string, msg: string, data?: unknown) => void;
    info: (cat: string, msg: string, data?: unknown) => void;
    warn: (cat: string, msg: string, data?: unknown) => void;
    error: (cat: string, msg: string, data?: unknown) => void;
    /** Get all logs as formatted text */
    getText(): string;
    /** Download logs as a timestamped file */
    download(): void;
    /** Get raw log entries */
    getLogs(): readonly LogEntry[];
    /** Get session ID */
    getSessionId(): string;
    /** Clear all logs */
    clear(): void;
};
export {};
