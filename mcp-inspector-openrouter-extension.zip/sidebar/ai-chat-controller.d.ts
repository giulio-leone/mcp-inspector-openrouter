/**
 * ai-chat-controller.ts — Handles AI chat initialization, prompt suggestion, and message sending.
 */
import type { CleanTool } from '../types';
import type { PlanManager } from './plan-manager';
import type { ITabSessionPort } from '../ports/tab-session.port';
import type { SecurityDialog } from '../components/security-dialog';
import type { ConversationController } from './conversation-controller';
import type { ChatHeader } from '../components/chat-header';
import type { ChatInput } from '../components/chat-input';
import type { IResettable } from './state-manager';
export interface AIChatDeps {
    readonly chatInput: ChatInput;
    readonly chatHeader: ChatHeader;
    readonly getCurrentTab: () => Promise<chrome.tabs.Tab | undefined>;
    readonly getCurrentTools: () => CleanTool[];
    readonly setCurrentTools: (tools: CleanTool[]) => void;
    readonly convCtrl: ConversationController;
    readonly planManager: PlanManager;
    readonly securityDialogEl: SecurityDialog;
    readonly tabSession: ITabSessionPort;
}
export declare class AIChatController implements IResettable {
    private genAI;
    private userPromptPendingId;
    private lastSuggestedUserPrompt;
    private readonly deps;
    private mentionAC;
    private activeMentions;
    /** Pinned conversation coordinates for the in-flight request. */
    private pinnedConv;
    constructor(deps: AIChatDeps);
    resetOnConversationChange(): void;
    init(): Promise<void>;
    setupListeners(): void;
    suggestUserPrompt(): Promise<void>;
    promptAI(providedMessage?: string): Promise<void>;
    private runOrchestrator;
    private getFormattedDate;
    private extractPresetPrompts;
}
