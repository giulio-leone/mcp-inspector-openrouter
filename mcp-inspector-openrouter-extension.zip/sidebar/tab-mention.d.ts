/**
 * tab-mention.ts — @mention autocomplete for cross-tab references.
 * When the user types `@` in the chat input, shows a dropdown of open tabs.
 */
export interface TabMention {
    tabId: number;
    title: string;
    url: string;
}
export interface MentionAutocomplete {
    /** Clean up event listeners */
    destroy: () => void;
    /** Extract mentions from text and return clean text + mentioned tabs */
    parseMentions: (text: string) => {
        cleanText: string;
        mentions: TabMention[];
    };
}
export declare function createMentionAutocomplete(textarea: HTMLTextAreaElement, container: HTMLElement): MentionAutocomplete;
