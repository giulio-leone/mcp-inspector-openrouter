/** Centralized SVG icon strings — 16×16, uses currentColor for theme compat */
export declare const ICONS: {
    readonly wrench: string;
    readonly chat: string;
    readonly clipboard: string;
    readonly edit: string;
    readonly trash: string;
    readonly check: string;
    readonly x: string;
    readonly zap: string;
    readonly checkCircle: string;
    readonly xCircle: string;
    readonly alertTriangle: string;
    readonly refresh: string;
    readonly square: string;
    readonly skipForward: string;
    readonly chevronDown: string;
    readonly chevronRight: string;
    readonly lock: string;
    readonly unlock: string;
    readonly layers: string;
    readonly brain: string;
    readonly sliders: string;
};
