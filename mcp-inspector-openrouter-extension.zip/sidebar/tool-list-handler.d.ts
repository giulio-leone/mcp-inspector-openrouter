/**
 * Tool list handler — utility functions for tool data formatting.
 */
import type { CleanTool } from '../types';
/**
 * Generate copy-to-clipboard text formats.
 */
export declare function toolsAsScriptToolConfig(tools: CleanTool[]): string;
export declare function toolsAsJSON(tools: CleanTool[]): string;
