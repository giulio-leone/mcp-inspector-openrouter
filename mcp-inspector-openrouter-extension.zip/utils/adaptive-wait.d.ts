/**
 * AdaptiveWait — intelligent page load detection for tab operations.
 * Replaces hardcoded timeouts with event-driven detection.
 */
export interface AdaptiveWaitOptions {
    /** Maximum time to wait in ms (default: 10000) */
    readonly maxWaitMs: number;
    /** Minimum time to wait after tab status='complete' for SPA settling (default: 200) */
    readonly settleMs: number;
}
/**
 * Wait for a Chrome tab to finish loading using chrome.tabs.onUpdated.
 * Returns the elapsed time in ms.
 *
 * Strategy:
 * 1. Listen for tab status='complete' event
 * 2. After complete, wait an additional settleMs for SPA hydration
 * 3. If maxWaitMs exceeded, resolve anyway (never hang)
 */
export declare function waitForTabReady(tabId: number, options?: Partial<AdaptiveWaitOptions>): Promise<number>;
/**
 * Wait for a tab to be focused and ready after activation.
 * Replaces the hardcoded 300ms pause.
 *
 * Strategy:
 * 1. Check if tab is already active
 * 2. If not, listen for chrome.tabs.onActivated
 * 3. Then wait settleMs for rendering
 */
export declare function waitForTabFocus(tabId: number, options?: Partial<AdaptiveWaitOptions>): Promise<number>;
