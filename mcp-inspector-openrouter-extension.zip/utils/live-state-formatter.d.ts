/**
 * Human-readable live state formatter for AI system prompts.
 *
 * Pure function that converts a LiveStateSnapshot into a compact,
 * emoji-annotated string optimised for AI token budgets.
 */
import type { LiveStateSnapshot } from '../types/live-state.types';
/** Convert a LiveStateSnapshot into a compact, human-readable prompt block. */
export declare function formatLiveStateForPrompt(snapshot: LiveStateSnapshot): string;
