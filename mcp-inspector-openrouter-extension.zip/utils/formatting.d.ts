/**
 * Text formatting utilities extracted from chat-ui.js.
 * Markdown-to-HTML rendering for AI chat bubbles.
 */
/** Escape HTML special characters */
export declare function escapeHtml(text: string): string;
/** Truncate text to maxLen characters, appending ellipsis if truncated */
export declare function truncate(text: string, maxLen: number): string;
/** Inline formatting: bold, italic, inline code, links */
export declare function inlineFormat(text: string): string;
/**
 * Lightweight markdown → HTML renderer for AI chat bubbles.
 * Supports: headings, bold, italic, fenced code blocks, inline code,
 *           ordered/unordered lists, links, and paragraph breaks.
 */
export declare function formatAIText(text: string): string;
