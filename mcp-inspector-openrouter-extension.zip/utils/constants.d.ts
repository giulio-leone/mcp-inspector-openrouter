/**
 * Constants extracted from the JS source files.
 * Single source of truth for magic numbers, strings, and configuration.
 */
import type { SecurityTier, SecurityTierMap, ToolCategory, AIClassifierConfig } from '../types';
/** Maximum number of tools a single category scanner can emit */
export declare const MAX_TOOLS_PER_CATEGORY = 15;
/** Inference cache TTL in milliseconds (30 seconds) */
export declare const INFERENCE_CACHE_TTL = 30000;
/** Confidence threshold: below this tools are sent to AI classifier */
export declare const AI_CONFIDENCE_THRESHOLD = 0.7;
/** Minimum confidence: below this tools are discarded entirely */
export declare const MIN_CONFIDENCE = 0.5;
/** Security tier metadata definitions */
export declare const SECURITY_TIERS: SecurityTierMap;
/** Security tier enum values for convenience */
export declare const SecurityTierLevel: {
    readonly SAFE: SecurityTier;
    readonly NAVIGATION: SecurityTier;
    readonly MUTATION: SecurityTier;
};
/** All 13 scanner categories in priority order (specialized before generic) */
export declare const SCANNER_CATEGORIES: readonly ToolCategory[];
/** Default AI classifier configuration */
export declare const AI_CLASSIFIER_CONFIG: Readonly<AIClassifierConfig>;
/** OpenRouter API base URL */
export declare const OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1";
/** OpenRouter chat completions endpoint */
export declare const OPENROUTER_CHAT_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";
/** OpenRouter models list endpoint */
export declare const OPENROUTER_MODELS_ENDPOINT = "https://openrouter.ai/api/v1/models";
/** Default model for chat interactions */
export declare const DEFAULT_MODEL = "google/gemini-2.0-flash-001";
/** Default model for AI classifier (lightweight) */
export declare const DEFAULT_CLASSIFIER_MODEL = "google/gemini-2.0-flash-lite-001";
/** Default max output tokens for chat completions */
export declare const OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS = 65000;
/** Internal input budget cap used for local history trimming */
export declare const OPENROUTER_DEFAULT_MAX_INPUT_TOKENS = 1000000;
/** Max retained messages in chat history before additional input-budget trimming */
export declare const OPENROUTER_MAX_HISTORY_MESSAGES = 200;
/** localStorage key for conversation data */
export declare const STORAGE_KEY_CONVERSATIONS = "wmcp_conversations";
/** localStorage key for lock mode state */
export declare const STORAGE_KEY_LOCK_MODE = "wmcp_lock_mode";
/** localStorage key for OpenRouter API key */
export declare const STORAGE_KEY_API_KEY = "openrouter_api_key";
/** localStorage key for selected model */
export declare const STORAGE_KEY_MODEL = "openrouter_model";
/** Storage key for screenshot toggle */
export declare const STORAGE_KEY_SCREENSHOT_ENABLED = "wmcp_screenshot_enabled";
/** Storage key for plan mode toggle */
export declare const STORAGE_KEY_PLAN_MODE = "wmcp_plan_mode";
/** Key for YOLO mode (auto-execute all tools without confirmation) */
export declare const STORAGE_KEY_YOLO_MODE = "wmcp_yolo_mode";
/** Key for orchestrator mode (use hexagonal AgentOrchestrator instead of legacy tool-loop) */
export declare const STORAGE_KEY_ORCHESTRATOR_MODE = "wmcp_orchestrator_mode";
/** Debounce delay for DOM mutation observer (ms) */
export declare const DOM_OBSERVER_DEBOUNCE_MS = 300;
/** Debounce delay for SPA navigation detection (ms) */
export declare const SPA_NAVIGATION_DEBOUNCE_MS = 500;
/** Max retry attempts for empty AI responses */
export declare const AI_MAX_RETRIES = 3;
/** Delay between AI retry attempts (ms) */
export declare const AI_RETRY_DELAY_MS = 1000;
/** HTTP-Referer header for OpenRouter requests */
export declare const OPENROUTER_REFERER = "https://github.com/miguelspizza/webmcp";
/** X-Title header for OpenRouter requests */
export declare const OPENROUTER_TITLE = "Model Context Tool Inspector (OpenRouter)";
/** X-Title header for AI classifier requests */
export declare const AI_CLASSIFIER_TITLE = "WMCP AI Classifier";
/** Content scripts injected on install (bundled into single file by webpack) */
export declare const CONTENT_SCRIPTS: readonly string[];
/** Max products to extract from page context */
export declare const MAX_PAGE_CONTEXT_PRODUCTS = 20;
/** Shadow DOM max traversal depth */
export declare const SHADOW_DOM_MAX_DEPTH = 5;
