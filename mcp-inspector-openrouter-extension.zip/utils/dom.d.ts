/**
 * DOM utility functions extracted from content.js and wmcp-inference-engine.js.
 */
/** Check if an element is visible (not display:none, visibility:hidden, or opacity:0) */
export declare function isVisible(el: Element): boolean;
/**
 * Get an accessible label for an element.
 * Checks: aria-label → aria-labelledby → label[for] → title → placeholder →
 * data-placeholder → short textContent.
 */
export declare function getLabel(el: Element): string;
/** Convert text to a URL/tool-name-safe slug (max 64 chars) */
export declare function slugify(text: string): string;
/**
 * Traverse shadow DOM boundaries to query elements.
 * Searches up to `maxDepth` shadow roots deep.
 */
export declare function querySelectorDeep(root: Document | Element | ShadowRoot, selector: string, maxDepth?: number): Element[];
/**
 * Extract all form field name/value pairs from a form element.
 * Uses FormData for standard form serialization.
 * Password values are masked for security.
 */
export declare function getFormValues(form: HTMLFormElement): Record<string, string>;
