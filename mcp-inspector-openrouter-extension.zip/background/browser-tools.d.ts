/**
 * Browser control tools — executed in the background service worker.
 * These handle chrome.tabs and chrome.windows APIs.
 */
export interface BrowserToolResult {
    success: boolean;
    message: string;
    data?: unknown;
}
export declare function handleBrowserTool(action: string, args: Record<string, unknown>): Promise<BrowserToolResult>;
/** Check if a tool name is a browser tool */
export declare function isBrowserTool(name: string): boolean;
