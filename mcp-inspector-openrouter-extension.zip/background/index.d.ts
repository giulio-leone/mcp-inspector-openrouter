/**
 * Background service worker (Manifest V3).
 * Handles: side panel setup, content script injection, badge updates, AI classification bridge.
 */
export {};
