/**
 * Options page controller.
 * Manages API key, model selection, and connection testing.
 */
export {};
