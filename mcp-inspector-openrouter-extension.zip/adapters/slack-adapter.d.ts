/**
 * SlackAdapter — DOM-based adapter for Slack platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { ISlackPort } from '../ports/productivity.port';
export declare class SlackAdapter implements ISlackPort {
    isOnSlack(): boolean;
    sendMessage(text: string): Promise<void>;
    replyInThread(text: string): Promise<void>;
    addReaction(emoji: string): Promise<void>;
    editLastMessage(): Promise<void>;
    deleteLastMessage(): Promise<void>;
    switchChannel(channel: string): Promise<void>;
    searchMessages(query: string): Promise<void>;
    createChannel(name: string): Promise<void>;
    setStatus(status: string): Promise<void>;
    setAvailability(_available: boolean): Promise<void>;
    uploadFile(): Promise<void>;
    goToThreads(): Promise<void>;
    goToDMs(): Promise<void>;
    goToMentions(): Promise<void>;
}
