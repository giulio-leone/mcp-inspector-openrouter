/**
 * SemanticCrawlerAdapter — ICrawlerPort implementation for extension context.
 *
 * Crawls sites via fetch + DOMParser, extracts semantic tool definitions
 * from HTML (forms, buttons, inputs, links with aria/data attributes),
 * and stores results in the IToolCachePort.
 */
import type { ICrawlerPort, CrawlTarget, CrawlProgress, CrawlResult, CleanTool } from '../ports/crawler.port';
import type { IToolCachePort } from '../ports/tool-cache.port';
/** Convert a glob-like pattern to a RegExp */
export declare function globToRegex(pattern: string): RegExp;
/** Test if a URL matches any of the given glob patterns */
export declare function matchesPatterns(url: string, patterns: readonly string[]): boolean;
/** Extract same-origin internal links from parsed HTML */
export declare function extractInternalLinks(html: string, baseUrl: string): string[];
/** Extract semantic tool definitions from parsed HTML */
export declare function extractToolsFromHTML(html: string, _url: string): CleanTool[];
export declare class SemanticCrawlerAdapter implements ICrawlerPort {
    private readonly cache;
    private abortController;
    private running;
    constructor(cache: IToolCachePort);
    crawl(target: CrawlTarget, onProgress?: (p: CrawlProgress) => void): Promise<CrawlResult>;
    cancel(): void;
    isRunning(): boolean;
}
