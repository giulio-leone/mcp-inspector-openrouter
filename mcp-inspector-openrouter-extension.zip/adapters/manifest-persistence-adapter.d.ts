/**
 * ManifestPersistenceAdapter — IManifestPersistencePort implementation
 * using IndexedDB for persistent storage of SiteToolManifest data.
 *
 * Uses the `wmcp_manifests` object store with origin as key.
 */
import type { IManifestPersistencePort } from '../ports/manifest-persistence.port';
import type { SiteToolManifest } from '../ports/tool-manifest.port';
export declare class ManifestPersistenceAdapter implements IManifestPersistencePort {
    save(origin: string, manifest: SiteToolManifest): Promise<void>;
    load(origin: string): Promise<SiteToolManifest | null>;
    listOrigins(): Promise<string[]>;
    delete(origin: string): Promise<void>;
}
