/**
 * PlanningAdapter — IPlanningPort implementation wrapping PlanManager.
 *
 * Thin adapter that delegates to the existing PlanManager while
 * adding observer support for plan state changes.
 */
import type { IPlanningPort } from '../ports/planning.port';
import type { Plan, PlanStep } from '../ports/types';
import type { PlanManager } from '../sidebar/plan-manager';
export declare class PlanningAdapter implements IPlanningPort {
    private readonly planManager;
    private readonly listeners;
    constructor(planManager: PlanManager);
    createPlan(goal: string, steps: PlanStep[]): Plan;
    updatePlan(goal: string, steps: PlanStep[]): Plan;
    getCurrentPlan(): Plan | null;
    advanceStep(): void;
    markStepDone(detail?: string): void;
    markStepFailed(detail?: string): void;
    onPlanChanged(callback: (plan: Plan | null) => void): () => void;
    private notify;
}
