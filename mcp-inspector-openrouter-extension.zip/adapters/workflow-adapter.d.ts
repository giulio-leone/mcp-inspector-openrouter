/**
 * WorkflowAdapter — browser-safe adapter that executes workflow definitions
 * by walking their step list sequentially, emitting events, and honouring
 * the optional maxDurationMs timeout.
 *
 * Implements IWorkflowPort without pulling in any Node.js dependencies.
 */
import type { IWorkflowPort, WorkflowDef, WorkflowContextMap, WorkflowRunResult, WorkflowEventCallback } from '../ports/workflow.port';
export declare class WorkflowAdapter implements IWorkflowPort {
    private readonly listeners;
    execute(definition: WorkflowDef, context?: WorkflowContextMap): Promise<WorkflowRunResult>;
    onEvent(listener: WorkflowEventCallback): () => void;
    private emit;
}
