/**
 * TabDelegationAdapter — A2A delegation via chrome.tabs message passing.
 * Scores tabs by skill overlap and delegates tasks with timing.
 */
import type { ITabDelegationPort, TabAgent, TabDelegationResult } from '../ports/tab-delegation.port';
export declare class TabDelegationAdapter implements ITabDelegationPort {
    private readonly tabs;
    registerTab(tabId: number, url: string, title: string, skills: string[]): void;
    unregisterTab(tabId: number): void;
    /**
     * Scores each registered tab by the fraction of requiredSkills it covers.
     * Returns the tab with the highest overlap, or null if none match.
     */
    findTabForTask(requiredSkills: string[], excludeTabId?: number): TabAgent | null;
    delegate(sourceTabId: number, targetTabId: number, taskDescription: string): Promise<TabDelegationResult>;
    listRegisteredTabs(): readonly TabAgent[];
}
