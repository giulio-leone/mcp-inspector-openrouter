/**
 * GoogleDocsAdapter — DOM-based adapter for Google Docs platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { IGoogleDocsPort } from '../ports/productivity.port';
export declare class GoogleDocsAdapter implements IGoogleDocsPort {
    isOnGoogleDocs(): boolean;
    getDocTitle(): string;
    setDocTitle(title: string): Promise<void>;
    insertText(text: string): Promise<void>;
    formatBold(): Promise<void>;
    formatItalic(): Promise<void>;
    formatHeading(level: number): Promise<void>;
    insertLink(url: string): Promise<void>;
    addComment(text: string): Promise<void>;
    resolveComment(): Promise<void>;
    goToBeginning(): Promise<void>;
    goToEnd(): Promise<void>;
    findAndReplace(find: string, replace: string): Promise<void>;
    shareDoc(): Promise<void>;
    getShareLink(): string;
}
