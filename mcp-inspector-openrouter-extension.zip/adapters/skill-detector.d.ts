/**
 * Skill detector — infers tab capabilities from URL and page title.
 * Used by the orchestrator to auto-register tabs with the delegation adapter.
 */
export interface SkillDetectionResult {
    readonly skills: readonly string[];
    readonly platform: string;
    readonly confidence: number;
}
export declare function detectSkills(url: string, _title: string): SkillDetectionResult;
