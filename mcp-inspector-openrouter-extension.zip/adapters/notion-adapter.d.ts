/**
 * NotionAdapter — DOM-based adapter for Notion platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { INotionPort } from '../ports/productivity.port';
export declare class NotionAdapter implements INotionPort {
    isOnNotion(): boolean;
    createPage(title: string, _parentId?: string): Promise<void>;
    duplicatePage(): Promise<void>;
    deletePage(): Promise<void>;
    addBlock(type: 'text' | 'heading' | 'todo' | 'bullet' | 'code', content: string): Promise<void>;
    toggleTodo(): Promise<void>;
    addDatabaseRow(): Promise<void>;
    filterDatabase(property: string, value: string): Promise<void>;
    sortDatabase(property: string, _direction: 'asc' | 'desc'): Promise<void>;
    searchPages(query: string): Promise<void>;
    goToPage(title: string): Promise<void>;
    toggleSidebar(): Promise<void>;
}
