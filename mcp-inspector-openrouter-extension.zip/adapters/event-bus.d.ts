/**
 * TypedEventBus — Generic, type-safe event bus with wildcard and once support.
 *
 * Provides a strongly typed publish/subscribe mechanism for decoupled
 * communication between components. Listeners are snapshot-copied before
 * iteration so that unsubscribes during emit never skip siblings.
 */
/** Listener for a specific event type */
type EventListener<T> = (data: T) => void;
/** Listener for the wildcard `*` — receives every event */
type WildcardListener = (type: string, data: unknown) => void;
export declare class TypedEventBus<T extends {
    [K in keyof T]: unknown;
}> {
    private readonly listeners;
    /**
     * Subscribe to a specific event type.
     * Returns an unsubscribe function.
     */
    on<K extends keyof T>(type: K, listener: EventListener<T[K]>): () => void;
    /** Subscribe to all events via wildcard. */
    on(type: '*', listener: WildcardListener): () => void;
    /**
     * Subscribe to a single occurrence of an event type.
     * The listener is automatically removed after the first match.
     */
    once<K extends keyof T>(type: K, listener: EventListener<T[K]>): () => void;
    /**
     * Emit an event. Listeners are snapshot-copied before iteration so
     * that unsubscribes during emit never cause other listeners to be skipped.
     */
    emit<K extends keyof T>(type: K, ...args: T[K] extends undefined ? [] : [T[K]]): void;
    /** Remove all listeners. */
    dispose(): void;
    /**
     * Return the number of listeners for a specific type, or the total
     * across all types when called without arguments.
     */
    listenerCount(type?: keyof T | '*'): number;
}
export {};
