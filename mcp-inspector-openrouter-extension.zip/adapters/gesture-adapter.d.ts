/**
 * GestureAdapter — platform-agnostic touch gesture execution engine.
 * Dispatches realistic TouchEvent sequences for swipe, scroll, pinch, and long press.
 */
import type { IGesturePort, SwipeDirection, ScrollDirection } from '../ports/gesture.port';
export declare class GestureAdapter implements IGesturePort {
    swipe(direction: SwipeDirection, element?: HTMLElement): Promise<void>;
    scroll(direction: ScrollDirection, distance?: number): Promise<void>;
    pinch(scale: number, element?: HTMLElement): Promise<void>;
    longPress(element: HTMLElement, duration?: number): Promise<void>;
}
