/**
 * ProductivityAdapter — composite adapter for productivity platform detection
 * and interaction. Delegates to platform-specific adapters.
 */
import type { IProductivityPort, ProductivityPlatform } from '../ports/productivity.port';
import { NotionAdapter } from './notion-adapter';
import { GitHubAdapter } from './github-adapter';
import { GoogleDocsAdapter } from './google-docs-adapter';
import { TrelloAdapter } from './trello-adapter';
import { SlackAdapter } from './slack-adapter';
export declare class ProductivityAdapter implements IProductivityPort {
    readonly notion: NotionAdapter;
    readonly github: GitHubAdapter;
    readonly googleDocs: GoogleDocsAdapter;
    readonly trello: TrelloAdapter;
    readonly slack: SlackAdapter;
    constructor();
    detectPlatform(): ProductivityPlatform;
    isProductivityApp(): boolean;
}
