/**
 * EcommerceAdapter — DOM-based adapter for e-commerce platform interactions.
 * Supports Shopify, WooCommerce, Wix, and Webflow with platform-specific selectors.
 */
import type { IEcommercePort, EcommercePlatform, ProductInfo, CartItem, OrderSummary, OrderDetails, OrderTracking, InventoryItem, ProductCreateData } from '../ports/ecommerce.port';
/** Throw if value is empty or whitespace-only. */
export declare function requireNonEmpty(value: string, paramName: string): string;
export declare class EcommerceAdapter implements IEcommercePort {
    detectPlatform(): EcommercePlatform;
    isEcommerce(): boolean;
    getProductInfo(): Promise<ProductInfo | null>;
    addToCart(quantity?: number, variant?: string): Promise<void>;
    selectVariant(variant: string): Promise<void>;
    setQuantity(qty: number): Promise<void>;
    viewCart(): Promise<void>;
    getCartItems(): Promise<CartItem[]>;
    removeFromCart(itemName: string): Promise<void>;
    updateCartQuantity(itemName: string, quantity: number): Promise<void>;
    goToCheckout(): Promise<void>;
    searchProducts(query: string): Promise<void>;
    filterByCategory(category: string): Promise<void>;
    sortProducts(by: 'price-asc' | 'price-desc' | 'newest' | 'popular'): Promise<void>;
    isAdminPage(): boolean;
    getOrders(): Promise<OrderSummary[]>;
    getOrderDetails(orderId: string): Promise<OrderDetails | null>;
    trackOrder(orderId: string): Promise<OrderTracking | null>;
    getInventoryStatus(): Promise<InventoryItem[]>;
    updateInventory(productId: string, quantity: number): Promise<void>;
    createProduct(data: ProductCreateData): Promise<void>;
    updateProduct(productId: string, data: Partial<ProductCreateData>): Promise<void>;
    deleteProduct(productId: string): Promise<void>;
}
