/**
 * ContextManager — manages context window budget via tool-result
 * offloading and token tracking.
 *
 * Large tool results are replaced with a truncated preview and a
 * reference ID that can be used to retrieve the full content later.
 * Token usage is tracked cumulatively across request/response cycles.
 */
import type { IContextManagerPort } from '../ports/context-manager.port';
import type { TokenUsage } from '../ports/types';
export interface ContextManagerConfig {
    /** Max tokens for a single tool result before offloading (default: 5000) */
    readonly offloadThreshold: number;
    /** Max chars to keep inline when offloading (default: 500) */
    readonly offloadPreviewChars: number;
}
export declare class ContextManager implements IContextManagerPort {
    private readonly config;
    private inputTokens;
    private outputTokens;
    private counter;
    /** Map of offloaded content by reference ID */
    private readonly offloaded;
    constructor(config?: Partial<ContextManagerConfig>);
    /**
     * Process a tool result string. If it exceeds offloadThreshold,
     * store the full content and return a truncated preview.
     * Otherwise return the original string.
     */
    processToolResult(toolName: string, result: string): string;
    /** Retrieve an offloaded result by its reference ID */
    getOffloaded(refId: string): string | undefined;
    /** Track token usage for a request/response cycle */
    trackUsage(inputTokens: number, outputTokens: number): void;
    /** Estimate tokens for a string (4 chars per token) */
    estimateTokens(text: string): number;
    /** Get cumulative token usage */
    getUsage(): TokenUsage;
    /** Reset all state (offloaded content, usage counters) */
    reset(): void;
}
