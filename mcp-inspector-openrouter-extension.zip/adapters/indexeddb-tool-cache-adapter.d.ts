/**
 * IndexedDBToolCacheAdapter — IToolCachePort implementation using IndexedDB.
 *
 * Stores per-site WebMCP manifests with URL pattern matching.
 * Supports incremental diff updates to avoid full rescans.
 */
import type { IToolCachePort, SiteManifest, ToolDiff } from '../ports/tool-cache.port';
import type { CleanTool } from '../types';
import { urlToPattern } from 'onegenui-deep-agents/scraping';
export { urlToPattern };
/** Hash a tools array for quick diff comparison (includes confidence). */
export declare function hashTools(tools: readonly CleanTool[]): string;
/** Extract site origin from a URL. */
export declare function extractSite(url: string): string;
export declare class IndexedDBToolCacheAdapter implements IToolCachePort {
    private readonly ttlMs;
    constructor(options?: {
        ttlMs?: number;
    });
    get(site: string, url: string): Promise<readonly CleanTool[] | null>;
    put(site: string, url: string, tools: readonly CleanTool[]): Promise<void>;
    getManifest(site: string): Promise<SiteManifest | null>;
    diff(site: string, url: string, liveTools: readonly CleanTool[]): Promise<ToolDiff>;
    applyDiff(site: string, url: string, diff: ToolDiff): Promise<void>;
    invalidate(site: string, url: string): Promise<void>;
    invalidateSite(site: string): Promise<void>;
    clear(): Promise<void>;
}
