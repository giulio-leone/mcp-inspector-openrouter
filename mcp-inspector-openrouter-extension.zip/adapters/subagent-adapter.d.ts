/**
 * SubagentAdapter — ISubagentPort implementation for browser-based child agents.
 *
 * Manages lightweight subagent tasks with AbortController-based cancellation,
 * configurable depth limits, and timeout enforcement. Subagent execution is
 * delegated to the IAgentPort provided at construction time, enabling
 * recursive agent composition without circular dependencies.
 */
import type { ISubagentPort } from '../ports/subagent.port';
import type { IAgentPort } from '../ports/agent.port';
import type { SubagentInfo, SubagentResult, SubagentTask } from '../ports/types';
export interface SubagentLimits {
    /** Maximum concurrent subagents (default: 3). */
    readonly maxConcurrent?: number;
    /** Default timeout per subagent in ms (default: 30 000). */
    readonly defaultTimeoutMs?: number;
    /** Maximum recursion depth (default: 2). */
    readonly maxDepth?: number;
}
export declare class SubagentAdapter implements ISubagentPort {
    private readonly agentFactory;
    private readonly active;
    private readonly maxDepth;
    private readonly maxConcurrent;
    private readonly defaultTimeoutMs;
    constructor(agentFactory: () => IAgentPort, limits?: SubagentLimits);
    spawn(task: SubagentTask): Promise<SubagentResult>;
    getActiveSubagents(): readonly SubagentInfo[];
    cancel(subagentId: string): Promise<void>;
    private updateStatus;
}
