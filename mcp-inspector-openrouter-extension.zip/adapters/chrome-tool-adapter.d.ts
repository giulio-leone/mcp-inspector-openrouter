/**
 * ChromeToolAdapter — IToolExecutionPort implementation for Chrome Extension.
 *
 * Routes tool calls through chrome.tabs.sendMessage (content tools) and
 * chrome.runtime.sendMessage (browser tools), translating between the
 * hexagonal port contract and Chrome Extension messaging.
 */
import type { IToolExecutionPort } from '../ports/tool-execution.port';
import type { ToolCallResult, ToolDefinition, ToolTarget } from '../ports/types';
export declare class ChromeToolAdapter implements IToolExecutionPort {
    execute(toolName: string, args: Record<string, unknown>, target: ToolTarget): Promise<ToolCallResult>;
    getAvailableTools(tabId: number): Promise<readonly ToolDefinition[]>;
    onToolsChanged(callback: (tools: readonly ToolDefinition[]) => void): () => void;
    private executeBrowserTool;
    private executeContentTool;
}
