/**
 * TrelloAdapter — DOM-based adapter for Trello platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { ITrelloPort } from '../ports/productivity.port';
export declare class TrelloAdapter implements ITrelloPort {
    isOnTrello(): boolean;
    createCard(title: string): Promise<void>;
    moveCard(listName: string): Promise<void>;
    archiveCard(): Promise<void>;
    addLabel(label: string): Promise<void>;
    addComment(text: string): Promise<void>;
    assignMember(member: string): Promise<void>;
    setDueDate(date: string): Promise<void>;
    createList(name: string): Promise<void>;
    archiveList(): Promise<void>;
    searchCards(query: string): Promise<void>;
    filterByLabel(label: string): Promise<void>;
    filterByMember(member: string): Promise<void>;
}
