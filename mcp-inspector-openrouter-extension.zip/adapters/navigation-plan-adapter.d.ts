/**
 * NavigationPlanAdapter — manages navigation plan state and step progression.
 * Handles plan creation, step advancement with retry/skip/abort strategies,
 * and template resolution for data interpolation between steps.
 */
import type { INavigationPlanPort, NavigationPlan, NavigationStep, PlanExecutionState, StepResult } from '../ports/navigation-plan.port';
/** Replaces ${dataKey} placeholders with data from previous step results */
export declare function resolveTemplate(value: string, results: readonly StepResult[]): string;
export declare class NavigationPlanAdapter implements INavigationPlanPort {
    private plan;
    private state;
    createPlan(description: string, steps: readonly NavigationStep[]): NavigationPlan;
    getState(): PlanExecutionState | null;
    getCurrentStep(): NavigationStep | null;
    advanceStep(result: StepResult): void;
    abort(_reason: string): void;
    reset(): void;
}
