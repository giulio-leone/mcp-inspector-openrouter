/**
 * InstagramAdapter — DOM-based adapter for Instagram platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { IInstagramPort, InstagramSection } from '../ports/instagram.port';
import type { IGesturePort } from '../ports/gesture.port';
/** Check whether the current page is Instagram */
export declare function isInstagram(): boolean;
export declare class InstagramAdapter implements IInstagramPort {
    private readonly gesture;
    constructor(gesture?: IGesturePort);
    viewStory(username: string): Promise<void>;
    nextStory(): Promise<void>;
    previousStory(): Promise<void>;
    replyToStory(message: string): Promise<void>;
    likePost(): Promise<void>;
    unlikePost(): Promise<void>;
    savePost(): Promise<void>;
    unsavePost(): Promise<void>;
    commentOnPost(text: string): Promise<void>;
    sharePost(username: string): Promise<void>;
    scrollFeed(direction: 'up' | 'down'): Promise<void>;
    likeReel(): Promise<void>;
    commentOnReel(text: string): Promise<void>;
    nextReel(): Promise<void>;
    shareReel(username: string): Promise<void>;
    swipeToNextReel(): Promise<void>;
    swipeToPreviousReel(): Promise<void>;
    scrollReels(count?: number): Promise<void>;
    swipeNextStory(): Promise<void>;
    swipePreviousStory(): Promise<void>;
    openCommentComposer(): Promise<void>;
    replyToComment(text: string): Promise<void>;
    loadMoreComments(): Promise<void>;
    sendDM(username: string, message: string): Promise<void>;
    openConversation(username: string): Promise<void>;
    followUser(username: string): Promise<void>;
    unfollowUser(username: string): Promise<void>;
    goToExplore(): Promise<void>;
    goToReels(): Promise<void>;
    goToProfile(username?: string): Promise<void>;
    searchUser(query: string): Promise<void>;
    isOnInstagram(): boolean;
    getCurrentSection(): InstagramSection;
}
