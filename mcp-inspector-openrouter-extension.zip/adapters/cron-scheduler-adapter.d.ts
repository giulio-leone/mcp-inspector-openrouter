/**
 * CronSchedulerAdapter — Implements ICronSchedulerPort using Chrome Alarms API.
 * Delegates task execution to IBackgroundTaskPort (Dependency Inversion).
 */
import { TypedEventBus } from './event-bus';
import type { ICronSchedulerPort, CronSchedule, CronEventMap, ScheduleOptions } from '../ports/cron-scheduler.port';
import type { IBackgroundTaskPort } from '../ports/background-task.port';
export declare class CronSchedulerAdapter implements ICronSchedulerPort {
    private readonly backgroundTask;
    readonly eventBus: TypedEventBus<CronEventMap>;
    private readonly schedules;
    private readonly callbacks;
    constructor(backgroundTask: IBackgroundTaskPort);
    schedule(options: ScheduleOptions): string;
    cancel(scheduleId: string): boolean;
    getSchedule(scheduleId: string): CronSchedule | undefined;
    listSchedules(): readonly CronSchedule[];
    dispose(): void;
    private readonly handleAlarm;
}
