/**
 * TabSessionAdapter — manages multi-tab session context.
 * Accumulates data extracted from each tab during a workflow,
 * making it available for AI context injection.
 */
import type { ITabSessionPort, TabContext } from '../ports/tab-session.port';
export declare class TabSessionAdapter implements ITabSessionPort {
    private sessionId;
    private readonly contexts;
    startSession(): string;
    setTabContext(tabId: number, context: Omit<TabContext, 'tabId' | 'timestamp'>): void;
    storeData(tabId: number, key: string, value: unknown): void;
    getTabContext(tabId: number): TabContext | undefined;
    getAllContexts(): readonly TabContext[];
    buildContextSummary(): string;
    endSession(): void;
    getSessionId(): string | null;
}
