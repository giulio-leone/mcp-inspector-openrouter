/**
 * BackgroundTaskAdapter — Implements IBackgroundTaskPort with TypedEventBus integration.
 * Tasks are enqueued and executed asynchronously with timeout support.
 */
import { TypedEventBus } from './event-bus';
import type { IBackgroundTaskPort, BackgroundTask, BackgroundTaskEventMap, EnqueueOptions } from '../ports/background-task.port';
export declare class BackgroundTaskAdapter implements IBackgroundTaskPort {
    readonly eventBus: TypedEventBus<BackgroundTaskEventMap>;
    private readonly tasks;
    private readonly timers;
    /** Reject handles to settle timeout promises eagerly on cancel/dispose */
    private readonly abortHandles;
    private readonly maxConcurrent;
    constructor(limits?: {
        maxConcurrent?: number;
    });
    enqueue(options: EnqueueOptions): string;
    cancel(taskId: string): boolean;
    getTask(taskId: string): BackgroundTask | undefined;
    listTasks(): readonly BackgroundTask[];
    dispose(): void;
    private clearTimer;
    private executeTask;
}
