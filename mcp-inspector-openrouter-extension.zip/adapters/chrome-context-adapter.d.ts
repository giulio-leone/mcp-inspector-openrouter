/**
 * ChromeContextAdapter — IContextPort implementation for Chrome Extension.
 *
 * Bridges page context (via chrome.tabs.sendMessage), conversation history
 * (via chat-store), and live state (embedded in PageContext) into the
 * hexagonal port contract.
 */
import type { IContextPort } from '../ports/context.port';
import type { ContextSummary, LiveStateSnapshot, Message, PageContext } from '../ports/types';
export interface ChromeContextAdapterConfig {
    /** Current site key for chat-store lookups */
    readonly site: string;
    /** Current conversation ID */
    readonly conversationId: string;
}
export declare class ChromeContextAdapter implements IContextPort {
    private lastPageContext;
    private config;
    constructor(config: ChromeContextAdapterConfig);
    /** Update the active site/conversation coordinates */
    setConfig(config: ChromeContextAdapterConfig): void;
    getPageContext(tabId: number): Promise<PageContext | null>;
    getLiveState(): LiveStateSnapshot | null;
    getConversationHistory(): readonly Message[];
    summarizeIfNeeded(messages: readonly Message[], tokenBudget: number): Promise<ContextSummary>;
}
