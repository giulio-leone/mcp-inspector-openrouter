/**
 * ApprovalGateAdapter — decorator wrapping IToolExecutionPort.
 *
 * Intercepts Tier 2 (mutation) tool calls, requesting user approval
 * before execution. Implements both IToolExecutionPort and IApprovalGatePort,
 * following the Decorator pattern (OCP: extend behavior without modifying original).
 */
import type { IToolExecutionPort } from '../ports/tool-execution.port';
import type { IApprovalGatePort, ApprovalDecision, ApprovalRequest } from '../ports/approval-gate.port';
import type { ToolCallResult, ToolDefinition, ToolTarget } from '../ports/types';
export type ApprovalCallback = (request: ApprovalRequest) => Promise<ApprovalDecision>;
export type TierResolver = (toolName: string) => number;
export declare class ApprovalGateAdapter implements IToolExecutionPort, IApprovalGatePort {
    private readonly inner;
    private readonly resolveTier;
    private readonly onApprovalNeeded;
    private autoApprove;
    constructor(inner: IToolExecutionPort, resolveTier: TierResolver, onApprovalNeeded: ApprovalCallback);
    execute(toolName: string, args: Record<string, unknown>, target: ToolTarget): Promise<ToolCallResult>;
    getAvailableTools(tabId: number): Promise<readonly ToolDefinition[]>;
    onToolsChanged(callback: (tools: readonly ToolDefinition[]) => void): () => void;
    requestApproval(request: ApprovalRequest): Promise<ApprovalDecision>;
    setAutoApprove(enabled: boolean): void;
    isAutoApprove(): boolean;
}
