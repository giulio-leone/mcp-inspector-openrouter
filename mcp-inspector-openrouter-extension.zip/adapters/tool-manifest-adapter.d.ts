/**
 * ToolManifestAdapter — Thin wrapper around OneCrawl's SemanticScrapingAdapter.
 *
 * Adapts CleanTool (Chrome extension–specific) ↔ SemanticTool (generic)
 * while delegating all manifest logic to the shared OneCrawl implementation.
 */
import type { IToolManifestPort, SiteToolManifest, ManifestTool } from '../ports/tool-manifest.port';
import type { CleanTool } from '../types';
export declare class ToolManifestAdapter implements IToolManifestPort {
    private readonly inner;
    getManifest(origin: string): SiteToolManifest | null;
    updatePage(origin: string, url: string, tools: CleanTool[]): SiteToolManifest;
    applyDiff(origin: string, url: string, added: CleanTool[], removed: string[]): SiteToolManifest;
    toMCPJson(origin: string): string;
    getToolsForUrl(origin: string, url: string): ManifestTool[];
}
