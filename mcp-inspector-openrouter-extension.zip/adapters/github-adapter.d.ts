/**
 * GitHubAdapter — DOM-based adapter for GitHub platform interactions.
 * Uses resilient selector strategies with multiple fallbacks.
 */
import type { IGitHubPort } from '../ports/productivity.port';
export declare class GitHubAdapter implements IGitHubPort {
    isOnGitHub(): boolean;
    starRepo(): Promise<void>;
    unstarRepo(): Promise<void>;
    forkRepo(): Promise<void>;
    createIssue(title: string, _body?: string): Promise<void>;
    closeIssue(): Promise<void>;
    reopenIssue(): Promise<void>;
    addComment(text: string): Promise<void>;
    addLabel(label: string): Promise<void>;
    approvePR(): Promise<void>;
    requestChanges(comment: string): Promise<void>;
    mergePR(): Promise<void>;
    goToIssues(): Promise<void>;
    goToPullRequests(): Promise<void>;
    goToActions(): Promise<void>;
    searchRepo(query: string): Promise<void>;
    toggleFileView(): Promise<void>;
    copyPermalink(): Promise<void>;
}
