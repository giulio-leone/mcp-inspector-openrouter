/**
 * AgentOrchestrator — IAgentPort implementation wiring all hexagonal adapters.
 *
 * Replaces the manual tool-loop pattern with a structured agent that:
 *  1. Sends user prompt to AI via OpenRouterChat
 *  2. Processes tool calls through IToolExecutionPort
 *  3. Manages plans through IPlanningPort
 *  4. Provides context awareness through IContextPort
 *  5. Supports recursive subagent spawning through ISubagentPort
 */
import type { IAgentPort } from '../ports/agent.port';
import type { IToolExecutionPort } from '../ports/tool-execution.port';
import type { IPlanningPort } from '../ports/planning.port';
import type { IContextPort } from '../ports/context.port';
import type { IContextManagerPort } from '../ports/context-manager.port';
import type { ITabSessionPort } from '../ports/tab-session.port';
import type { ISubagentPort } from '../ports/subagent.port';
import type { ITabDelegationPort } from '../ports/tab-delegation.port';
import type { AgentContext, AgentResult, ToolDefinition, OrchestratorEventListener, AgentEventMap } from '../ports/types';
import { TypedEventBus } from './event-bus';
import type { OpenRouterChat } from '../services/adapters';
import type { ChatConfig } from '../services/adapters/openrouter';
import type { PageContext, ContentPart } from '../types';
export interface OrchestratorLimits {
    /** Maximum tool-loop iterations per run (0 = unlimited, default: 0). */
    readonly maxIterations?: number;
    /** Global loop timeout in ms (0 = unlimited, default: 0). */
    readonly loopTimeoutMs?: number;
}
export interface OrchestratorDeps {
    readonly toolPort: IToolExecutionPort;
    readonly contextPort: IContextPort;
    readonly planningPort: IPlanningPort;
    readonly contextManager?: IContextManagerPort;
    readonly tabSession?: ITabSessionPort;
    readonly subagentPort?: ISubagentPort;
    readonly delegation?: ITabDelegationPort;
    readonly depth?: number;
    readonly limits?: OrchestratorLimits;
    readonly chatFactory: () => OpenRouterChat;
    readonly buildConfig: (ctx: PageContext | null, tools: readonly ToolDefinition[]) => ChatConfig;
}
export declare class AgentOrchestrator implements IAgentPort {
    private readonly deps;
    private chat;
    /** Typed event bus for granular subscriptions. */
    readonly eventBus: TypedEventBus<AgentEventMap>;
    constructor(deps: OrchestratorDeps);
    /**
     * Subscribe to orchestrator events (legacy API).
     * Internally delegates to the typed event bus.
     * Returns an unsubscribe function.
     */
    onEvent(listener: OrchestratorEventListener): () => void;
    run(prompt: string | ContentPart[], context: AgentContext): Promise<AgentResult>;
    dispose(): Promise<void>;
    private buildResult;
    private toToolResponse;
}
