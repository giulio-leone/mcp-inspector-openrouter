/**
 * OpenRouterChat — stateful chat with history and streaming support.
 */
import type { ChatMessage, ChatSendResponse } from '../../../types';
import type { ChatSendParams, StreamChunk } from './types';
export declare class OpenRouterChat {
    private readonly apiKey;
    model: string;
    history: ChatMessage[];
    constructor(apiKey: string, model: string);
    /**
     * Trim history to keep the last N user/assistant/tool messages,
     * preventing unbounded token growth.
     */
    trimHistory(maxMessages?: number): void;
    private trimHistoryByInputBudget;
    private resolveMaxInputTokens;
    /** Append user or tool messages to history based on message type */
    private appendIncomingMessages;
    /** Build the request body for the API call */
    private buildRequestBody;
    sendMessage(params: ChatSendParams): Promise<ChatSendResponse>;
    /**
     * Send a message and stream the response token-by-token via SSE.
     * Yields StreamChunk objects; the final chunk has `done: true`.
     */
    sendMessageStreaming(params: ChatSendParams): AsyncGenerator<StreamChunk>;
}
