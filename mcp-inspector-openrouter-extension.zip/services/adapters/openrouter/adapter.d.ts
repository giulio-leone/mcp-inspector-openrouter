/**
 * OpenRouter AI provider adapter — implements IAIProvider.
 */
import type { IAIProvider } from '../../ports';
import type { AIModel, AIProviderConfig, AIResponse, ChatMessage, Tool } from '../../../types';
export declare class OpenRouterAdapter implements IAIProvider {
    private readonly apiKey;
    private readonly model;
    constructor(config: AIProviderConfig);
    sendMessage(messages: readonly ChatMessage[], tools?: readonly Tool[]): Promise<AIResponse>;
    listModels(): Promise<readonly AIModel[]>;
}
