import type { FunctionDeclaration, Tool, ToolDeclaration } from '../../../types';
export declare const DEFAULT_TEMPERATURE = 0.7;
export declare const DEFAULT_MAX_TOKENS = 65000;
export declare const DEFAULT_MAX_INPUT_TOKENS = 1000000;
export declare const MAX_HISTORY_MESSAGES = 200;
export declare function buildHeaders(apiKey: string): Record<string, string>;
export declare function formatToolDeclarations(tools: readonly Tool[]): ToolDeclaration[];
export declare function formatFunctionDeclarations(decls: readonly FunctionDeclaration[]): ToolDeclaration[];
/** Parse a raw API error body and throw a typed error */
export declare function throwApiError(res: Response): Promise<never>;
/** Safe JSON.parse for tool call arguments; returns empty object on failure */
export declare function safeParseArguments(raw: string, toolCallId: string, fnName: string): Record<string, unknown>;
export declare function delay(ms: number): Promise<void>;
/** Execute a fetch with exponential backoff on rate-limit errors */
export declare function fetchWithBackoff(url: string, init: RequestInit): Promise<Response>;
