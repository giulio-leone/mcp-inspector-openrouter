import type { ChatMessage } from '../../../types';
import type { StreamChunk } from './types';
/**
 * Parse an SSE stream from the OpenRouter API, yielding StreamChunk objects.
 * Appends the final assistant message to the provided history array.
 */
export declare function parseSSEStream(reader: ReadableStreamDefaultReader<Uint8Array>, history: ChatMessage[]): AsyncGenerator<StreamChunk>;
