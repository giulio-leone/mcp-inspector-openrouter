/** Base class for OpenRouter API errors */
export declare class OpenRouterError extends Error {
    readonly statusCode: number;
    constructor(message: string, statusCode: number);
}
/** Thrown when the API key is invalid or missing (401/403) */
export declare class AuthenticationError extends OpenRouterError {
    constructor(message: string, statusCode: number);
}
/** Thrown when rate-limited by the API (429) */
export declare class RateLimitError extends OpenRouterError {
    readonly retryAfterMs?: number | undefined;
    constructor(message: string, retryAfterMs?: number | undefined);
}
/** Thrown for model-specific errors (invalid model, context length exceeded) */
export declare class ModelError extends OpenRouterError {
    constructor(message: string, statusCode: number);
}
