/**
 * Chrome Messenger adapter — implements IMessenger using chrome.runtime / chrome.tabs.
 */
import type { IMessenger } from '../ports';
import type { ExtensionMessage } from '../../types';
export declare class ChromeMessengerAdapter implements IMessenger {
    sendToBackground(message: ExtensionMessage): Promise<unknown>;
    sendToTab(tabId: number, message: ExtensionMessage): Promise<unknown>;
    onMessage(handler: (message: ExtensionMessage, sender: chrome.runtime.MessageSender) => void | Promise<unknown>): void;
}
