/**
 * Chrome Storage adapter — implements IStorage using chrome.storage.local.
 */
import type { IStorage } from '../ports';
export declare class ChromeStorageAdapter implements IStorage {
    get<T>(key: string): Promise<T | null>;
    set<T>(key: string, value: T): Promise<void>;
    remove(key: string): Promise<void>;
}
