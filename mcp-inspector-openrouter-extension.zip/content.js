/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/adapters/indexeddb-tool-cache-adapter.ts":
/*!******************************************************!*\
  !*** ./src/adapters/indexeddb-tool-cache-adapter.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IndexedDBToolCacheAdapter: () => (/* binding */ IndexedDBToolCacheAdapter),
/* harmony export */   extractSite: () => (/* binding */ extractSite),
/* harmony export */   hashTools: () => (/* binding */ hashTools),
/* harmony export */   urlToPattern: () => (/* reexport safe */ onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__.urlToPattern)
/* harmony export */ });
/* harmony import */ var onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! onegenui-deep-agents/scraping */ "../onecrawl/dist/scraping/index.js");
/**
 * IndexedDBToolCacheAdapter — IToolCachePort implementation using IndexedDB.
 *
 * Stores per-site WebMCP manifests with URL pattern matching.
 * Supports incremental diff updates to avoid full rescans.
 */


const DB_NAME = 'webmcp-tool-cache';
const DB_VERSION = 1;
const STORE_NAME = 'manifests';
/** Default cache TTL: 24 hours */
const DEFAULT_TTL_MS = 24 * 60 * 60 * 1000;
/** Hash a tools array for quick diff comparison (includes confidence). */
function hashTools(tools) {
    const keys = tools
        .map((t) => `${t.name}:${t.confidence ?? 0}:${t.description ?? ''}:${JSON.stringify(t.inputSchema ?? {})}`)
        .sort();
    let h = 0;
    const s = keys.join('|');
    for (let i = 0; i < s.length; i++) {
        h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    }
    return h.toString(36);
}
/** Extract site origin from a URL. */
function extractSite(url) {
    try {
        return new URL(url).hostname;
    }
    catch {
        return url;
    }
}
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'site' });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
class IndexedDBToolCacheAdapter {
    ttlMs;
    constructor(options) {
        this.ttlMs = options?.ttlMs ?? DEFAULT_TTL_MS;
    }
    async get(site, url) {
        const manifest = await this.getManifest(site);
        if (!manifest)
            return null;
        const pattern = (0,onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__.urlToPattern)(url);
        const page = manifest.pages[pattern];
        if (!page)
            return null;
        if (Date.now() - page.scannedAt > this.ttlMs)
            return null;
        return page.tools;
    }
    async put(site, url, tools) {
        const pattern = (0,onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__.urlToPattern)(url);
        const hash = hashTools(tools);
        const now = Date.now();
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            const getReq = store.get(site);
            getReq.onsuccess = () => {
                const existing = getReq.result;
                const manifest = existing
                    ? { ...existing, version: existing.version + 1, pages: { ...existing.pages } }
                    : { site, version: 1, lastFullScan: now, pages: {} };
                manifest.pages[pattern] = {
                    pattern, tools, hash, scannedAt: now,
                };
                store.put(manifest);
            };
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
    async getManifest(site) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).get(site);
            req.onsuccess = () => { db.close(); resolve(req.result ?? null); };
            req.onerror = () => { db.close(); reject(req.error); };
        });
    }
    async diff(site, url, liveTools) {
        const cached = await this.get(site, url);
        if (!cached) {
            return { added: liveTools, removed: [], changed: [], unchanged: 0 };
        }
        const cachedMap = new Map(cached.map((t) => [t.name, t]));
        const liveMap = new Map(liveTools.map((t) => [t.name, t]));
        const added = [];
        const changed = [];
        const removed = [];
        for (const [name, tool] of liveMap) {
            const prev = cachedMap.get(name);
            if (!prev) {
                added.push(tool);
            }
            else if (hashTools([prev]) !== hashTools([tool])) {
                changed.push(tool);
            }
        }
        for (const name of cachedMap.keys()) {
            if (!liveMap.has(name))
                removed.push(name);
        }
        const unchanged = liveTools.length - added.length - changed.length;
        return { added, removed, changed, unchanged };
    }
    async applyDiff(site, url, diff) {
        const cached = await this.get(site, url);
        if (!cached) {
            await this.put(site, url, [...diff.added, ...diff.changed]);
            return;
        }
        const removedSet = new Set(diff.removed);
        const changedMap = new Map(diff.changed.map((t) => [t.name, t]));
        const merged = cached
            .filter((t) => !removedSet.has(t.name))
            .map((t) => changedMap.get(t.name) ?? t);
        const existingNames = new Set(merged.map((t) => t.name));
        for (const tool of diff.added) {
            if (!existingNames.has(tool.name))
                merged.push(tool);
        }
        await this.put(site, url, merged);
    }
    async invalidate(site, url) {
        const pattern = (0,onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__.urlToPattern)(url);
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            const getReq = store.get(site);
            getReq.onsuccess = () => {
                const manifest = getReq.result;
                if (!manifest || !(pattern in manifest.pages))
                    return;
                const pages = { ...manifest.pages };
                delete pages[pattern];
                store.put({ ...manifest, version: manifest.version + 1, pages });
            };
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
    async invalidateSite(site) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).delete(site);
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
    async clear() {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).clear();
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
}


/***/ }),

/***/ "./src/adapters/manifest-persistence-adapter.ts":
/*!******************************************************!*\
  !*** ./src/adapters/manifest-persistence-adapter.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ManifestPersistenceAdapter: () => (/* binding */ ManifestPersistenceAdapter)
/* harmony export */ });
/**
 * ManifestPersistenceAdapter — IManifestPersistencePort implementation
 * using IndexedDB for persistent storage of SiteToolManifest data.
 *
 * Uses the `wmcp_manifests` object store with origin as key.
 */
const DB_NAME = 'webmcp-manifest-persistence';
const DB_VERSION = 1;
const STORE_NAME = 'wmcp_manifests';
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: 'origin' });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
class ManifestPersistenceAdapter {
    async save(origin, manifest) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).put({ ...manifest, origin });
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
    async load(origin) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).get(origin);
            req.onsuccess = () => { db.close(); resolve(req.result ?? null); };
            req.onerror = () => { db.close(); reject(req.error); };
        });
    }
    async listOrigins() {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const req = tx.objectStore(STORE_NAME).getAllKeys();
            req.onsuccess = () => { db.close(); resolve(req.result); };
            req.onerror = () => { db.close(); reject(req.error); };
        });
    }
    async delete(origin) {
        const db = await openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).delete(origin);
            tx.oncomplete = () => { db.close(); resolve(); };
            tx.onerror = () => { db.close(); reject(tx.error); };
        });
    }
}


/***/ }),

/***/ "./src/adapters/tool-manifest-adapter.ts":
/*!***********************************************!*\
  !*** ./src/adapters/tool-manifest-adapter.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolManifestAdapter: () => (/* binding */ ToolManifestAdapter)
/* harmony export */ });
/* harmony import */ var onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! onegenui-deep-agents/scraping */ "../onecrawl/dist/scraping/index.js");
/**
 * ToolManifestAdapter — Thin wrapper around OneCrawl's SemanticScrapingAdapter.
 *
 * Adapts CleanTool (Chrome extension–specific) ↔ SemanticTool (generic)
 * while delegating all manifest logic to the shared OneCrawl implementation.
 */

const VOLATILE_MANIFEST_CATEGORIES = new Set([
    'social-action',
]);
const STRUCTURAL_NAV_PREFIXES = [
    'nav.header.',
    'nav.nav.',
    'nav.sidebar.',
    'nav.footer.',
];
function shouldApplyStructuralFiltering(tool) {
    return tool._source === undefined || tool._source === 'inferred' || tool._source === 'manifest';
}
/** Convert a CleanTool to a SemanticTool for the shared adapter. */
function toSemanticTool(tool) {
    return {
        name: tool.name,
        description: tool.description,
        inputSchema: typeof tool.inputSchema === 'string'
            ? tool.inputSchema
            : { ...tool.inputSchema },
        category: tool.category,
        annotations: tool.annotations
            ? { ...tool.annotations }
            : undefined,
    };
}
function isStructuralManifestTool(tool) {
    if (!shouldApplyStructuralFiltering(tool)) {
        return true;
    }
    if (tool.category === 'navigation') {
        if (!tool.name.startsWith('nav.')) {
            return true;
        }
        return STRUCTURAL_NAV_PREFIXES.some(prefix => tool.name.startsWith(prefix));
    }
    return !tool.category || !VOLATILE_MANIFEST_CATEGORIES.has(tool.category);
}
class ToolManifestAdapter {
    inner = new onegenui_deep_agents_scraping__WEBPACK_IMPORTED_MODULE_0__.SemanticScrapingAdapter();
    getManifest(origin) {
        return this.inner.getManifest(origin);
    }
    updatePage(origin, url, tools) {
        return this.inner.updatePage(origin, url, tools.filter(isStructuralManifestTool).map(toSemanticTool));
    }
    applyDiff(origin, url, added, removed) {
        return this.inner.applyDiff(origin, url, added.filter(isStructuralManifestTool).map(toSemanticTool), removed);
    }
    toMCPJson(origin) {
        return this.inner.toMCPJson(origin);
    }
    getToolsForUrl(origin, url) {
        return this.inner.getToolsForUrl(origin, url);
    }
}


/***/ }),

/***/ "./src/content/ai-classifier.ts":
/*!**************************************!*\
  !*** ./src/content/ai-classifier.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AIClassifier: () => (/* binding */ AIClassifier)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/**
 * AI Classifier — sends low-confidence tools to an LLM for refined
 * categorisation.  Communicates with the background service worker
 * via chrome.runtime messages (AI_CLASSIFY action).
 */

class AIClassifier {
    cache = new Map();
    /**
     * Classify a batch of ambiguous tools via AI.
     * Returns enhanced tools with AI-refined metadata.
     */
    async classifyElements(tools, pageContext) {
        if (tools.length === 0)
            return [];
        const uncached = [];
        const cachedResults = [];
        for (const tool of tools) {
            const key = this.cacheKey(tool);
            const cached = this.cache.get(key);
            if (cached && Date.now() - cached.ts < _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_CLASSIFIER_CONFIG.cacheTTL) {
                cachedResults.push(cached.result);
            }
            else {
                uncached.push(tool);
            }
        }
        if (uncached.length === 0) {
            console.debug('[WMCP-AI] All elements served from cache');
            return cachedResults;
        }
        const allResults = [...cachedResults];
        for (let i = 0; i < uncached.length; i += _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_CLASSIFIER_CONFIG.batchSize) {
            const batch = uncached.slice(i, i + _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_CLASSIFIER_CONFIG.batchSize);
            try {
                const results = await this.classifyBatch(batch, pageContext);
                results.forEach((result, idx) => {
                    const key = this.cacheKey(batch[idx]);
                    this.cache.set(key, { result, ts: Date.now() });
                });
                allResults.push(...results);
            }
            catch (e) {
                console.warn('[WMCP-AI] Batch classification failed:', e);
                allResults.push(...batch);
            }
        }
        return allResults;
    }
    // ── Private helpers ──
    async classifyBatch(tools, pageContext) {
        const prompt = this.buildPrompt(tools, pageContext);
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                action: 'AI_CLASSIFY',
                model: _utils_constants__WEBPACK_IMPORTED_MODULE_0__.AI_CLASSIFIER_CONFIG.model,
                prompt,
            }, (resp) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                }
                else if (resp?.error) {
                    reject(new Error(resp.error));
                }
                else {
                    resolve(resp);
                }
            });
        });
        return this.parseResponse(response.text ?? '', tools);
    }
    buildPrompt(tools, pageContext) {
        const elements = tools
            .map((t, i) => {
            const conf = (t.confidence ?? 0).toFixed(2);
            return `[${i}] name="${t.name}" | category="${t.category ?? ''}" | description="${t.description}" | confidence=${conf}`;
        })
            .join('\n');
        return `You are a web element classifier for the WebMCP protocol.

Page: ${pageContext.url}
Title: ${pageContext.title}

I have ${tools.length} DOM elements that my heuristic scanner couldn't confidently classify.
For each element, provide a refined classification.

Elements:
${elements}

Respond with a JSON array of objects, one per element, in the same order:
[
  {
    "index": 0,
    "name": "category.action-slug",
    "description": "Better description of what this element does",
    "category": "one of: form|navigation|search|interactive|media|ecommerce|auth|page-state|schema-org|richtext|file-upload|social-action",
    "confidence": 0.85
  }
]

Rules:
- Use MCP dot notation for names: category.action-slug (e.g. form.submit-login, richtext.compose-post)
- Confidence should reflect how certain you are (0.7-1.0)
- richtext = contenteditable / WYSIWYG editors / social media post composers
- file-upload = file inputs, drop zones, upload buttons
- social-action = like, share, follow, comment, repost buttons
- If unsure, keep the original values but raise confidence slightly
- Only return the JSON array, no other text`;
    }
    parseResponse(text, originalTools) {
        try {
            const jsonMatch = text.match(/\[[\s\S]*\]/);
            if (!jsonMatch) {
                console.warn('[WMCP-AI] Could not extract JSON from response');
                return originalTools;
            }
            const parsed = JSON.parse(jsonMatch[0]);
            return originalTools.map((tool, idx) => {
                const refined = parsed.find((r) => r.index === idx);
                if (!refined)
                    return tool;
                return {
                    ...tool,
                    name: refined.name || tool.name,
                    description: refined.description || tool.description,
                    category: refined.category || tool.category,
                    confidence: refined.confidence || tool.confidence,
                    _aiRefined: true,
                };
            });
        }
        catch (e) {
            console.warn('[WMCP-AI] Failed to parse AI response:', e);
            return originalTools;
        }
    }
    cacheKey(tool) {
        return `${tool.name}::${tool.category ?? ''}::${location.href}`;
    }
}


/***/ }),

/***/ "./src/content/executors/auth-executor.ts":
/*!************************************************!*\
  !*** ./src/content/executors/auth-executor.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthExecutor: () => (/* binding */ AuthExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Auth executor: login form fill + submit, logout click.
 */

class AuthExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'auth';
    async execute(tool, args) {
        if (tool.name === 'auth.login') {
            const form = this.findElement(tool);
            if (!form)
                return this.fail('Login form not found');
            const parsed = this.parseArgs(args);
            for (const [key, value] of Object.entries(parsed)) {
                const input = form.querySelector(`[name="${key}"], #${key}`);
                if (input) {
                    input.value = String(value);
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }
            form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
            return this.ok('Login form submitted');
        }
        if (tool.name === 'auth.logout') {
            const el = this.findElement(tool);
            if (el)
                el.click();
            return this.ok('Logout clicked');
        }
        return this.fail(`Unknown auth tool: ${tool.name}`);
    }
}


/***/ }),

/***/ "./src/content/executors/base-executor.ts":
/*!************************************************!*\
  !*** ./src/content/executors/base-executor.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseExecutor: () => (/* binding */ BaseExecutor)
/* harmony export */ });
/**
 * Base executor class and shared result type.
 * All category executors extend this and implement execute().
 */
/**
 * Abstract base class for all category executors.
 * Provides shared DOM helpers used across multiple strategies.
 */
class BaseExecutor {
    /** Resolve the tool's associated DOM element */
    findElement(tool) {
        return tool._el ?? null;
    }
    /** Fire a sequence of events on an element */
    dispatchEvents(el, events) {
        for (const name of events) {
            el.dispatchEvent(new Event(name, { bubbles: true }));
        }
    }
    /** Poll for an element matching `selector` to appear in the DOM */
    waitForElement(selector, timeout = 3000) {
        return new Promise((resolve) => {
            const el = document.querySelector(selector);
            if (el) {
                resolve(el);
                return;
            }
            const interval = 200;
            let elapsed = 0;
            const timer = setInterval(() => {
                elapsed += interval;
                const found = document.querySelector(selector);
                if (found || elapsed >= timeout) {
                    clearInterval(timer);
                    resolve(found);
                }
            }, interval);
        });
    }
    /** Parse args that may arrive as a JSON string */
    parseArgs(args) {
        if (typeof args === 'string') {
            return JSON.parse(args);
        }
        return args;
    }
    /** Convenience: return a success result */
    ok(message, data) {
        return { success: true, message, data };
    }
    /** Convenience: return a failure result */
    fail(message, data) {
        return { success: false, message, data };
    }
}


/***/ }),

/***/ "./src/content/executors/chatbot-executor.ts":
/*!***************************************************!*\
  !*** ./src/content/executors/chatbot-executor.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatbotExecutor: () => (/* binding */ ChatbotExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Chatbot executor: types prompts into AI chatbot inputs and clicks send buttons.
 *
 * Handles both contenteditable divs (Claude, Gemini) and textareas (ChatGPT, Grok)
 * using framework-compatible value setting.
 */

class ChatbotExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'chatbot';
    async execute(tool, args) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('Chatbot element not found');
        if (tool.name === 'chatbot.type-prompt') {
            return this.typePrompt(el, args);
        }
        if (tool.name === 'chatbot.send-message') {
            return this.sendMessage(el);
        }
        return this.fail(`Unknown chatbot tool: "${tool.name}"`);
    }
    async typePrompt(el, args) {
        const parsed = this.parseArgs(args);
        const text = String(parsed.text ?? '');
        const htmlEl = el;
        htmlEl.focus();
        if (el.getAttribute('contenteditable') === 'true') {
            // Contenteditable div (Claude, Gemini, etc.)
            // Clear existing content, then insert via execCommand for React/ProseMirror compat
            const selection = window.getSelection();
            if (selection) {
                selection.selectAllChildren(htmlEl);
                selection.deleteFromDocument();
            }
            document.execCommand('insertText', false, text);
            this.dispatchEvents(el, ['input', 'change']);
        }
        else {
            // Textarea (ChatGPT, Grok, etc.)
            const textarea = el;
            const nativeSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
            // First try: native setter + bulk events (works for ChatGPT)
            if (nativeSetter) {
                nativeSetter.call(textarea, text);
            }
            else {
                textarea.value = text;
            }
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
            // Wait briefly, then check if React picked it up
            await new Promise((r) => setTimeout(r, 50));
            // If the textarea value was reset by React, simulate char-by-char typing.
            // This is needed for Grok and other React apps that don't respond to bulk value setting.
            if (textarea.value !== text) {
                if (nativeSetter) {
                    nativeSetter.call(textarea, '');
                }
                else {
                    textarea.value = '';
                }
                el.dispatchEvent(new Event('input', { bubbles: true }));
                for (const char of text) {
                    el.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
                    if (nativeSetter) {
                        nativeSetter.call(textarea, textarea.value + char);
                    }
                    else {
                        textarea.value += char;
                    }
                    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: char, inputType: 'insertText' }));
                    el.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
                }
            }
        }
        // Let frameworks react
        await new Promise((r) => setTimeout(r, 150));
        return this.ok(`Typed prompt: "${text}"`);
    }
    async sendMessage(el) {
        const btn = el;
        // Some chatbots disable the send button until input has content — wait up to 1s
        for (let i = 0; i < 10 && (btn.disabled || btn.getAttribute('aria-disabled') === 'true'); i++) {
            await new Promise((r) => setTimeout(r, 100));
        }
        if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') {
            // Fallback: try pressing Enter on the textarea instead
            const textarea = btn.closest('form')?.querySelector('textarea')
                ?? document.querySelector('textarea');
            if (textarea) {
                textarea.focus();
                textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
                return this.ok('Send via Enter key (button was disabled)');
            }
            return this.fail('Send button is still disabled — input may not have been recognized');
        }
        btn.click();
        return this.ok('Send button clicked');
    }
}


/***/ }),

/***/ "./src/content/executors/ecommerce-executor.ts":
/*!*****************************************************!*\
  !*** ./src/content/executors/ecommerce-executor.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EcommerceExecutor: () => (/* binding */ EcommerceExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * E-commerce executor: add-to-cart, set quantity, checkout clicks.
 */

class EcommerceExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'ecommerce';
    async execute(tool, args) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('E-commerce element not found');
        if (tool.name.includes('.add-to-cart-')) {
            el.click();
            return this.ok(`Added to cart: ${tool.description}`);
        }
        if (tool.name.includes('.set-quantity-')) {
            const parsed = this.parseArgs(args);
            const qty = parsed.quantity ?? 1;
            el.value = String(qty);
            el.dispatchEvent(new Event('change', { bubbles: true }));
            return this.ok(`Set quantity to ${qty}`);
        }
        el.click();
        return this.ok(`E-commerce action: ${tool.name}`);
    }
}


/***/ }),

/***/ "./src/content/executors/file-upload-executor.ts":
/*!*******************************************************!*\
  !*** ./src/content/executors/file-upload-executor.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileUploadExecutor: () => (/* binding */ FileUploadExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * File-upload executor: triggers file input click or drop zone click.
 */

class FileUploadExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'file-upload';
    async execute(tool, args) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('Upload element not found');
        const parsed = this.parseArgs(args);
        const filePath = parsed.file_path;
        if (!filePath)
            return this.fail('No file_path provided');
        const label = tool.title ?? tool.name;
        if (el instanceof HTMLInputElement &&
            el.type === 'file') {
            el.click();
            return this.ok(`Opened file picker for: ${label}. ` +
                `Please manually select: ${filePath}. ` +
                `Note: For automated file upload, use Chrome DevTools MCP upload_file tool.`);
        }
        // Drop zones, buttons, etc.
        el.click();
        return this.ok(`Clicked upload trigger: ${label}. Please use Chrome DevTools MCP for actual file upload.`);
    }
}


/***/ }),

/***/ "./src/content/executors/form-executor.ts":
/*!************************************************!*\
  !*** ./src/content/executors/form-executor.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormExecutor: () => (/* binding */ FormExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Form executor: fills fields, handles select/checkbox/radio, submits.
 *
 * Supports two tool prefixes:
 * - `form.submit-*` — fills all fields of a <form> and submits
 * - `form.fill-*`   — fills a single standalone input field
 *
 * Uses native value setter for React/Vue compatibility.
 * Submits via submit button click > form.submit() > submit event.
 */

class FormExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'form';
    async execute(tool, args) {
        // ── form.fill-* : single standalone field ──
        if (tool.name.startsWith('form.fill-')) {
            const el = this.findElement(tool);
            if (!el)
                return this.fail('Field element not found');
            const parsed = this.parseArgs(args);
            const value = parsed.value;
            if (value === undefined)
                return this.fail('Missing "value" argument for form.fill-*');
            // Radio groups need option lookup by value; the emitted tool is bound
            // to one radio element but should set the requested option.
            if (el instanceof HTMLInputElement && el.type === 'radio' && el.name) {
                const scope = (el.form ?? el.getRootNode());
                const radios = scope.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`);
                const match = Array.from(radios).find((radio) => radio.value === String(value));
                if (!match) {
                    return this.fail(`Radio option "${String(value)}" not found for group "${el.name}"`);
                }
                this.setFieldValue(match, value);
                return this.ok(`Field "${tool.name}" set to "${String(value)}"`);
            }
            this.setFieldValue(el, value);
            return this.ok(`Field "${tool.name}" set to "${String(value)}"`);
        }
        // ── form.submit-* : fill + submit a <form> ──
        const form = this.findElement(tool);
        if (!form)
            return this.fail('Form element not found');
        const parsed = this.parseArgs(args);
        for (const [key, value] of Object.entries(parsed)) {
            const input = form.querySelector(`[name="${CSS.escape(key)}"], #${CSS.escape(key)}`);
            if (!input)
                continue;
            if (input instanceof HTMLInputElement &&
                input.type === 'radio') {
                const radio = form.querySelector(`input[type="radio"][name="${CSS.escape(key)}"][value="${CSS.escape(String(value))}"]`);
                if (radio)
                    this.setFieldValue(radio, value);
            }
            else {
                this.setFieldValue(input, value);
            }
        }
        // Small delay for frameworks to process value changes
        await new Promise((r) => setTimeout(r, 100));
        // Strategy 1: find and click a submit button
        const submitBtn = form.querySelector('input[type="submit"], button[type="submit"], button:not([type])');
        if (submitBtn) {
            submitBtn.click();
        }
        else {
            // Strategy 2: native form.submit()
            form.submit();
        }
        const fieldCount = Object.keys(parsed).length;
        return this.ok(`Form "${tool.name}" submitted with ${fieldCount} fields`);
    }
    /** Set the value of a single form field with React/Vue-compatible native setters. */
    setFieldValue(el, value) {
        if (el instanceof HTMLSelectElement) {
            const normalized = String(value).trim().toLowerCase();
            const opt = [...el.options].find((o) => o.value.trim().toLowerCase() === normalized ||
                o.text.trim().toLowerCase() === normalized);
            if (opt)
                el.value = opt.value;
        }
        else if (el instanceof HTMLInputElement &&
            el.type === 'checkbox') {
            el.checked = this.toBoolean(value);
        }
        else if (el instanceof HTMLInputElement &&
            el.type === 'radio') {
            el.checked = true;
        }
        else if (el instanceof HTMLInputElement) {
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
            if (setter)
                setter.call(el, String(value));
            else
                el.value = String(value);
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }
        else if (el instanceof HTMLTextAreaElement) {
            const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
            if (setter)
                setter.call(el, String(value));
            else
                el.value = String(value);
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    toBoolean(value) {
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'number')
            return value !== 0;
        if (typeof value === 'string') {
            const normalized = value.trim().toLowerCase();
            if (['', '0', 'false', 'off', 'no', 'n'].includes(normalized))
                return false;
            if (['1', 'true', 'on', 'yes', 'y'].includes(normalized))
                return true;
        }
        return !!value;
    }
}


/***/ }),

/***/ "./src/content/executors/index.ts":
/*!****************************************!*\
  !*** ./src/content/executors/index.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseExecutor: () => (/* reexport safe */ _base_executor__WEBPACK_IMPORTED_MODULE_13__.BaseExecutor),
/* harmony export */   ExecutorRegistry: () => (/* binding */ ExecutorRegistry)
/* harmony export */ });
/* harmony import */ var _form_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-executor */ "./src/content/executors/form-executor.ts");
/* harmony import */ var _navigation_executor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation-executor */ "./src/content/executors/navigation-executor.ts");
/* harmony import */ var _search_executor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./search-executor */ "./src/content/executors/search-executor.ts");
/* harmony import */ var _interactive_executor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./interactive-executor */ "./src/content/executors/interactive-executor.ts");
/* harmony import */ var _media_executor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./media-executor */ "./src/content/executors/media-executor.ts");
/* harmony import */ var _ecommerce_executor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ecommerce-executor */ "./src/content/executors/ecommerce-executor.ts");
/* harmony import */ var _auth_executor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth-executor */ "./src/content/executors/auth-executor.ts");
/* harmony import */ var _page_state_executor__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page-state-executor */ "./src/content/executors/page-state-executor.ts");
/* harmony import */ var _schema_org_executor__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./schema-org-executor */ "./src/content/executors/schema-org-executor.ts");
/* harmony import */ var _richtext_executor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./richtext-executor */ "./src/content/executors/richtext-executor.ts");
/* harmony import */ var _file_upload_executor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./file-upload-executor */ "./src/content/executors/file-upload-executor.ts");
/* harmony import */ var _social_executor__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./social-executor */ "./src/content/executors/social-executor.ts");
/* harmony import */ var _chatbot_executor__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./chatbot-executor */ "./src/content/executors/chatbot-executor.ts");
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Executor registry: maps tool categories to their executor instances.
 */














class ExecutorRegistry {
    executors;
    constructor() {
        const all = [
            new _form_executor__WEBPACK_IMPORTED_MODULE_0__.FormExecutor(),
            new _navigation_executor__WEBPACK_IMPORTED_MODULE_1__.NavigationExecutor(),
            new _search_executor__WEBPACK_IMPORTED_MODULE_2__.SearchExecutor(),
            new _interactive_executor__WEBPACK_IMPORTED_MODULE_3__.InteractiveExecutor(),
            new _media_executor__WEBPACK_IMPORTED_MODULE_4__.MediaExecutor(),
            new _ecommerce_executor__WEBPACK_IMPORTED_MODULE_5__.EcommerceExecutor(),
            new _auth_executor__WEBPACK_IMPORTED_MODULE_6__.AuthExecutor(),
            new _page_state_executor__WEBPACK_IMPORTED_MODULE_7__.PageStateExecutor(),
            new _schema_org_executor__WEBPACK_IMPORTED_MODULE_8__.SchemaOrgExecutor(),
            new _richtext_executor__WEBPACK_IMPORTED_MODULE_9__.RichTextExecutor(),
            new _file_upload_executor__WEBPACK_IMPORTED_MODULE_10__.FileUploadExecutor(),
            new _social_executor__WEBPACK_IMPORTED_MODULE_11__.SocialExecutor(),
            new _chatbot_executor__WEBPACK_IMPORTED_MODULE_12__.ChatbotExecutor(),
        ];
        this.executors = new Map(all.map((e) => [e.category, e]));
    }
    /** Execute a tool using the matching category executor */
    async execute(tool, args) {
        const category = tool.category;
        if (!category) {
            return {
                success: false,
                message: `No category on tool "${tool.name}"`,
            };
        }
        const executor = this.executors.get(category);
        if (!executor) {
            return {
                success: false,
                message: `No executor for category "${category}"`,
            };
        }
        console.debug(`[WMCP-Executor] Executing "${tool.name}" (${category})`, args);
        return executor.execute(tool, args);
    }
    /** Get the executor for a specific category */
    getExecutor(category) {
        return this.executors.get(category);
    }
}


/***/ }),

/***/ "./src/content/executors/interactive-executor.ts":
/*!*******************************************************!*\
  !*** ./src/content/executors/interactive-executor.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InteractiveExecutor: () => (/* binding */ InteractiveExecutor)
/* harmony export */ });
/* harmony import */ var _live_state__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../live-state */ "./src/content/live-state/index.ts");
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Interactive executor: button clicks, toggles, tab switches, combobox selection.
 *
 * Uses live state to provide informative response messages about
 * the resulting state of interactive elements.
 */


class InteractiveExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_1__.BaseExecutor {
    category = 'interactive';
    async execute(tool, args) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('Interactive element not found');
        // Toggle
        if (tool.name.includes('.toggle-')) {
            const parsed = this.parseArgs(args ?? {});
            if ((el instanceof HTMLInputElement && el.type === 'checkbox') ||
                el.getAttribute('role') === 'switch') {
                const checkbox = el;
                const desired = parsed.checked !== undefined
                    ? !!parsed.checked
                    : !checkbox.checked;
                if (checkbox.checked !== desired)
                    el.click();
                return this.ok(`Toggled "${tool.name}" to ${desired ? 'ON' : 'OFF'}`);
            }
        }
        // Select option (combobox / listbox)
        if (tool.name.includes('.select-') && args) {
            const parsed = this.parseArgs(args);
            const value = parsed.value;
            if (value) {
                el.click();
                setTimeout(() => {
                    const opts = [
                        ...document.querySelectorAll('[role="option"]'),
                    ];
                    const match = opts.find((o) => (o.textContent ?? '').trim().toLowerCase() ===
                        value.toLowerCase());
                    if (match instanceof HTMLElement)
                        match.click();
                }, 100);
                return this.ok(`Selected "${value}" from ${tool.name}`);
            }
        }
        // Default: click with state-aware feedback
        el.click();
        return this.ok(this.buildClickMessage(tool.name));
    }
    /** Enrich click responses with current interactive state context */
    buildClickMessage(toolName) {
        const snapshot = (0,_live_state__WEBPACK_IMPORTED_MODULE_0__.getLiveStateManager)().getLatestSnapshot();
        if (!snapshot)
            return `Clicked: ${toolName}`;
        const { openModals, expandedAccordions } = snapshot.interactive;
        const parts = [`Clicked: ${toolName}`];
        if (openModals.length)
            parts.push(`(${openModals.length} modal(s) open)`);
        if (expandedAccordions.length)
            parts.push(`(${expandedAccordions.length} accordion(s) expanded)`);
        return parts.join(' ');
    }
}


/***/ }),

/***/ "./src/content/executors/media-executor.ts":
/*!*************************************************!*\
  !*** ./src/content/executors/media-executor.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MediaExecutor: () => (/* binding */ MediaExecutor)
/* harmony export */ });
/* harmony import */ var _media__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../media */ "./src/content/media/index.ts");
/* harmony import */ var _live_state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../live-state */ "./src/content/live-state/index.ts");
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Media executor: unified media command execution through player adapters.
 *
 * Performs live-state pre-checks before executing actions to avoid
 * redundant operations (e.g. playing an already-playing video).
 */



class MediaExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_2__.BaseExecutor {
    category = 'media';
    async execute(tool, args) {
        const actionTarget = this.parseTool(tool.name);
        if (!actionTarget)
            return this.fail('Unknown media action');
        const parsedArgs = this.parseArgs(args);
        const player = this.resolvePlayer(actionTarget.playerId, tool);
        if (!player) {
            return this.fail(`Media player not found: ${actionTarget.playerId}`);
        }
        const liveState = this.getMediaLiveState(actionTarget.playerId);
        const preCheck = this.preCheckAction(actionTarget.action, liveState, parsedArgs);
        if (preCheck)
            return preCheck;
        try {
            return await this.executeAction(player, actionTarget.action, parsedArgs, tool.description);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            return this.fail(`Media execution failed: ${message}`);
        }
    }
    /** Retrieve cached live state for a specific player */
    getMediaLiveState(playerId) {
        const snapshot = (0,_live_state__WEBPACK_IMPORTED_MODULE_1__.getLiveStateManager)().getLatestSnapshot();
        return snapshot?.media.find((m) => m.playerId === playerId);
    }
    /**
     * Pre-check: return an early result if the action is redundant.
     * Returns `null` when the action should proceed normally.
     */
    preCheckAction(action, state, args) {
        if (!state)
            return null;
        const time = this.fmtTimeSec(state.currentTime);
        switch (action) {
            case 'play':
                if (!state.paused) {
                    return this.ok(`Already playing at ${time} — no action needed`);
                }
                break;
            case 'pause':
                if (state.paused) {
                    return this.ok(`Already paused at ${time} — no action needed`);
                }
                break;
            case 'mute':
                if (state.muted) {
                    return this.ok('Already muted — no action needed');
                }
                break;
            case 'unmute':
                if (!state.muted) {
                    return this.ok('Already unmuted — no action needed');
                }
                break;
            case 'set-volume': {
                const level = typeof args.level === 'number' ? args.level : Number(args.level);
                if (Number.isFinite(level) && Math.abs(state.volume - level) < 0.01) {
                    return this.ok(`Volume already at ${Math.round(level * 100)}% — no action needed`);
                }
                break;
            }
        }
        return null;
    }
    parseTool(toolName) {
        return (0,_media__WEBPACK_IMPORTED_MODULE_0__.parseMediaToolName)(toolName) ?? this.parseLegacyToolName(toolName);
    }
    parseLegacyToolName(toolName) {
        const patterns = [
            { re: /\.play-(?:audio-)?(.+)$/i, action: 'play' },
            { re: /\.pause-(.+)$/i, action: 'pause' },
            { re: /\.seek-(.+)$/i, action: 'seek' },
        ];
        for (const { re, action } of patterns) {
            const match = re.exec(toolName);
            if (!match || !match[1])
                continue;
            return {
                action,
                playerId: match[1],
            };
        }
        return null;
    }
    resolvePlayer(playerId, tool) {
        const registry = (0,_media__WEBPACK_IMPORTED_MODULE_0__.getPlayerRegistry)();
        registry.refresh(document);
        const fromRegistry = registry.getById(playerId);
        if (fromRegistry)
            return fromRegistry;
        const el = this.findElement(tool);
        if (el instanceof HTMLMediaElement) {
            return new _media__WEBPACK_IMPORTED_MODULE_0__.NativePlayerAdapter(playerId, el);
        }
        return null;
    }
    async executeAction(player, action, args, description) {
        switch (action) {
            case 'play': {
                await player.play();
                return this.ok(`Playing: ${description}`);
            }
            case 'pause': {
                await player.pause();
                return this.ok(`Paused: ${description}`);
            }
            case 'seek': {
                const time = this.toFiniteNumber(args.time, 'time');
                await player.seek(time);
                return this.ok(`Seeked to ${time}s: ${description}`);
            }
            case 'set-volume': {
                const level = this.toFiniteNumber(args.level, 'level');
                await player.setVolume(level);
                return this.ok(`Volume set to ${level}: ${description}`);
            }
            case 'mute': {
                await player.mute();
                return this.ok(`Muted: ${description}`);
            }
            case 'unmute': {
                await player.unmute();
                return this.ok(`Unmuted: ${description}`);
            }
            case 'get-state': {
                const state = await player.getState();
                return this.ok(`State retrieved: ${description}`, state);
            }
            case 'get-transcript': {
                const transcript = await this.extractTranscript(player);
                if (!transcript) {
                    return this.fail('Transcript unavailable for current media context');
                }
                return this.ok(`Transcript retrieved: ${description}`, transcript);
            }
            case 'next-track': {
                if (!player.nextTrack)
                    return this.fail('next-track not supported by this player');
                await player.nextTrack();
                return this.ok(`Moved to next track: ${description}`);
            }
            case 'previous-track': {
                if (!player.previousTrack)
                    return this.fail('previous-track not supported by this player');
                await player.previousTrack();
                return this.ok(`Moved to previous track: ${description}`);
            }
            case 'shuffle': {
                if (!player.shuffle)
                    return this.fail('shuffle not supported by this player');
                await player.shuffle();
                return this.ok(`Shuffle enabled: ${description}`);
            }
            default:
                return this.fail('Unknown media action');
        }
    }
    toFiniteNumber(value, argName) {
        const numberValue = typeof value === 'number' ? value : Number(value);
        if (!Number.isFinite(numberValue)) {
            throw new Error(`Invalid ${argName} argument`);
        }
        return numberValue;
    }
    async extractTranscript(player) {
        if (player.platform !== 'youtube')
            return null;
        const readSegments = () => {
            const selectors = [
                'ytd-transcript-segment-renderer #segment-text',
                'ytd-transcript-segment-renderer .segment-text',
                'ytd-transcript-renderer #segments-container ytd-transcript-segment-renderer',
                '[data-testid*="transcript" i] [data-testid*="segment" i]',
                '[class*="transcript" i] [class*="segment" i]',
            ];
            const out = [];
            for (const selector of selectors) {
                const nodes = Array.from(document.querySelectorAll(selector));
                for (const node of nodes) {
                    const text = (node.textContent ?? '').trim();
                    if (text)
                        out.push(text);
                }
            }
            return [...new Set(out)];
        };
        let segments = readSegments();
        if (segments.length === 0) {
            const openButtons = [
                'button[aria-label*="transcript" i]',
                'tp-yt-paper-button[aria-label*="transcript" i]',
                'button[aria-label*="show transcript" i]',
                'button[title*="transcript" i]',
            ];
            const btn = openButtons
                .map((selector) => document.querySelector(selector))
                .find((el) => !!el);
            if (btn) {
                btn.click();
                await this.wait(300);
            }
            segments = readSegments();
        }
        if (segments.length === 0)
            return null;
        return {
            text: segments.join('\n'),
            segments,
        };
    }
    wait(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    fmtTimeSec(seconds) {
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    }
}


/***/ }),

/***/ "./src/content/executors/navigation-executor.ts":
/*!******************************************************!*\
  !*** ./src/content/executors/navigation-executor.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NavigationExecutor: () => (/* binding */ NavigationExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Navigation executor: clicks links, navigates to URLs.
 */

class NavigationExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'navigation';
    async execute(tool) {
        const link = this.findElement(tool);
        if (!link)
            return this.fail('Navigation link not found');
        const href = link.getAttribute('href');
        if (!href)
            return this.fail('No href found');
        link.click();
        return this.ok(`Navigated to: ${href}`);
    }
}


/***/ }),

/***/ "./src/content/executors/page-state-executor.ts":
/*!******************************************************!*\
  !*** ./src/content/executors/page-state-executor.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageStateExecutor: () => (/* binding */ PageStateExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Page-state executor: scroll, theme toggle, back-to-top.
 */

class PageStateExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'page-state';
    async execute(tool) {
        if (tool.name === 'page.scroll-to-top') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            return this.ok('Scrolled to top');
        }
        if (tool.name === 'page.scroll-to-bottom') {
            window.scrollTo({
                top: document.body.scrollHeight,
                behavior: 'smooth',
            });
            return this.ok('Scrolled to bottom');
        }
        if (tool.name === 'page.toggle-theme' ||
            tool.name === 'page.click-back-to-top') {
            const el = this.findElement(tool);
            if (el)
                el.click();
            return this.ok(`Executed: ${tool.name}`);
        }
        return this.fail('Unknown page state action');
    }
}


/***/ }),

/***/ "./src/content/executors/richtext-executor.ts":
/*!****************************************************!*\
  !*** ./src/content/executors/richtext-executor.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RichTextExecutor: () => (/* binding */ RichTextExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Rich-text executor: Quill, Draft.js, ProseMirror, generic contenteditable.
 * Uses paste simulation for React-based editors to keep internal state in sync.
 */

/** Check if an element is connected and has non-zero height */
function isReady(el) {
    return (!!el &&
        el.isConnected &&
        el.getBoundingClientRect().height > 0);
}
function isTextInput(el) {
    return !!el && (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement);
}
function isEditableNode(el) {
    if (!el)
        return false;
    const htmlEl = el;
    return (htmlEl.isContentEditable ||
        el.getAttribute('role') === 'textbox' ||
        isTextInput(el));
}
/** HTML-escape a string */
function esc(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
/** Find a contenteditable editor on the page (priority order) */
function findEditor() {
    return document.querySelector('.ql-editor[contenteditable="true"], ' +
        '.ProseMirror[contenteditable="true"], ' +
        '[contenteditable="true"][role="textbox"], ' +
        'textarea[aria-label*="comment" i], ' +
        'textarea[placeholder*="comment" i], ' +
        'textarea[placeholder*="reply" i], ' +
        'textarea[placeholder*="message" i], ' +
        'ytd-comment-simplebox-renderer #contenteditable-root, ' +
        'div[contenteditable="true"][data-tab], ' +
        '[contenteditable="true"]');
}
/** Pattern matching content-creation trigger buttons (multilingual) */
const TRIGGER_RE = /\b(post|compose|write|create|tweet|reply|comment|message|chat|scrivi|pubblica|crea|nouveau|erstellen|escribir|rédiger)\b/i;
class RichTextExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'richtext';
    async execute(tool, args) {
        const parsed = this.parseArgs(args);
        const text = String(parsed.text ?? '');
        if (!text)
            return this.fail('No text provided');
        try {
            const editable = await this.resolveEditor(tool);
            if (!isReady(editable) || !isEditableNode(editable)) {
                return this.fail('Editor not found — could not activate the composer');
            }
            if (isTextInput(editable)) {
                editable.focus();
                editable.value = text;
                editable.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    cancelable: true,
                    inputType: 'insertText',
                    data: text,
                }));
                editable.dispatchEvent(new Event('change', { bubbles: true }));
                return this.ok(`Wrote ${text.length} chars to "${tool.title ?? tool.name}"`);
            }
            const isQuill = editable.classList.contains('ql-editor') ||
                !!editable.closest?.('.ql-container');
            // Focus & settle
            editable.focus();
            await this.delay(200);
            const lines = text.split('\n');
            if (isQuill) {
                this.insertQuill(editable, lines);
            }
            else {
                await this.insertPaste(editable, text, lines);
            }
            // Notify framework
            editable.dispatchEvent(new InputEvent('input', {
                bubbles: true,
                cancelable: true,
                inputType: 'insertText',
                data: text,
            }));
            editable.dispatchEvent(new Event('change', { bubbles: true }));
            return this.ok(`Wrote ${text.length} chars to "${tool.title ?? tool.name}"`);
        }
        catch (e) {
            // Ultimate fallback: innerHTML with <p> tags
            return this.fallbackInsert(tool, text, e);
        }
    }
    /** Resolve or activate the editable element */
    async resolveEditor(tool) {
        let editable = this.findElement(tool);
        // If _el is a container, drill down to the actual editable child
        if (editable && !isEditableNode(editable)) {
            const nestedEditable = editable.querySelector('.ql-editor') ??
                editable.querySelector('[contenteditable="true"]') ??
                editable.querySelector('textarea, input[type="text"], [role="textbox"]');
            if (nestedEditable) {
                editable = nestedEditable;
            }
            else {
                editable.click();
                await this.delay(200);
            }
        }
        if (isReady(editable) && isEditableNode(editable))
            return editable;
        // Maybe there's already an editor elsewhere on the page
        editable = findEditor();
        if (isReady(editable) && isEditableNode(editable))
            return editable;
        // No editor in DOM — scan for a trigger button
        const buttons = [
            ...document.querySelectorAll('button, [role="button"]'),
        ];
        const trigger = buttons.find((btn) => {
            if (!isReady(btn))
                return false;
            const label = ((btn.textContent ?? '') +
                ' ' +
                (btn.getAttribute('aria-label') ?? '')).toLowerCase();
            return TRIGGER_RE.test(label);
        });
        if (trigger) {
            trigger.click();
            // Poll for editor to appear (up to ~3 s)
            for (let i = 0; i < 15; i++) {
                await this.delay(200);
                editable = findEditor();
                if (isReady(editable) && isEditableNode(editable))
                    break;
            }
        }
        return isReady(editable) && isEditableNode(editable) ? editable : null;
    }
    /** Quill: build <p> elements directly (Quill's MutationObserver syncs) */
    insertQuill(editable, lines) {
        editable.innerHTML = '';
        for (const line of lines) {
            const p = document.createElement('p');
            if (line.trim().length === 0) {
                p.innerHTML = '<br>';
            }
            else {
                p.textContent = line;
            }
            editable.appendChild(p);
        }
        editable.classList.remove('ql-blank');
    }
    /** Paste simulation for Draft.js, ProseMirror, Slate, etc. */
    async insertPaste(editable, text, lines) {
        // Select all existing content
        const sel = window.getSelection();
        if (sel) {
            const range = document.createRange();
            range.selectNodeContents(editable);
            sel.removeAllRanges();
            sel.addRange(range);
        }
        // Build clipboard data
        const dt = new DataTransfer();
        dt.setData('text/plain', text);
        dt.setData('text/html', lines.map((l) => `<p>${l.trim() ? esc(l) : '<br>'}</p>`).join(''));
        // Dispatch paste event
        editable.dispatchEvent(new ClipboardEvent('paste', {
            bubbles: true,
            cancelable: true,
            clipboardData: dt,
        }));
        await this.delay(500);
        // Verify: if paste didn't insert anything, fall back to execCommand
        const content = editable.innerText || editable.textContent || '';
        if (content.trim().length < 5) {
            console.warn('[WMCP-Executor] Paste simulation did not take effect, falling back to execCommand');
            editable.focus();
            document.execCommand('selectAll', false, undefined);
            document.execCommand('delete', false, undefined);
            for (let i = 0; i < lines.length; i++) {
                if (i > 0) {
                    document.execCommand('insertParagraph', false, undefined);
                }
                if (lines[i].length > 0) {
                    document.execCommand('insertText', false, lines[i]);
                }
                if (i % 3 === 2) {
                    await this.delay(15);
                }
            }
        }
    }
    /** Last-resort fallback: innerHTML with <p> tags */
    fallbackInsert(tool, text, originalError) {
        console.warn('[WMCP-Executor] richtext failed:', originalError);
        try {
            const fb = findEditor() ?? this.findElement(tool);
            if (!fb)
                return this.fail(`Failed: ${originalError.message}`);
            if (isTextInput(fb)) {
                fb.value = text;
                fb.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    cancelable: true,
                    inputType: 'insertText',
                    data: text,
                }));
                fb.dispatchEvent(new Event('change', { bubbles: true }));
                return this.ok(`Wrote ${text.length} chars (fallback) to "${tool.title ?? tool.name}"`);
            }
            const lines = text.split('\n');
            fb.innerHTML = lines
                .map((l) => `<p>${l.trim() ? esc(l) : '<br>'}</p>`)
                .join('');
            fb.classList?.remove('ql-blank');
            fb.dispatchEvent(new InputEvent('input', {
                bubbles: true,
                cancelable: true,
                inputType: 'insertText',
                data: text,
            }));
            return this.ok(`Wrote ${text.length} chars (fallback) to "${tool.title ?? tool.name}"`);
        }
        catch {
            return this.fail(`Failed: ${originalError.message}`);
        }
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}


/***/ }),

/***/ "./src/content/executors/schema-org-executor.ts":
/*!******************************************************!*\
  !*** ./src/content/executors/schema-org-executor.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchemaOrgExecutor: () => (/* binding */ SchemaOrgExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Schema.org executor: resolves action URL template and navigates.
 */

class SchemaOrgExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'schema-org';
    async execute(tool, args) {
        const action = tool._schemaAction;
        if (!action?.target)
            return this.fail('No Schema.org target');
        let url;
        if (typeof action.target === 'string') {
            url = action.target;
        }
        else {
            const target = action.target;
            url = target.urlTemplate ?? target.url ?? '';
        }
        if (args) {
            const parsed = this.parseArgs(args);
            for (const [key, value] of Object.entries(parsed)) {
                url = url.replace(`{${key}}`, encodeURIComponent(String(value)));
            }
        }
        if (url) {
            window.location.href = url;
            return this.ok(`Navigating to Schema.org action: ${url}`);
        }
        return this.fail('Could not resolve Schema.org action URL');
    }
}


/***/ }),

/***/ "./src/content/executors/search-executor.ts":
/*!**************************************************!*\
  !*** ./src/content/executors/search-executor.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchExecutor: () => (/* binding */ SearchExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Search executor: fills search input, submits form or simulates Enter.
 *
 * Uses the native InputEvent setter to bypass React/framework value traps,
 * then submits via form.submit() (bypasses JS handlers that may preventDefault),
 * with fallback to submit button click, then form submit event, then Enter key.
 */

class SearchExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'search';
    async execute(tool, args) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('Search input not found');
        const parsed = this.parseArgs(args);
        const query = String(parsed.query ?? '');
        // Use native setter to work with React/Vue controlled inputs
        const nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) {
            nativeSetter.call(el, query);
        }
        else {
            el.value = query;
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        // Small delay to let frameworks react to the value change
        await new Promise((r) => setTimeout(r, 100));
        const form = tool._form ?? el.closest('form');
        if (form) {
            // Strategy 1: find and click a submit button (most reliable)
            const submitBtn = form.querySelector('input[type="submit"], button[type="submit"], button:not([type])') ??
                form.querySelector('[role="button"], .search-submit, .search-btn, [class*="search"]');
            if (submitBtn) {
                submitBtn.click();
            }
            else {
                // Strategy 2: native form.submit() — bypasses JS preventDefault
                form.submit();
            }
        }
        else {
            // No form: simulate full Enter key sequence
            const enterOpts = {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true,
            };
            el.dispatchEvent(new KeyboardEvent('keydown', enterOpts));
            el.dispatchEvent(new KeyboardEvent('keypress', enterOpts));
            el.dispatchEvent(new KeyboardEvent('keyup', enterOpts));
        }
        return this.ok(`Searched for: "${query}"`);
    }
}


/***/ }),

/***/ "./src/content/executors/social-executor.ts":
/*!**************************************************!*\
  !*** ./src/content/executors/social-executor.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SocialExecutor: () => (/* binding */ SocialExecutor)
/* harmony export */ });
/* harmony import */ var _base_executor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-executor */ "./src/content/executors/base-executor.ts");
/**
 * Social-action executor: like, share, follow, comment clicks.
 */

class SocialExecutor extends _base_executor__WEBPACK_IMPORTED_MODULE_0__.BaseExecutor {
    category = 'social-action';
    async execute(tool) {
        const el = this.findElement(tool);
        if (!el)
            return this.fail('Social action element not found');
        el.click();
        const action = this.parseAction(tool.name);
        switch (action) {
            case 'like':
                return this.ok(`Liked/reacted: ${tool.description}`);
            case 'share':
                return this.ok(`Shared/reposted: ${tool.description}`);
            case 'follow':
                return this.ok(`Followed/subscribed: ${tool.description}`);
            case 'comment':
                return this.ok(`Opened comment/reply: ${tool.description}`);
            case 'message':
                return this.ok(`Opened message/chat action: ${tool.description}`);
            case 'save':
                return this.ok(`Saved/bookmarked: ${tool.description}`);
            case 'join':
                return this.ok(`Joined action executed: ${tool.description}`);
            default:
                return this.ok(`Social action executed: ${tool.name}`);
        }
    }
    parseAction(name) {
        const match = /^social\.([a-z-]+)-/i.exec(name);
        if (!match)
            return null;
        const action = match[1].toLowerCase();
        switch (action) {
            case 'like':
            case 'share':
            case 'follow':
            case 'comment':
            case 'message':
            case 'save':
            case 'join':
                return action;
            default:
                return null;
        }
    }
}


/***/ }),

/***/ "./src/content/live-state/index.ts":
/*!*****************************************!*\
  !*** ./src/content/live-state/index.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.AuthStateProvider),
/* harmony export */   FormStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.FormStateProvider),
/* harmony export */   InteractiveStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.InteractiveStateProvider),
/* harmony export */   LiveStateManager: () => (/* reexport safe */ _live_state_manager__WEBPACK_IMPORTED_MODULE_0__.LiveStateManager),
/* harmony export */   MediaStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.MediaStateProvider),
/* harmony export */   NavigationStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.NavigationStateProvider),
/* harmony export */   PollingEngine: () => (/* reexport safe */ _polling_engine__WEBPACK_IMPORTED_MODULE_1__.PollingEngine),
/* harmony export */   VisibilityStateProvider: () => (/* reexport safe */ _providers__WEBPACK_IMPORTED_MODULE_2__.VisibilityStateProvider),
/* harmony export */   getLiveStateManager: () => (/* reexport safe */ _live_state_manager__WEBPACK_IMPORTED_MODULE_0__.getLiveStateManager)
/* harmony export */ });
/* harmony import */ var _live_state_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./live-state-manager */ "./src/content/live-state/live-state-manager.ts");
/* harmony import */ var _polling_engine__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./polling-engine */ "./src/content/live-state/polling-engine.ts");
/* harmony import */ var _providers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./providers */ "./src/content/live-state/providers/index.ts");
/**
 * Barrel exports for the live-state module.
 */





/***/ }),

/***/ "./src/content/live-state/live-state-manager.ts":
/*!******************************************************!*\
  !*** ./src/content/live-state/live-state-manager.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LiveStateManager: () => (/* binding */ LiveStateManager),
/* harmony export */   getLiveStateManager: () => (/* binding */ getLiveStateManager)
/* harmony export */ });
/**
 * LiveStateManager — singleton orchestrator for live page state collection.
 *
 * Registers IStateProvider instances, collects snapshots on demand,
 * and caches the latest result. Polling is deferred to Phase 3.
 */
/** Default navigation state when no provider is registered */
const DEFAULT_NAVIGATION = {
    currentUrl: '',
    scrollPercent: 0,
};
/** Default auth state when no provider is registered */
const DEFAULT_AUTH = {
    isLoggedIn: false,
    hasLoginForm: false,
    hasLogoutButton: false,
};
/** Default interactive state when no provider is registered */
const DEFAULT_INTERACTIVE = {
    openModals: [],
    expandedAccordions: [],
    openDropdowns: [],
    activeTooltips: [],
    visibleNotifications: [],
};
/** Default visibility state when no provider is registered */
const DEFAULT_VISIBILITY = {
    overlays: [],
    loadingIndicators: false,
};
/**
 * Orchestrates live-state collection across all registered providers.
 * Use `getLiveStateManager()` to obtain the singleton instance.
 */
class LiveStateManager {
    providers = [];
    latestSnapshot = null;
    running = false;
    /** Register a provider for a specific live-state category */
    registerProvider(provider) {
        this.providers.push(provider);
    }
    /** Return the first registered provider matching a given category */
    getProviderByCategory(category) {
        return this.providers.find((p) => p.category === category);
    }
    /** Synchronously collect a full snapshot from all registered providers */
    collectSnapshot(root = document) {
        let media = [];
        let forms = [];
        let navigation = DEFAULT_NAVIGATION;
        let auth = DEFAULT_AUTH;
        let interactive = DEFAULT_INTERACTIVE;
        let visibility = DEFAULT_VISIBILITY;
        for (const provider of this.providers) {
            const result = provider.collect(root);
            switch (provider.category) {
                case 'media':
                    media = Array.isArray(result)
                        ? result
                        : [result];
                    break;
                case 'form':
                    forms = Array.isArray(result)
                        ? result
                        : [result];
                    break;
                case 'navigation':
                    navigation = (Array.isArray(result) ? result[0] ?? DEFAULT_NAVIGATION : result);
                    break;
                case 'auth':
                    auth = (Array.isArray(result) ? result[0] ?? DEFAULT_AUTH : result);
                    break;
                case 'interactive':
                    interactive = (Array.isArray(result) ? result[0] ?? DEFAULT_INTERACTIVE : result);
                    break;
                case 'visibility':
                    visibility = (Array.isArray(result) ? result[0] ?? DEFAULT_VISIBILITY : result);
                    break;
            }
        }
        const snapshot = {
            timestamp: Date.now(),
            media,
            forms,
            navigation,
            auth,
            interactive,
            visibility,
        };
        this.latestSnapshot = snapshot;
        return snapshot;
    }
    /** Return the most recently collected snapshot, or null if none exists */
    getLatestSnapshot() {
        return this.latestSnapshot;
    }
    /** Mark the manager as running (polling deferred to Phase 3) */
    start() {
        this.running = true;
    }
    /** Stop the manager */
    stop() {
        this.running = false;
    }
    /** Whether the manager is currently running */
    isRunning() {
        return this.running;
    }
    /** Dispose all providers and reset internal state */
    dispose() {
        this.stop();
        for (const provider of this.providers) {
            provider.dispose();
        }
        this.providers.length = 0;
        this.latestSnapshot = null;
    }
}
// ── Singleton ──
let instance = null;
/** Get (or create) the singleton LiveStateManager instance */
function getLiveStateManager() {
    if (!instance) {
        instance = new LiveStateManager();
    }
    return instance;
}


/***/ }),

/***/ "./src/content/live-state/polling-engine.ts":
/*!**************************************************!*\
  !*** ./src/content/live-state/polling-engine.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PollingEngine: () => (/* binding */ PollingEngine)
/* harmony export */ });
/**
 * PollingEngine — adaptive interval-based polling for live-state collection.
 *
 * Uses setInterval (not requestAnimationFrame) since this runs in an
 * extension content script. Switches between idle and active polling
 * rates based on user activity, and triggers immediate (debounced)
 * snapshots on DOM mutations.
 */
/** Events that indicate user activity */
const ACTIVITY_EVENTS = [
    'mousemove',
    'keydown',
    'scroll',
    'click',
    'touchstart',
];
/** Time (ms) to remain in "active" mode after the last user interaction */
const ACTIVE_COOLDOWN_MS = 3000;
/** Debounce delay (ms) for mutation-triggered snapshots */
const MUTATION_DEBOUNCE_MS = 100;
class PollingEngine {
    manager;
    config;
    timerId = null;
    mutationObserver = null;
    mutationDebounceId = null;
    lastActivityTs = 0;
    running = false;
    /** Bound handler references for clean removal */
    onActivity = () => {
        const wasIdle = !this.isActive();
        this.lastActivityTs = Date.now();
        // Only reschedule on idle → active transition to avoid timer starvation
        if (wasIdle) {
            this.reschedule();
        }
    };
    constructor(manager, config) {
        this.manager = manager;
        this.config = config;
    }
    // ── Lifecycle ──
    start() {
        if (this.running)
            return;
        this.running = true;
        this.addActivityListeners();
        this.startMutationObserver();
        this.scheduleTimer(this.config.pollingIntervalMs);
    }
    stop() {
        if (!this.running)
            return;
        this.running = false;
        this.clearTimer();
        this.clearMutationDebounce();
        this.removeActivityListeners();
        this.stopMutationObserver();
    }
    dispose() {
        this.stop();
        // null-out to free references
        this.mutationObserver = null;
    }
    isRunning() {
        return this.running;
    }
    // ── Polling ──
    scheduleTimer(intervalMs) {
        this.clearTimer();
        this.timerId = setInterval(() => void this.tick(), intervalMs);
    }
    clearTimer() {
        if (this.timerId !== null) {
            clearInterval(this.timerId);
            this.timerId = null;
        }
    }
    /** Reschedule the timer when switching between idle/active rates */
    reschedule() {
        if (!this.running)
            return;
        const interval = this.isActive()
            ? this.config.activePollingIntervalMs
            : this.config.pollingIntervalMs;
        this.scheduleTimer(interval);
    }
    isActive() {
        return Date.now() - this.lastActivityTs < ACTIVE_COOLDOWN_MS;
    }
    /** Single poll tick: refresh async providers then collect a snapshot */
    async tick() {
        const mediaProvider = this.manager.getProviderByCategory('media');
        if (mediaProvider?.refreshAsync) {
            await mediaProvider.refreshAsync();
        }
        this.manager.collectSnapshot();
        // If we were active but cooldown has elapsed, drop back to idle rate
        if (!this.isActive()) {
            this.reschedule();
        }
    }
    // ── Activity Detection ──
    addActivityListeners() {
        for (const evt of ACTIVITY_EVENTS) {
            document.addEventListener(evt, this.onActivity, { passive: true });
        }
    }
    removeActivityListeners() {
        for (const evt of ACTIVITY_EVENTS) {
            document.removeEventListener(evt, this.onActivity);
        }
    }
    // ── MutationObserver ──
    startMutationObserver() {
        if (!document.body)
            return;
        this.mutationObserver = new MutationObserver(() => {
            this.debouncedMutationTick();
        });
        this.mutationObserver.observe(document.body, {
            childList: true,
            subtree: true,
        });
    }
    stopMutationObserver() {
        if (this.mutationObserver) {
            this.mutationObserver.disconnect();
        }
        this.clearMutationDebounce();
    }
    debouncedMutationTick() {
        this.clearMutationDebounce();
        this.mutationDebounceId = setTimeout(() => {
            this.mutationDebounceId = null;
            if (this.running) {
                void this.tick();
            }
        }, MUTATION_DEBOUNCE_MS);
    }
    clearMutationDebounce() {
        if (this.mutationDebounceId !== null) {
            clearTimeout(this.mutationDebounceId);
            this.mutationDebounceId = null;
        }
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/auth-state-provider.ts":
/*!*****************************************************************!*\
  !*** ./src/content/live-state/providers/auth-state-provider.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthStateProvider: () => (/* binding */ AuthStateProvider)
/* harmony export */ });
/**
 * AuthStateProvider — collects live state for authentication indicators.
 *
 * Uses DOM heuristics to detect login forms, logout controls,
 * and the currently visible user name.
 */
const LOGOUT_SELECTOR = [
    'a[href*="logout" i]',
    'a[href*="sign-out" i]',
    'button[class*="logout" i]',
    '[data-action="logout"]',
].join(', ');
const USERNAME_SELECTOR = [
    '[class*="avatar" i] img[alt]',
    '[class*="user" i][class*="name" i]',
    '[class*="profile" i] [class*="name" i]',
].join(', ');
/** Truncate a string to a maximum length */
function truncate(value, max = 100) {
    return value.length > max ? value.slice(0, max) : value;
}
class AuthStateProvider {
    category = 'auth';
    collect(root) {
        const hasLoginForm = !!root.querySelector('input[type="password"]');
        const hasLogoutButton = !!root.querySelector(LOGOUT_SELECTOR);
        const isLoggedIn = hasLogoutButton && !hasLoginForm;
        // Attempt to extract a user name from common patterns
        let userName;
        const candidate = root.querySelector(USERNAME_SELECTOR);
        if (candidate) {
            const text = candidate.alt?.trim() ||
                candidate.textContent?.trim() ||
                '';
            if (text)
                userName = truncate(text);
        }
        return {
            isLoggedIn,
            hasLoginForm,
            hasLogoutButton,
            ...(userName ? { userName } : {}),
        };
    }
    dispose() {
        /* no-op */
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/form-state-provider.ts":
/*!*****************************************************************!*\
  !*** ./src/content/live-state/providers/form-state-provider.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormStateProvider: () => (/* binding */ FormStateProvider)
/* harmony export */ });
/**
 * FormStateProvider — collects live state for forms on the page.
 *
 * Enumerates all <form> elements, counts fields, detects dirty/invalid
 * state, and computes a completion percentage.
 */
/** Input-like elements whose value can be inspected */
const FIELD_SELECTOR = 'input, select, textarea';
/** Max fields per form */
const MAX_FIELDS_PER_FORM = 30;
/** Max orphan fields */
const MAX_ORPHAN_FIELDS = 20;
/** Truncate a string to a maximum length */
function truncate(value, max = 100) {
    return value.length > max ? value.slice(0, max) : value;
}
/** Check whether a form field has a non-empty value */
function isFilled(el) {
    if (el instanceof HTMLInputElement) {
        if (el.type === 'checkbox' || el.type === 'radio')
            return el.checked;
        return el.value.trim().length > 0;
    }
    return el.value.trim().length > 0;
}
/** Derive a human-readable label for a field */
function fieldLabel(el) {
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel)
        return truncate(ariaLabel);
    const id = el.id;
    if (id) {
        try {
            const labelEl = el.ownerDocument?.querySelector(`label[for="${CSS.escape(id)}"]`);
            if (labelEl?.textContent?.trim())
                return truncate(labelEl.textContent.trim());
        }
        catch { /* malformed selector — skip */ }
    }
    const placeholder = el.placeholder;
    if (placeholder)
        return truncate(placeholder);
    const name = el.name;
    if (name)
        return truncate(name);
    if (id)
        return truncate(id);
    return '';
}
/** Get field value, masking passwords with fixed-length mask */
function getFieldValue(el) {
    if (el instanceof HTMLInputElement && el.type === 'password') {
        return el.value ? '******' : '';
    }
    if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) {
        return el.checked ? 'checked' : '';
    }
    return el.value;
}
/** Collect options for select elements */
function getSelectOptions(el) {
    return Array.from(el.options)
        .filter(opt => opt.value !== '')
        .map(opt => opt.text?.trim() || opt.value);
}
/** Collect option labels for radio groups */
function getRadioOptions(el, root) {
    if (!el.name)
        return [];
    try {
        const radios = root.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`);
        return Array.from(radios).map(r => fieldLabel(r) || r.value);
    }
    catch {
        return [];
    }
}
/** Build a FormFieldDetail for a single element */
function buildFieldDetail(el, root, index) {
    if (el instanceof HTMLInputElement && el.type === 'hidden')
        return null;
    const name = el.name
        || el.id
        || el.getAttribute('aria-label')
        || el.placeholder
        || el.getAttribute('data-testid')
        || (index !== undefined ? `field-${index}` : '');
    if (!name)
        return null;
    const type = el instanceof HTMLSelectElement
        ? 'select'
        : el instanceof HTMLTextAreaElement
            ? 'textarea'
            : el.type || 'text';
    let options;
    if (el instanceof HTMLSelectElement) {
        options = getSelectOptions(el);
    }
    else if (el instanceof HTMLInputElement && el.type === 'radio') {
        options = getRadioOptions(el, root);
    }
    return {
        name,
        label: fieldLabel(el),
        type,
        value: getFieldValue(el),
        filled: isFilled(el),
        required: el.required || el.getAttribute('aria-required') === 'true',
        valid: !el.matches(':invalid'),
        ...(options?.length ? { options } : {}),
    };
}
class FormStateProvider {
    category = 'form';
    collect(root) {
        const forms = root.querySelectorAll('form');
        const results = [];
        const formFieldElements = new Set();
        forms.forEach((form, index) => {
            const fieldEls = form.querySelectorAll(FIELD_SELECTOR);
            const totalFields = fieldEls.length;
            let filledFields = 0;
            const dirtyFields = [];
            let hasValidationErrors = false;
            const fields = [];
            fieldEls.forEach((field, fieldIndex) => {
                const el = field;
                formFieldElements.add(el);
                if (isFilled(el))
                    filledFields++;
                if (el instanceof HTMLInputElement &&
                    (el.type === 'checkbox' || el.type === 'radio')) {
                    if (el.checked !== el.defaultChecked)
                        dirtyFields.push(fieldLabel(el));
                }
                else if (el instanceof HTMLSelectElement) {
                    const isDirty = Array.from(el.options).some((opt) => opt.selected !== opt.defaultSelected);
                    if (isDirty)
                        dirtyFields.push(fieldLabel(el));
                }
                else if ('defaultValue' in el && el.value !== el.defaultValue) {
                    dirtyFields.push(fieldLabel(el));
                }
                if (el.matches(':invalid')) {
                    hasValidationErrors = true;
                }
                if (fields.length < MAX_FIELDS_PER_FORM) {
                    const detail = buildFieldDetail(el, root, fieldIndex);
                    if (detail)
                        fields.push(detail);
                }
            });
            const completionPercent = totalFields > 0 ? Math.round((filledFields / totalFields) * 100) : 0;
            results.push({
                formId: form.id || form.getAttribute('toolname') || String(index),
                toolName: form.getAttribute('toolname') || '',
                totalFields,
                filledFields,
                dirtyFields,
                hasValidationErrors,
                completionPercent,
                fields,
            });
        });
        // Orphan inputs (not inside any <form>)
        const allFieldEls = root.querySelectorAll(FIELD_SELECTOR);
        const orphanFields = [];
        let orphanFilled = 0;
        let orphanTotal = 0;
        let orphanErrors = false;
        const orphanDirty = [];
        let orphanIndex = 0;
        allFieldEls.forEach((field) => {
            if (formFieldElements.has(field))
                return;
            const el = field;
            if (el instanceof HTMLInputElement && el.type === 'hidden')
                return;
            orphanTotal++;
            if (isFilled(el))
                orphanFilled++;
            if (el.matches(':invalid'))
                orphanErrors = true;
            if ('defaultValue' in el && el.value !== el.defaultValue) {
                orphanDirty.push(fieldLabel(el));
            }
            if (orphanFields.length < MAX_ORPHAN_FIELDS) {
                const detail = buildFieldDetail(el, root, orphanIndex);
                if (detail)
                    orphanFields.push(detail);
            }
            orphanIndex++;
        });
        if (orphanFields.length > 0) {
            results.push({
                formId: 'orphan',
                toolName: '',
                totalFields: orphanTotal,
                filledFields: orphanFilled,
                dirtyFields: orphanDirty,
                hasValidationErrors: orphanErrors,
                completionPercent: orphanTotal > 0 ? Math.round((orphanFilled / orphanTotal) * 100) : 0,
                fields: orphanFields,
            });
        }
        return results;
    }
    dispose() {
        /* no-op */
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/index.ts":
/*!***************************************************!*\
  !*** ./src/content/live-state/providers/index.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthStateProvider: () => (/* reexport safe */ _auth_state_provider__WEBPACK_IMPORTED_MODULE_3__.AuthStateProvider),
/* harmony export */   FormStateProvider: () => (/* reexport safe */ _form_state_provider__WEBPACK_IMPORTED_MODULE_1__.FormStateProvider),
/* harmony export */   InteractiveStateProvider: () => (/* reexport safe */ _interactive_state_provider__WEBPACK_IMPORTED_MODULE_4__.InteractiveStateProvider),
/* harmony export */   MediaStateProvider: () => (/* reexport safe */ _media_state_provider__WEBPACK_IMPORTED_MODULE_0__.MediaStateProvider),
/* harmony export */   NavigationStateProvider: () => (/* reexport safe */ _navigation_state_provider__WEBPACK_IMPORTED_MODULE_2__.NavigationStateProvider),
/* harmony export */   VisibilityStateProvider: () => (/* reexport safe */ _visibility_state_provider__WEBPACK_IMPORTED_MODULE_5__.VisibilityStateProvider)
/* harmony export */ });
/* harmony import */ var _media_state_provider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./media-state-provider */ "./src/content/live-state/providers/media-state-provider.ts");
/* harmony import */ var _form_state_provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form-state-provider */ "./src/content/live-state/providers/form-state-provider.ts");
/* harmony import */ var _navigation_state_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation-state-provider */ "./src/content/live-state/providers/navigation-state-provider.ts");
/* harmony import */ var _auth_state_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth-state-provider */ "./src/content/live-state/providers/auth-state-provider.ts");
/* harmony import */ var _interactive_state_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./interactive-state-provider */ "./src/content/live-state/providers/interactive-state-provider.ts");
/* harmony import */ var _visibility_state_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./visibility-state-provider */ "./src/content/live-state/providers/visibility-state-provider.ts");
/**
 * Barrel exports for live-state providers.
 */








/***/ }),

/***/ "./src/content/live-state/providers/interactive-state-provider.ts":
/*!************************************************************************!*\
  !*** ./src/content/live-state/providers/interactive-state-provider.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InteractiveStateProvider: () => (/* binding */ InteractiveStateProvider)
/* harmony export */ });
/**
 * InteractiveStateProvider — collects live state for interactive UI widgets.
 *
 * Detects open modals, expanded accordions, open dropdowns,
 * active tooltips, and visible notifications.
 */
const MODAL_SELECTOR = [
    'dialog[open]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.modal.show',
    '.modal.open',
    '[class*="modal" i][class*="open" i]',
].join(', ');
const DROPDOWN_SELECTOR = [
    '[role="listbox"]:not([aria-hidden="true"])',
    'select:focus',
    '[role="combobox"][aria-expanded="true"]',
].join(', ');
const NOTIFICATION_SELECTOR = [
    '[role="alert"]',
    '[role="status"]',
    '[class*="toast" i]:not([aria-hidden="true"])',
    '[class*="notification" i]:not([aria-hidden="true"])',
].join(', ');
/** Truncate a string to a maximum length */
function truncate(value, max = 100) {
    return value.length > max ? value.slice(0, max) : value;
}
/** Extract a label from an element: aria-label, first heading, or trimmed text */
function extractLabel(el) {
    const ariaLabel = el.getAttribute('aria-label')?.trim();
    if (ariaLabel)
        return truncate(ariaLabel);
    const heading = el.querySelector('h1, h2, h3, h4');
    if (heading?.textContent?.trim())
        return truncate(heading.textContent.trim());
    const text = el.textContent?.trim();
    return text ? truncate(text) : '';
}
class InteractiveStateProvider {
    category = 'interactive';
    collect(root) {
        // Open modals
        const openModals = Array.from(root.querySelectorAll(MODAL_SELECTOR)).map(extractLabel);
        // Expanded accordions (limit to 10)
        const expandedAccordions = Array.from(root.querySelectorAll('[aria-expanded="true"]'))
            .slice(0, 10)
            .map((el) => {
            const label = el.getAttribute('aria-label')?.trim() || el.textContent?.trim() || '';
            return truncate(label);
        });
        // Open dropdowns
        const openDropdowns = Array.from(root.querySelectorAll(DROPDOWN_SELECTOR)).map((el) => {
            const label = el.getAttribute('aria-label')?.trim() || el.textContent?.trim() || '';
            return truncate(label);
        });
        // Active tooltips
        const activeTooltips = Array.from(root.querySelectorAll('[role="tooltip"]:not([aria-hidden="true"])')).map((el) => truncate(el.textContent?.trim() || ''));
        // Visible notifications (limit to 5)
        const visibleNotifications = Array.from(root.querySelectorAll(NOTIFICATION_SELECTOR))
            .slice(0, 5)
            .map((el) => truncate(el.textContent?.trim() || ''));
        return {
            openModals,
            expandedAccordions,
            openDropdowns,
            activeTooltips,
            visibleNotifications,
        };
    }
    dispose() {
        /* no-op */
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/media-state-provider.ts":
/*!******************************************************************!*\
  !*** ./src/content/live-state/providers/media-state-provider.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MediaStateProvider: () => (/* binding */ MediaStateProvider)
/* harmony export */ });
/* harmony import */ var _media_player_registry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../media/player-registry */ "./src/content/media/player-registry.ts");
/**
 * MediaStateProvider — collects live state for media players on the page.
 *
 * Uses the PlayerRegistry to discover players and caches their async state
 * so that the synchronous collect() contract of IStateProvider is satisfied.
 */

/** Truncate a string to a maximum length */
function truncate(value, max = 100) {
    return value.length > max ? value.slice(0, max) : value;
}
/** Detect if a video element is currently in fullscreen */
function isFullscreen(el) {
    if (!el)
        return false;
    try {
        const fsEl = el.ownerDocument?.fullscreenElement;
        if (!fsEl)
            return false;
        return fsEl === el || fsEl.contains(el) || el.contains(fsEl);
    }
    catch {
        return false;
    }
}
/** Detect if captions/subtitles are active on a media element */
function hasCaptionsActive(el) {
    if (!el || !(el instanceof HTMLMediaElement))
        return false;
    try {
        const tracks = el.textTracks;
        for (let i = 0; i < tracks.length; i++) {
            if (tracks[i].mode === 'showing')
                return true;
        }
    }
    catch {
        // Ignore cross-origin or unavailable textTracks
    }
    return false;
}
class MediaStateProvider {
    category = 'media';
    cache = new Map();
    collect(_root) {
        const registry = (0,_media_player_registry__WEBPACK_IMPORTED_MODULE_0__.getPlayerRegistry)();
        const alivePlayers = registry.getAll();
        const aliveIds = new Set(alivePlayers.map((p) => p.id));
        // Prune stale entries
        for (const id of this.cache.keys()) {
            if (!aliveIds.has(id)) {
                this.cache.delete(id);
            }
        }
        return Array.from(this.cache.values());
    }
    /**
     * Asynchronously refresh the cache by awaiting getState() on each player.
     * Call this before collectSnapshot() when an up-to-date read is needed.
     */
    async refreshAsync(root = document) {
        const registry = (0,_media_player_registry__WEBPACK_IMPORTED_MODULE_0__.getPlayerRegistry)();
        const players = registry.refresh(root);
        const entries = await Promise.all(players.map(async (player) => {
            try {
                const s = await player.getState();
                const state = {
                    playerId: player.id,
                    platform: s.platform,
                    title: truncate(s.title),
                    paused: s.paused,
                    currentTime: s.currentTime,
                    duration: s.duration,
                    volume: s.volume,
                    muted: s.muted,
                    fullscreen: isFullscreen(player.anchorElement),
                    captions: hasCaptionsActive(player.anchorElement),
                    playbackRate: s.playbackRate,
                    hasPlaylist: s.hasPlaylist,
                    ...(s.playlistIndex !== undefined && { playlistIndex: s.playlistIndex }),
                    ...(s.playlistLength !== undefined && { playlistLength: s.playlistLength }),
                };
                return [player.id, state];
            }
            catch {
                return null;
            }
        }));
        this.cache.clear();
        for (const entry of entries) {
            if (entry) {
                this.cache.set(entry[0], entry[1]);
            }
        }
    }
    dispose() {
        this.cache.clear();
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/navigation-state-provider.ts":
/*!***********************************************************************!*\
  !*** ./src/content/live-state/providers/navigation-state-provider.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NavigationStateProvider: () => (/* binding */ NavigationStateProvider)
/* harmony export */ });
/**
 * NavigationStateProvider — collects live state for page navigation.
 *
 * Reports the current URL, scroll position, visible heading section,
 * active ARIA tab, and breadcrumb trail.
 */
/** Truncate a string to a maximum length */
function truncate(value, max = 100) {
    return value.length > max ? value.slice(0, max) : value;
}
/** Find the heading (h1-h3) closest to the top of the viewport */
function findVisibleSection(root) {
    const headings = root.querySelectorAll('h1, h2, h3');
    let best;
    let bestDistance = Infinity;
    headings.forEach((h) => {
        const rect = h.getBoundingClientRect();
        const distance = Math.abs(rect.top);
        if (distance < bestDistance) {
            bestDistance = distance;
            best = h;
        }
    });
    const text = best ? best.textContent?.trim() : undefined;
    return text ? truncate(text) : undefined;
}
class NavigationStateProvider {
    category = 'navigation';
    collect(root) {
        const doc = root instanceof Document ? root : root.ownerDocument;
        // Scroll percentage (clamped 0–100)
        const scrollHeight = doc.documentElement.scrollHeight - window.innerHeight;
        const rawPercent = scrollHeight > 0
            ? Math.round((window.scrollY / scrollHeight) * 100)
            : 0;
        const scrollPercent = Math.max(0, Math.min(100, rawPercent));
        // Active ARIA tab
        const activeTabEl = root.querySelector('[role="tab"][aria-selected="true"]');
        const activeTab = activeTabEl?.textContent?.trim();
        // Breadcrumb trail
        const crumbEls = root.querySelectorAll('nav[aria-label*="breadcrumb" i] a, [class*="breadcrumb" i] a');
        const breadcrumb = crumbEls.length > 0
            ? Array.from(crumbEls)
                .map((el) => truncate(el.textContent?.trim() || ''))
                .filter(Boolean)
            : undefined;
        return {
            currentUrl: doc.location?.href ?? '',
            scrollPercent,
            visibleSection: findVisibleSection(root),
            ...(activeTab ? { activeTab: truncate(activeTab) } : {}),
            ...(breadcrumb ? { breadcrumb } : {}),
        };
    }
    dispose() {
        /* no-op */
    }
}


/***/ }),

/***/ "./src/content/live-state/providers/visibility-state-provider.ts":
/*!***********************************************************************!*\
  !*** ./src/content/live-state/providers/visibility-state-provider.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VisibilityStateProvider: () => (/* binding */ VisibilityStateProvider)
/* harmony export */ });
/**
 * VisibilityStateProvider — collects live state for DOM visibility context.
 *
 * Detects overlays (cookie banners, popups blocking content) and
 * loading indicators (spinners, skeleton screens).
 */
const OVERLAY_SELECTORS = [
    // Cookie/consent banners
    '[class*="cookie" i][class*="banner" i]',
    '[class*="cookie" i][class*="consent" i]',
    '[class*="consent" i][class*="banner" i]',
    '[id*="cookie" i][id*="banner" i]',
    '[id*="cookie" i][id*="consent" i]',
    '[id*="consent" i][id*="banner" i]',
    '[id*="consent" i][id*="popup" i]',
    '[id*="consent" i][id*="modal" i]',
    // Generic overlays / popups
    '[class*="overlay" i]:not([aria-hidden="true"])',
    '[class*="popup" i]:not([aria-hidden="true"]):not([style*="display: none"])',
    '[class*="lightbox" i]:not([aria-hidden="true"])',
    // GDPR / privacy
    '[class*="gdpr" i]',
    '[class*="privacy" i][class*="banner" i]',
];
const LOADING_SELECTORS = [
    // Spinners
    '[class*="spinner" i]',
    '[class~="loading" i]',
    '.is-loading',
    '[aria-busy="true"]',
    '[role="progressbar"]',
    // Skeleton screens
    '[class*="skeleton" i]',
    '[class*="shimmer" i]',
    '[class*="placeholder" i][class*="loading" i]',
];
/** Truncate a string to a maximum length */
function truncate(value, max = 80) {
    return value.length > max ? value.slice(0, max) : value;
}
/** Check whether an element is visible in the viewport */
function isVisibleInViewport(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0)
        return false;
    const computed = window.getComputedStyle(el);
    if (computed.display === 'none' || computed.visibility === 'hidden')
        return false;
    return (rect.top < window.innerHeight &&
        rect.bottom > 0 &&
        rect.left < window.innerWidth &&
        rect.right > 0);
}
/** Extract a human-readable label from an overlay element */
function extractOverlayLabel(el) {
    const ariaLabel = el.getAttribute('aria-label')?.trim();
    if (ariaLabel)
        return truncate(ariaLabel);
    const heading = el.querySelector('h1, h2, h3, h4, h5');
    if (heading?.textContent?.trim())
        return truncate(heading.textContent.trim());
    const id = el.id;
    if (id)
        return truncate(id);
    const cls = el.className;
    if (typeof cls === 'string' && cls.trim()) {
        return truncate(cls.trim().split(/\s+/).slice(0, 3).join(' '));
    }
    return 'unknown overlay';
}
class VisibilityStateProvider {
    category = 'visibility';
    collect(root) {
        // Detect visible overlays
        const overlays = [];
        const seen = new Set();
        for (const selector of OVERLAY_SELECTORS) {
            try {
                const elements = root.querySelectorAll(selector);
                for (const el of elements) {
                    if (seen.has(el))
                        continue;
                    seen.add(el);
                    if (isVisibleInViewport(el)) {
                        overlays.push(extractOverlayLabel(el));
                    }
                }
            }
            catch {
                // Invalid selector in this DOM — skip
            }
        }
        // Detect loading indicators
        let loadingIndicators = false;
        for (const selector of LOADING_SELECTORS) {
            try {
                const elements = root.querySelectorAll(selector);
                for (const el of elements) {
                    if (isVisibleInViewport(el)) {
                        loadingIndicators = true;
                        break;
                    }
                }
            }
            catch {
                // Skip
            }
            if (loadingIndicators)
                break;
        }
        return {
            overlays: overlays.slice(0, 5),
            loadingIndicators,
        };
    }
    dispose() {
        /* no-op */
    }
}


/***/ }),

/***/ "./src/content/media/audio-embeds/bandcamp-player.ts":
/*!***********************************************************!*\
  !*** ./src/content/media/audio-embeds/bandcamp-player.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BandcampPlayer: () => (/* binding */ BandcampPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const BANDCAMP_ALLOWED_ORIGINS = new Set([
    'https://bandcamp.com',
    'https://www.bandcamp.com',
]);
const BANDCAMP_CAPABILITIES = {
    play: true,
    pause: true,
    seek: false,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class BandcampPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'bandcamp';
    capabilities = BANDCAMP_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const eventName = this.readString(payload.event);
        if (eventName === 'play')
            this.snapshot.paused = false;
        if (eventName === 'pause')
            this.snapshot.paused = true;
        const data = payload.data;
        if (!data || typeof data !== 'object')
            return;
        const record = data;
        if (typeof record.currentTime === 'number')
            this.snapshot.currentTime = record.currentTime;
        if (typeof record.duration === 'number')
            this.snapshot.duration = record.duration;
        if (typeof record.volume === 'number') {
            const normalized = record.volume > 1 ? record.volume / 100 : record.volume;
            this.snapshot.volume = this.clampVolume(normalized);
            if (this.snapshot.volume > 0)
                this.lastNonZeroVolume = this.snapshot.volume;
        }
        if (typeof record.title === 'string')
            this.snapshot.title = record.title;
    };
    constructor(id, iframe) {
        super(id, 'bandcamp', BANDCAMP_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid Bandcamp iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postCommand('play');
    }
    async pause() {
        this.postCommand('pause');
    }
    async seek(_time) {
        throw new Error('Bandcamp seek is not supported');
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postCommand('setVolume', { volume: normalized });
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postCommand('setVolume', { volume: 0 });
        this.snapshot.volume = 0;
    }
    async unmute() {
        const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
        this.postCommand('setVolume', { volume: restore });
        this.snapshot.volume = restore;
    }
    async getState() {
        this.postCommand('getState');
        const volume = this.snapshot.volume ?? 1;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume,
            muted: volume === 0,
            playbackRate: 1,
            title: this.snapshot.title ?? this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postCommand(command, payload) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('Bandcamp iframe window unavailable');
        targetWindow.postMessage({ command, ...(payload ?? {}) }, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!BANDCAMP_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
    readString(value) {
        return typeof value === 'string' ? value : null;
    }
}


/***/ }),

/***/ "./src/content/media/audio-embeds/soundcloud-player.ts":
/*!*************************************************************!*\
  !*** ./src/content/media/audio-embeds/soundcloud-player.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SoundCloudPlayer: () => (/* binding */ SoundCloudPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const SOUNDCLOUD_ALLOWED_ORIGINS = new Set(['https://w.soundcloud.com']);
const SOUNDCLOUD_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: true,
    previousTrack: true,
    shuffle: false,
};
class SoundCloudPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'soundcloud';
    capabilities = SOUNDCLOUD_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const method = this.readString(payload.method);
        const value = payload.value;
        const eventName = this.readString(payload.event);
        if (eventName === 'play')
            this.snapshot.paused = false;
        if (eventName === 'pause')
            this.snapshot.paused = true;
        if (method === 'getPosition' && typeof value === 'number') {
            this.snapshot.currentTime = value / 1000;
        }
        if (method === 'getDuration' && typeof value === 'number') {
            this.snapshot.duration = value / 1000;
        }
        if (method === 'getVolume' && typeof value === 'number') {
            const normalized = value > 1 ? value / 100 : value;
            this.snapshot.volume = this.clampVolume(normalized);
            if (this.snapshot.volume > 0)
                this.lastNonZeroVolume = this.snapshot.volume;
        }
        if (method === 'getCurrentSound' && typeof value === 'object' && value) {
            const title = value.title;
            if (typeof title === 'string')
                this.snapshot.title = title;
        }
    };
    constructor(id, iframe) {
        super(id, 'soundcloud', SOUNDCLOUD_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid SoundCloud iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postMethod('play');
    }
    async pause() {
        this.postMethod('pause');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postMethod('seekTo', Math.round(normalized * 1000));
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postMethod('setVolume', Math.round(normalized * 100));
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postMethod('setVolume', 0);
        this.snapshot.volume = 0;
    }
    async unmute() {
        const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
        this.postMethod('setVolume', Math.round(restore * 100));
        this.snapshot.volume = restore;
    }
    async nextTrack() {
        this.postMethod('next');
    }
    async previousTrack() {
        this.postMethod('prev');
    }
    async getState() {
        this.postMethod('getPosition');
        this.postMethod('getDuration');
        this.postMethod('getVolume');
        this.postMethod('getCurrentSound');
        const volume = this.snapshot.volume ?? 1;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume,
            muted: volume === 0,
            playbackRate: 1,
            title: this.snapshot.title ?? this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: true,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postMethod(method, value) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('SoundCloud iframe window unavailable');
        const payload = value === undefined ? { method } : { method, value };
        targetWindow.postMessage(payload, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!SOUNDCLOUD_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
    readString(value) {
        return typeof value === 'string' ? value : null;
    }
}


/***/ }),

/***/ "./src/content/media/audio-embeds/spotify-player.ts":
/*!**********************************************************!*\
  !*** ./src/content/media/audio-embeds/spotify-player.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SpotifyPlayer: () => (/* binding */ SpotifyPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const SPOTIFY_ALLOWED_ORIGINS = new Set(['https://open.spotify.com']);
const SPOTIFY_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: true,
    previousTrack: true,
    shuffle: true,
};
class SpotifyPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'spotify';
    capabilities = SPOTIFY_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const data = payload.data;
        if (!data || typeof data !== 'object')
            return;
        const record = data;
        if (typeof record.position === 'number')
            this.snapshot.currentTime = record.position / 1000;
        if (typeof record.duration === 'number')
            this.snapshot.duration = record.duration / 1000;
        if (typeof record.paused === 'boolean')
            this.snapshot.paused = record.paused;
        if (typeof record.volume === 'number') {
            const normalized = record.volume > 1 ? record.volume / 100 : record.volume;
            this.snapshot.volume = this.clampVolume(normalized);
            if (this.snapshot.volume > 0)
                this.lastNonZeroVolume = this.snapshot.volume;
        }
        if (typeof record.muted === 'boolean')
            this.snapshot.muted = record.muted;
        if (typeof record.title === 'string')
            this.snapshot.title = record.title;
        if (typeof record.trackIndex === 'number')
            this.snapshot.playlistIndex = record.trackIndex;
        if (typeof record.trackCount === 'number')
            this.snapshot.playlistLength = record.trackCount;
    };
    constructor(id, iframe) {
        super(id, 'spotify', SPOTIFY_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid Spotify iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postCommand('play');
    }
    async pause() {
        this.postCommand('pause');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postCommand('seek', { positionMs: Math.round(normalized * 1000) });
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postCommand('setVolume', { volume: normalized });
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postCommand('setMuted', { muted: true });
        this.snapshot.muted = true;
        this.snapshot.volume = 0;
    }
    async unmute() {
        this.postCommand('setMuted', { muted: false });
        this.snapshot.muted = false;
        if ((this.snapshot.volume ?? 0) === 0) {
            const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
            this.postCommand('setVolume', { volume: restore });
            this.snapshot.volume = restore;
        }
    }
    async nextTrack() {
        this.postCommand('next');
    }
    async previousTrack() {
        this.postCommand('previous');
    }
    async shuffle() {
        this.postCommand('toggleShuffle', { enabled: true });
    }
    async getState() {
        this.postCommand('getState');
        const volume = this.snapshot.volume ?? 1;
        const muted = this.snapshot.muted ?? volume === 0;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume,
            muted,
            playbackRate: 1,
            title: this.snapshot.title ?? this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: true,
            playlistIndex: this.snapshot.playlistIndex,
            playlistLength: this.snapshot.playlistLength,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postCommand(command, payload) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('Spotify iframe window unavailable');
        targetWindow.postMessage({ command, ...(payload ?? {}) }, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!SPOTIFY_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
}


/***/ }),

/***/ "./src/content/media/base-player.ts":
/*!******************************************!*\
  !*** ./src/content/media/base-player.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BasePlayer: () => (/* binding */ BasePlayer)
/* harmony export */ });
class BasePlayer {
    id;
    platform;
    capabilities;
    constructor(id, platform, capabilities) {
        this.id = id;
        this.platform = platform;
        this.capabilities = capabilities;
    }
    async nextTrack() {
        throw new Error(`nextTrack not supported for platform "${this.platform}"`);
    }
    async previousTrack() {
        throw new Error(`previousTrack not supported for platform "${this.platform}"`);
    }
    async shuffle() {
        throw new Error(`shuffle not supported for platform "${this.platform}"`);
    }
    isAlive() {
        return this.anchorElement ? document.contains(this.anchorElement) : true;
    }
    dispose() {
        // no-op by default
    }
    clampVolume(level) {
        if (!Number.isFinite(level))
            return 1;
        return Math.min(1, Math.max(0, level));
    }
    clampSeek(time, duration) {
        const normalized = Number.isFinite(time) ? Math.max(0, time) : 0;
        if (!Number.isFinite(duration) || duration <= 0)
            return normalized;
        return Math.min(normalized, duration);
    }
    readElementTitle(el) {
        if (!el)
            return '';
        const attrTitle = el.getAttribute('title');
        if (attrTitle)
            return attrTitle.trim();
        const ariaLabel = el.getAttribute('aria-label');
        if (ariaLabel)
            return ariaLabel.trim();
        return '';
    }
}


/***/ }),

/***/ "./src/content/media/custom-players/base-custom-native-player.ts":
/*!***********************************************************************!*\
  !*** ./src/content/media/custom-players/base-custom-native-player.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseCustomNativePlayer: () => (/* binding */ BaseCustomNativePlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const CUSTOM_NATIVE_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class BaseCustomNativePlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    mediaElement;
    rootElement;
    capabilities = CUSTOM_NATIVE_CAPABILITIES;
    constructor(id, platform, mediaElement, rootElement) {
        super(id, platform, CUSTOM_NATIVE_CAPABILITIES);
        this.id = id;
        this.mediaElement = mediaElement;
        this.rootElement = rootElement;
    }
    get anchorElement() {
        return this.rootElement;
    }
    async play() {
        await this.mediaElement.play();
    }
    async pause() {
        this.mediaElement.pause();
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.mediaElement.duration);
        this.mediaElement.currentTime = normalized;
    }
    async setVolume(level) {
        this.mediaElement.volume = this.clampVolume(level);
    }
    async mute() {
        this.mediaElement.muted = true;
    }
    async unmute() {
        this.mediaElement.muted = false;
    }
    async getState() {
        return {
            currentTime: Number.isFinite(this.mediaElement.currentTime)
                ? this.mediaElement.currentTime
                : 0,
            duration: Number.isFinite(this.mediaElement.duration)
                ? this.mediaElement.duration
                : 0,
            paused: this.mediaElement.paused,
            volume: this.mediaElement.volume,
            muted: this.mediaElement.muted,
            playbackRate: this.mediaElement.playbackRate,
            title: this.readElementTitle(this.rootElement),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return document.contains(this.rootElement) && document.contains(this.mediaElement);
    }
}


/***/ }),

/***/ "./src/content/media/custom-players/jwplayer-player.ts":
/*!*************************************************************!*\
  !*** ./src/content/media/custom-players/jwplayer-player.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JWPlayerAdapter: () => (/* binding */ JWPlayerAdapter)
/* harmony export */ });
/* harmony import */ var _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-custom-native-player */ "./src/content/media/custom-players/base-custom-native-player.ts");

class JWPlayerAdapter extends _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__.BaseCustomNativePlayer {
    platform = 'jwplayer';
    constructor(id, mediaElement, rootElement) {
        super(id, 'jwplayer', mediaElement, rootElement);
    }
}


/***/ }),

/***/ "./src/content/media/custom-players/mediaelement-player.ts":
/*!*****************************************************************!*\
  !*** ./src/content/media/custom-players/mediaelement-player.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MediaElementPlayer: () => (/* binding */ MediaElementPlayer)
/* harmony export */ });
/* harmony import */ var _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-custom-native-player */ "./src/content/media/custom-players/base-custom-native-player.ts");

class MediaElementPlayer extends _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__.BaseCustomNativePlayer {
    platform = 'mediaelement';
    constructor(id, mediaElement, rootElement) {
        super(id, 'mediaelement', mediaElement, rootElement);
    }
}


/***/ }),

/***/ "./src/content/media/custom-players/plyr-player.ts":
/*!*********************************************************!*\
  !*** ./src/content/media/custom-players/plyr-player.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlyrPlayer: () => (/* binding */ PlyrPlayer)
/* harmony export */ });
/* harmony import */ var _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-custom-native-player */ "./src/content/media/custom-players/base-custom-native-player.ts");

class PlyrPlayer extends _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__.BaseCustomNativePlayer {
    platform = 'plyr';
    constructor(id, mediaElement, rootElement) {
        super(id, 'plyr', mediaElement, rootElement);
    }
}


/***/ }),

/***/ "./src/content/media/custom-players/videojs-player.ts":
/*!************************************************************!*\
  !*** ./src/content/media/custom-players/videojs-player.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VideoJsPlayer: () => (/* binding */ VideoJsPlayer)
/* harmony export */ });
/* harmony import */ var _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-custom-native-player */ "./src/content/media/custom-players/base-custom-native-player.ts");

class VideoJsPlayer extends _base_custom_native_player__WEBPACK_IMPORTED_MODULE_0__.BaseCustomNativePlayer {
    platform = 'videojs';
    constructor(id, mediaElement, rootElement) {
        super(id, 'videojs', mediaElement, rootElement);
    }
}


/***/ }),

/***/ "./src/content/media/iframe-players/dailymotion-player.ts":
/*!****************************************************************!*\
  !*** ./src/content/media/iframe-players/dailymotion-player.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DailymotionPlayer: () => (/* binding */ DailymotionPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const DAILYMOTION_ALLOWED_ORIGINS = new Set(['https://www.dailymotion.com']);
const DAILYMOTION_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class DailymotionPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'dailymotion';
    capabilities = DAILYMOTION_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const eventName = this.readString(payload.event);
        const data = payload.data;
        if (eventName === 'video_start' || eventName === 'play')
            this.snapshot.paused = false;
        if (eventName === 'pause' || eventName === 'video_end')
            this.snapshot.paused = true;
        if (typeof data === 'object' && data) {
            const record = data;
            if (typeof record.time === 'number')
                this.snapshot.currentTime = record.time;
            if (typeof record.duration === 'number')
                this.snapshot.duration = record.duration;
            if (typeof record.volume === 'number') {
                this.snapshot.volume = record.volume;
                if (record.volume > 0)
                    this.lastNonZeroVolume = record.volume;
            }
            if (typeof record.muted === 'boolean')
                this.snapshot.muted = record.muted;
        }
    };
    constructor(id, iframe) {
        super(id, 'dailymotion', DAILYMOTION_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid Dailymotion iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postCommand('play');
    }
    async pause() {
        this.postCommand('pause');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postCommand('seek', [normalized]);
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postCommand('setVolume', [normalized]);
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postCommand('setMuted', [true]);
        this.snapshot.muted = true;
        this.snapshot.volume = 0;
    }
    async unmute() {
        this.postCommand('setMuted', [false]);
        this.snapshot.muted = false;
        if ((this.snapshot.volume ?? 0) === 0) {
            const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
            this.postCommand('setVolume', [restore]);
            this.snapshot.volume = restore;
        }
    }
    async getState() {
        this.postCommand('getState');
        const volume = this.snapshot.volume ?? 1;
        const muted = this.snapshot.muted ?? volume === 0;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume: this.clampVolume(volume),
            muted,
            playbackRate: 1,
            title: this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postCommand(command, parameters = []) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('Dailymotion iframe window unavailable');
        targetWindow.postMessage({ command, parameters }, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!DAILYMOTION_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
    readString(value) {
        return typeof value === 'string' ? value : null;
    }
}


/***/ }),

/***/ "./src/content/media/iframe-players/twitch-player.ts":
/*!***********************************************************!*\
  !*** ./src/content/media/iframe-players/twitch-player.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TwitchPlayer: () => (/* binding */ TwitchPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const TWITCH_ALLOWED_ORIGINS = new Set([
    'https://player.twitch.tv',
    'https://www.twitch.tv',
]);
const TWITCH_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class TwitchPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'twitch';
    capabilities = TWITCH_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const eventName = this.readString(payload.event);
        if (eventName === 'play')
            this.snapshot.paused = false;
        if (eventName === 'pause')
            this.snapshot.paused = true;
        const data = payload.data;
        if (typeof data !== 'object' || !data)
            return;
        const record = data;
        if (typeof record.currentTime === 'number')
            this.snapshot.currentTime = record.currentTime;
        if (typeof record.duration === 'number')
            this.snapshot.duration = record.duration;
        if (typeof record.volume === 'number') {
            this.snapshot.volume = record.volume;
            if (record.volume > 0)
                this.lastNonZeroVolume = record.volume;
        }
        if (typeof record.muted === 'boolean')
            this.snapshot.muted = record.muted;
        if (typeof record.paused === 'boolean')
            this.snapshot.paused = record.paused;
    };
    constructor(id, iframe) {
        super(id, 'twitch', TWITCH_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid Twitch iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postCommand('play');
    }
    async pause() {
        this.postCommand('pause');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postCommand('seek', [normalized]);
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postCommand('setVolume', [normalized]);
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postCommand('setMuted', [true]);
        this.snapshot.muted = true;
        this.snapshot.volume = 0;
    }
    async unmute() {
        this.postCommand('setMuted', [false]);
        this.snapshot.muted = false;
        if ((this.snapshot.volume ?? 0) === 0) {
            const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
            this.postCommand('setVolume', [restore]);
            this.snapshot.volume = restore;
        }
    }
    async getState() {
        this.postCommand('getState');
        const volume = this.snapshot.volume ?? 1;
        const muted = this.snapshot.muted ?? volume === 0;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume: this.clampVolume(volume),
            muted,
            playbackRate: 1,
            title: this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postCommand(command, args = []) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('Twitch iframe window unavailable');
        targetWindow.postMessage({ command, args }, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!TWITCH_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
    readString(value) {
        return typeof value === 'string' ? value : null;
    }
}


/***/ }),

/***/ "./src/content/media/iframe-players/vimeo-player.ts":
/*!**********************************************************!*\
  !*** ./src/content/media/iframe-players/vimeo-player.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VimeoPlayer: () => (/* binding */ VimeoPlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const VIMEO_ALLOWED_ORIGINS = new Set(['https://player.vimeo.com']);
const VIMEO_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class VimeoPlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'vimeo';
    capabilities = VIMEO_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    lastNonZeroVolume = 1;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const eventName = this.readString(payload.event);
        const methodName = this.readString(payload.method);
        const data = payload.data;
        const value = payload.value;
        if (eventName === 'play')
            this.snapshot.paused = false;
        if (eventName === 'pause')
            this.snapshot.paused = true;
        if (eventName === 'timeupdate' && typeof data === 'object' && data) {
            const record = data;
            if (typeof record.seconds === 'number')
                this.snapshot.currentTime = record.seconds;
            if (typeof record.duration === 'number')
                this.snapshot.duration = record.duration;
        }
        if (methodName === 'getCurrentTime' && typeof value === 'number') {
            this.snapshot.currentTime = value;
        }
        if (methodName === 'getDuration' && typeof value === 'number') {
            this.snapshot.duration = value;
        }
        if (methodName === 'getVolume' && typeof value === 'number') {
            this.snapshot.volume = value;
            if (value > 0)
                this.lastNonZeroVolume = value;
        }
        if (methodName === 'getPaused' && typeof value === 'boolean') {
            this.snapshot.paused = value;
        }
    };
    constructor(id, iframe) {
        super(id, 'vimeo', VIMEO_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid Vimeo iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
    }
    async play() {
        this.postMethod('play');
    }
    async pause() {
        this.postMethod('pause');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postMethod('setCurrentTime', normalized);
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postMethod('setVolume', normalized);
        this.snapshot.volume = normalized;
        if (normalized > 0)
            this.lastNonZeroVolume = normalized;
    }
    async mute() {
        this.postMethod('setVolume', 0);
        this.snapshot.volume = 0;
    }
    async unmute() {
        const restore = this.lastNonZeroVolume > 0 ? this.lastNonZeroVolume : 1;
        this.postMethod('setVolume', restore);
        this.snapshot.volume = restore;
    }
    async getState() {
        this.postMethod('getCurrentTime');
        this.postMethod('getDuration');
        this.postMethod('getVolume');
        this.postMethod('getPaused');
        const volume = this.snapshot.volume ?? 1;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: this.snapshot.paused ?? true,
            volume: this.clampVolume(volume),
            muted: volume === 0,
            playbackRate: 1,
            title: this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    postMethod(method, value) {
        if (this.disposed)
            throw new Error('Player is disposed');
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow)
            throw new Error('Vimeo iframe window unavailable');
        const payload = value === undefined ? { method } : { method, value };
        targetWindow.postMessage(payload, this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'object')
            return data;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                return typeof parsed === 'object' && parsed ? parsed : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!VIMEO_ALLOWED_ORIGINS.has(url.origin))
                return null;
            return url.origin;
        }
        catch {
            return null;
        }
    }
    readString(value) {
        return typeof value === 'string' ? value : null;
    }
}


/***/ }),

/***/ "./src/content/media/iframe-players/youtube-player.ts":
/*!************************************************************!*\
  !*** ./src/content/media/iframe-players/youtube-player.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YouTubePlayer: () => (/* binding */ YouTubePlayer)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base-player */ "./src/content/media/base-player.ts");

const YOUTUBE_ALLOWED_ORIGINS = new Set([
    'https://www.youtube.com',
    'https://youtube.com',
    'https://m.youtube.com',
    'https://www.youtube-nocookie.com',
]);
const YOUTUBE_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: true,
    previousTrack: true,
    shuffle: true,
};
class YouTubePlayer extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    iframe;
    platform = 'youtube';
    capabilities = YOUTUBE_CAPABILITIES;
    anchorElement;
    targetOrigin;
    snapshot = {};
    disposed = false;
    messageListener = (event) => {
        if (this.disposed || event.source !== this.iframe.contentWindow)
            return;
        if (event.origin !== this.targetOrigin)
            return;
        const payload = this.parsePayload(event.data);
        if (!payload)
            return;
        const eventType = payload.event;
        if (eventType !== 'infoDelivery')
            return;
        const info = payload.info;
        if (!info || typeof info !== 'object')
            return;
        const record = info;
        this.updateSnapshot(record);
    };
    constructor(id, iframe) {
        super(id, 'youtube', YOUTUBE_CAPABILITIES);
        this.id = id;
        this.iframe = iframe;
        this.anchorElement = iframe;
        const origin = this.resolveTargetOrigin(iframe);
        if (!origin) {
            throw new Error('Invalid YouTube iframe origin');
        }
        this.targetOrigin = origin;
        window.addEventListener('message', this.messageListener);
        this.bootstrap();
    }
    async play() {
        this.postCommand('playVideo');
    }
    async pause() {
        this.postCommand('pauseVideo');
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.snapshot.duration ?? Number.NaN);
        this.postCommand('seekTo', [normalized, true]);
    }
    async setVolume(level) {
        const normalized = this.clampVolume(level);
        this.postCommand('setVolume', [Math.round(normalized * 100)]);
    }
    async mute() {
        this.postCommand('mute');
    }
    async unmute() {
        this.postCommand('unMute');
    }
    async nextTrack() {
        this.postCommand('nextVideo');
    }
    async previousTrack() {
        this.postCommand('previousVideo');
    }
    async shuffle() {
        this.postCommand('setShuffle', [true]);
    }
    async getState() {
        // Ask for fresh info; if API isn't enabled, we still return best-effort snapshot.
        this.postCommand('getCurrentTime');
        this.postCommand('getDuration');
        this.postCommand('getVolume');
        this.postCommand('isMuted');
        this.postCommand('getPlaybackRate');
        this.postCommand('getPlayerState');
        const rawVolume = this.snapshot.volume ?? 100;
        const normalizedVolume = rawVolume > 1 ? rawVolume / 100 : rawVolume;
        const playerState = this.snapshot.playerState;
        return {
            currentTime: this.snapshot.currentTime ?? 0,
            duration: this.snapshot.duration ?? 0,
            paused: playerState !== 1,
            volume: this.clampVolume(normalizedVolume),
            muted: this.snapshot.muted ?? false,
            playbackRate: this.snapshot.playbackRate ?? 1,
            title: this.readElementTitle(this.iframe),
            platform: this.platform,
            hasPlaylist: true,
        };
    }
    isAlive() {
        return !this.disposed && document.contains(this.iframe);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        window.removeEventListener('message', this.messageListener);
    }
    bootstrap() {
        this.postRaw({ event: 'listening', id: this.id, channel: 'widget' });
        this.postCommand('addEventListener', ['onStateChange']);
        this.postCommand('addEventListener', ['onPlaybackRateChange']);
    }
    postCommand(func, args = []) {
        this.postRaw({ event: 'command', func, args });
    }
    postRaw(payload) {
        if (this.disposed) {
            throw new Error('Player is disposed');
        }
        const targetWindow = this.iframe.contentWindow;
        if (!targetWindow) {
            throw new Error('YouTube iframe window unavailable');
        }
        targetWindow.postMessage(JSON.stringify(payload), this.targetOrigin);
    }
    parsePayload(data) {
        if (!data)
            return null;
        if (typeof data === 'string') {
            try {
                const parsed = JSON.parse(data);
                if (!parsed || typeof parsed !== 'object')
                    return null;
                return parsed;
            }
            catch {
                return null;
            }
        }
        if (typeof data === 'object') {
            return data;
        }
        return null;
    }
    updateSnapshot(info) {
        const currentTime = info.currentTime;
        if (typeof currentTime === 'number' && Number.isFinite(currentTime)) {
            this.snapshot.currentTime = currentTime;
        }
        const duration = info.duration;
        if (typeof duration === 'number' && Number.isFinite(duration)) {
            this.snapshot.duration = duration;
        }
        const volume = info.volume;
        if (typeof volume === 'number' && Number.isFinite(volume)) {
            this.snapshot.volume = volume;
        }
        const muted = info.muted;
        if (typeof muted === 'boolean') {
            this.snapshot.muted = muted;
        }
        else if (typeof muted === 'number') {
            this.snapshot.muted = muted === 1;
        }
        const playbackRate = info.playbackRate;
        if (typeof playbackRate === 'number' && Number.isFinite(playbackRate)) {
            this.snapshot.playbackRate = playbackRate;
        }
        const playerState = info.playerState;
        if (typeof playerState === 'number' && Number.isFinite(playerState)) {
            this.snapshot.playerState = playerState;
        }
    }
    resolveTargetOrigin(iframe) {
        const src = iframe.getAttribute('src');
        if (!src)
            return null;
        try {
            const url = new URL(src, location.href);
            if (!YOUTUBE_ALLOWED_ORIGINS.has(url.origin)) {
                return null;
            }
            return url.origin;
        }
        catch {
            return null;
        }
    }
}


/***/ }),

/***/ "./src/content/media/index.ts":
/*!************************************!*\
  !*** ./src/content/media/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BandcampPlayer: () => (/* reexport safe */ _audio_embeds_bandcamp_player__WEBPACK_IMPORTED_MODULE_15__.BandcampPlayer),
/* harmony export */   BasePlayer: () => (/* reexport safe */ _base_player__WEBPACK_IMPORTED_MODULE_1__.BasePlayer),
/* harmony export */   CORE_MEDIA_ACTIONS: () => (/* reexport safe */ _types__WEBPACK_IMPORTED_MODULE_0__.CORE_MEDIA_ACTIONS),
/* harmony export */   DailymotionPlayer: () => (/* reexport safe */ _iframe_players_dailymotion_player__WEBPACK_IMPORTED_MODULE_7__.DailymotionPlayer),
/* harmony export */   JWPlayerAdapter: () => (/* reexport safe */ _custom_players_jwplayer_player__WEBPACK_IMPORTED_MODULE_11__.JWPlayerAdapter),
/* harmony export */   MediaElementPlayer: () => (/* reexport safe */ _custom_players_mediaelement_player__WEBPACK_IMPORTED_MODULE_12__.MediaElementPlayer),
/* harmony export */   NativePlayerAdapter: () => (/* reexport safe */ _native_player__WEBPACK_IMPORTED_MODULE_2__.NativePlayerAdapter),
/* harmony export */   PLAYLIST_MEDIA_ACTIONS: () => (/* reexport safe */ _types__WEBPACK_IMPORTED_MODULE_0__.PLAYLIST_MEDIA_ACTIONS),
/* harmony export */   PlayerDetector: () => (/* reexport safe */ _player_detector__WEBPACK_IMPORTED_MODULE_3__.PlayerDetector),
/* harmony export */   PlayerRegistry: () => (/* reexport safe */ _player_registry__WEBPACK_IMPORTED_MODULE_4__.PlayerRegistry),
/* harmony export */   PlyrPlayer: () => (/* reexport safe */ _custom_players_plyr_player__WEBPACK_IMPORTED_MODULE_10__.PlyrPlayer),
/* harmony export */   SoundCloudPlayer: () => (/* reexport safe */ _audio_embeds_soundcloud_player__WEBPACK_IMPORTED_MODULE_14__.SoundCloudPlayer),
/* harmony export */   SpotifyPlayer: () => (/* reexport safe */ _audio_embeds_spotify_player__WEBPACK_IMPORTED_MODULE_13__.SpotifyPlayer),
/* harmony export */   TwitchPlayer: () => (/* reexport safe */ _iframe_players_twitch_player__WEBPACK_IMPORTED_MODULE_8__.TwitchPlayer),
/* harmony export */   VideoJsPlayer: () => (/* reexport safe */ _custom_players_videojs_player__WEBPACK_IMPORTED_MODULE_9__.VideoJsPlayer),
/* harmony export */   VimeoPlayer: () => (/* reexport safe */ _iframe_players_vimeo_player__WEBPACK_IMPORTED_MODULE_6__.VimeoPlayer),
/* harmony export */   YouTubePlayer: () => (/* reexport safe */ _iframe_players_youtube_player__WEBPACK_IMPORTED_MODULE_5__.YouTubePlayer),
/* harmony export */   getPlayerRegistry: () => (/* reexport safe */ _player_registry__WEBPACK_IMPORTED_MODULE_4__.getPlayerRegistry),
/* harmony export */   isPlaylistAction: () => (/* reexport safe */ _types__WEBPACK_IMPORTED_MODULE_0__.isPlaylistAction),
/* harmony export */   parseMediaToolName: () => (/* reexport safe */ _types__WEBPACK_IMPORTED_MODULE_0__.parseMediaToolName)
/* harmony export */ });
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./types */ "./src/content/media/types.ts");
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-player */ "./src/content/media/base-player.ts");
/* harmony import */ var _native_player__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./native-player */ "./src/content/media/native-player.ts");
/* harmony import */ var _player_detector__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./player-detector */ "./src/content/media/player-detector.ts");
/* harmony import */ var _player_registry__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./player-registry */ "./src/content/media/player-registry.ts");
/* harmony import */ var _iframe_players_youtube_player__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./iframe-players/youtube-player */ "./src/content/media/iframe-players/youtube-player.ts");
/* harmony import */ var _iframe_players_vimeo_player__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./iframe-players/vimeo-player */ "./src/content/media/iframe-players/vimeo-player.ts");
/* harmony import */ var _iframe_players_dailymotion_player__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./iframe-players/dailymotion-player */ "./src/content/media/iframe-players/dailymotion-player.ts");
/* harmony import */ var _iframe_players_twitch_player__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./iframe-players/twitch-player */ "./src/content/media/iframe-players/twitch-player.ts");
/* harmony import */ var _custom_players_videojs_player__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./custom-players/videojs-player */ "./src/content/media/custom-players/videojs-player.ts");
/* harmony import */ var _custom_players_plyr_player__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./custom-players/plyr-player */ "./src/content/media/custom-players/plyr-player.ts");
/* harmony import */ var _custom_players_jwplayer_player__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./custom-players/jwplayer-player */ "./src/content/media/custom-players/jwplayer-player.ts");
/* harmony import */ var _custom_players_mediaelement_player__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./custom-players/mediaelement-player */ "./src/content/media/custom-players/mediaelement-player.ts");
/* harmony import */ var _audio_embeds_spotify_player__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./audio-embeds/spotify-player */ "./src/content/media/audio-embeds/spotify-player.ts");
/* harmony import */ var _audio_embeds_soundcloud_player__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./audio-embeds/soundcloud-player */ "./src/content/media/audio-embeds/soundcloud-player.ts");
/* harmony import */ var _audio_embeds_bandcamp_player__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./audio-embeds/bandcamp-player */ "./src/content/media/audio-embeds/bandcamp-player.ts");


















/***/ }),

/***/ "./src/content/media/native-player.ts":
/*!********************************************!*\
  !*** ./src/content/media/native-player.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NativePlayerAdapter: () => (/* binding */ NativePlayerAdapter)
/* harmony export */ });
/* harmony import */ var _base_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-player */ "./src/content/media/base-player.ts");

const NATIVE_CAPABILITIES = {
    play: true,
    pause: true,
    seek: true,
    setVolume: true,
    mute: true,
    unmute: true,
    getState: true,
    nextTrack: false,
    previousTrack: false,
    shuffle: false,
};
class NativePlayerAdapter extends _base_player__WEBPACK_IMPORTED_MODULE_0__.BasePlayer {
    id;
    mediaElement;
    platform = 'native';
    capabilities = NATIVE_CAPABILITIES;
    constructor(id, mediaElement) {
        super(id, 'native', NATIVE_CAPABILITIES);
        this.id = id;
        this.mediaElement = mediaElement;
    }
    get anchorElement() {
        return this.mediaElement;
    }
    async play() {
        await this.mediaElement.play();
    }
    async pause() {
        this.mediaElement.pause();
    }
    async seek(time) {
        const normalized = this.clampSeek(time, this.mediaElement.duration);
        this.mediaElement.currentTime = normalized;
    }
    async setVolume(level) {
        this.mediaElement.volume = this.clampVolume(level);
    }
    async mute() {
        this.mediaElement.muted = true;
    }
    async unmute() {
        this.mediaElement.muted = false;
    }
    async getState() {
        return {
            currentTime: Number.isFinite(this.mediaElement.currentTime)
                ? this.mediaElement.currentTime
                : 0,
            duration: Number.isFinite(this.mediaElement.duration)
                ? this.mediaElement.duration
                : 0,
            paused: this.mediaElement.paused,
            volume: this.mediaElement.volume,
            muted: this.mediaElement.muted,
            playbackRate: this.mediaElement.playbackRate,
            title: this.readElementTitle(this.mediaElement),
            platform: this.platform,
            hasPlaylist: false,
        };
    }
    isAlive() {
        return document.contains(this.mediaElement);
    }
}


/***/ }),

/***/ "./src/content/media/player-detector.ts":
/*!**********************************************!*\
  !*** ./src/content/media/player-detector.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayerDetector: () => (/* binding */ PlayerDetector)
/* harmony export */ });
/* harmony import */ var _audio_embeds_bandcamp_player__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./audio-embeds/bandcamp-player */ "./src/content/media/audio-embeds/bandcamp-player.ts");
/* harmony import */ var _audio_embeds_soundcloud_player__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./audio-embeds/soundcloud-player */ "./src/content/media/audio-embeds/soundcloud-player.ts");
/* harmony import */ var _audio_embeds_spotify_player__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./audio-embeds/spotify-player */ "./src/content/media/audio-embeds/spotify-player.ts");
/* harmony import */ var _custom_players_jwplayer_player__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./custom-players/jwplayer-player */ "./src/content/media/custom-players/jwplayer-player.ts");
/* harmony import */ var _custom_players_mediaelement_player__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./custom-players/mediaelement-player */ "./src/content/media/custom-players/mediaelement-player.ts");
/* harmony import */ var _custom_players_plyr_player__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./custom-players/plyr-player */ "./src/content/media/custom-players/plyr-player.ts");
/* harmony import */ var _custom_players_videojs_player__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./custom-players/videojs-player */ "./src/content/media/custom-players/videojs-player.ts");
/* harmony import */ var _native_player__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./native-player */ "./src/content/media/native-player.ts");
/* harmony import */ var _iframe_players_dailymotion_player__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./iframe-players/dailymotion-player */ "./src/content/media/iframe-players/dailymotion-player.ts");
/* harmony import */ var _iframe_players_twitch_player__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./iframe-players/twitch-player */ "./src/content/media/iframe-players/twitch-player.ts");
/* harmony import */ var _iframe_players_vimeo_player__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./iframe-players/vimeo-player */ "./src/content/media/iframe-players/vimeo-player.ts");
/* harmony import */ var _iframe_players_youtube_player__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./iframe-players/youtube-player */ "./src/content/media/iframe-players/youtube-player.ts");












class PlayerDetector {
    detect(root) {
        const players = [];
        const claimed = new WeakSet();
        this.detectYouTube(root, claimed, players);
        this.detectVimeo(root, claimed, players);
        this.detectDailymotion(root, claimed, players);
        this.detectTwitch(root, claimed, players);
        this.detectCustomPlayers(root, claimed, players);
        this.detectAudioEmbeds(root, claimed, players);
        this.detectNative(root, claimed, players);
        return players;
    }
    detectAudioEmbeds(root, claimed, players) {
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'spotify',
            predicate: (src) => this.isSpotifyEmbed(src),
            create: (id, iframe) => new _audio_embeds_spotify_player__WEBPACK_IMPORTED_MODULE_2__.SpotifyPlayer(id, iframe),
        });
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'soundcloud',
            predicate: (src) => this.isSoundCloudEmbed(src),
            create: (id, iframe) => new _audio_embeds_soundcloud_player__WEBPACK_IMPORTED_MODULE_1__.SoundCloudPlayer(id, iframe),
        });
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'bandcamp',
            predicate: (src) => this.isBandcampEmbed(src),
            create: (id, iframe) => new _audio_embeds_bandcamp_player__WEBPACK_IMPORTED_MODULE_0__.BandcampPlayer(id, iframe),
        });
    }
    detectVimeo(root, claimed, players) {
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'vimeo',
            predicate: (src) => this.isVimeoEmbed(src),
            create: (id, iframe) => new _iframe_players_vimeo_player__WEBPACK_IMPORTED_MODULE_10__.VimeoPlayer(id, iframe),
        });
    }
    detectDailymotion(root, claimed, players) {
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'dailymotion',
            predicate: (src) => this.isDailymotionEmbed(src),
            create: (id, iframe) => new _iframe_players_dailymotion_player__WEBPACK_IMPORTED_MODULE_8__.DailymotionPlayer(id, iframe),
        });
    }
    detectTwitch(root, claimed, players) {
        this.detectIframeByPredicate(root, claimed, players, {
            prefix: 'twitch',
            predicate: (src) => this.isTwitchEmbed(src),
            create: (id, iframe) => new _iframe_players_twitch_player__WEBPACK_IMPORTED_MODULE_9__.TwitchPlayer(id, iframe),
        });
    }
    detectIframeByPredicate(root, claimed, players, options) {
        const iframes = this.queryAll(root, 'iframe[src]');
        let index = 0;
        for (const iframe of iframes) {
            if (claimed.has(iframe))
                continue;
            const src = iframe.getAttribute('src') ?? '';
            if (!options.predicate(src))
                continue;
            try {
                const id = this.makeId(options.prefix, iframe, index);
                players.push(options.create(id, iframe));
                claimed.add(iframe);
                index += 1;
            }
            catch {
                // Skip invalid/uncontrollable iframe players.
            }
        }
    }
    detectYouTube(root, claimed, players) {
        const iframes = this.queryAll(root, 'iframe[src]');
        let index = 0;
        for (const iframe of iframes) {
            if (claimed.has(iframe))
                continue;
            const src = iframe.getAttribute('src') ?? '';
            if (!this.isYouTubeEmbed(src))
                continue;
            try {
                const id = this.makeId('youtube', iframe, index);
                players.push(new _iframe_players_youtube_player__WEBPACK_IMPORTED_MODULE_11__.YouTubePlayer(id, iframe));
                claimed.add(iframe);
                index += 1;
            }
            catch {
                // Skip invalid/uncontrollable iframe players.
            }
        }
    }
    detectNative(root, claimed, players) {
        const mediaEls = this.queryAll(root, 'video, audio');
        let index = 0;
        for (const media of mediaEls) {
            if (claimed.has(media))
                continue;
            const id = this.makeId(media.tagName.toLowerCase(), media, index);
            players.push(new _native_player__WEBPACK_IMPORTED_MODULE_7__.NativePlayerAdapter(id, media));
            claimed.add(media);
            index += 1;
        }
    }
    detectCustomPlayers(root, claimed, players) {
        this.detectCustomBySelector(root, claimed, players, {
            selector: '.video-js',
            prefix: 'videojs',
            create: (id, media, host) => new _custom_players_videojs_player__WEBPACK_IMPORTED_MODULE_6__.VideoJsPlayer(id, media, host),
        });
        this.detectCustomBySelector(root, claimed, players, {
            selector: '.plyr',
            prefix: 'plyr',
            create: (id, media, host) => new _custom_players_plyr_player__WEBPACK_IMPORTED_MODULE_5__.PlyrPlayer(id, media, host),
        });
        this.detectCustomBySelector(root, claimed, players, {
            selector: '.jwplayer, [id^="jwplayer"], [class*="jwplayer"]',
            prefix: 'jwplayer',
            create: (id, media, host) => new _custom_players_jwplayer_player__WEBPACK_IMPORTED_MODULE_3__.JWPlayerAdapter(id, media, host),
        });
        this.detectCustomBySelector(root, claimed, players, {
            selector: '.mejs__container, .mejs-container',
            prefix: 'mediaelement',
            create: (id, media, host) => new _custom_players_mediaelement_player__WEBPACK_IMPORTED_MODULE_4__.MediaElementPlayer(id, media, host),
        });
    }
    detectCustomBySelector(root, claimed, players, options) {
        const hosts = this.queryAll(root, options.selector);
        let index = 0;
        for (const host of hosts) {
            if (claimed.has(host))
                continue;
            const media = host.querySelector('video, audio');
            if (!media || claimed.has(media))
                continue;
            const id = this.makeId(options.prefix, host, index);
            players.push(options.create(id, media, host));
            claimed.add(host);
            claimed.add(media);
            index += 1;
        }
    }
    queryAll(root, selector) {
        return Array.from(root.querySelectorAll(selector));
    }
    makeId(prefix, el, index) {
        const seed = el.id ||
            el.getAttribute('name') ||
            el.getAttribute('aria-label') ||
            el.getAttribute('title') ||
            el.getAttribute('src') ||
            `${prefix}-${index}`;
        return `${prefix}-${this.slugify(seed)}-${index}`;
    }
    slugify(text) {
        return (text || '')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '')
            .slice(0, 64);
    }
    isYouTubeEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            const host = url.hostname.toLowerCase();
            return (host === 'youtube.com' ||
                host === 'www.youtube.com' ||
                host === 'm.youtube.com' ||
                host === 'www.youtube-nocookie.com' ||
                host === 'youtu.be');
        }
        catch {
            return false;
        }
    }
    isVimeoEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            const host = url.hostname.toLowerCase();
            return host === 'player.vimeo.com' || host === 'vimeo.com' || host === 'www.vimeo.com';
        }
        catch {
            return false;
        }
    }
    isDailymotionEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            const host = url.hostname.toLowerCase();
            return host === 'www.dailymotion.com' || host === 'dailymotion.com';
        }
        catch {
            return false;
        }
    }
    isTwitchEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            const host = url.hostname.toLowerCase();
            return host === 'player.twitch.tv' || host === 'www.twitch.tv' || host === 'twitch.tv';
        }
        catch {
            return false;
        }
    }
    isSpotifyEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            return url.hostname === 'open.spotify.com' && url.pathname.includes('/embed');
        }
        catch {
            return false;
        }
    }
    isSoundCloudEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            return url.hostname === 'w.soundcloud.com' && url.pathname.includes('/player');
        }
        catch {
            return false;
        }
    }
    isBandcampEmbed(src) {
        if (!src)
            return false;
        try {
            const url = new URL(src, location.href);
            const host = url.hostname.toLowerCase();
            return (host === 'bandcamp.com' || host === 'www.bandcamp.com')
                && url.pathname.toLowerCase().includes('embeddedplayer');
        }
        catch {
            return false;
        }
    }
}


/***/ }),

/***/ "./src/content/media/player-registry.ts":
/*!**********************************************!*\
  !*** ./src/content/media/player-registry.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayerRegistry: () => (/* binding */ PlayerRegistry),
/* harmony export */   getPlayerRegistry: () => (/* binding */ getPlayerRegistry)
/* harmony export */ });
/* harmony import */ var _player_detector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./player-detector */ "./src/content/media/player-detector.ts");

class PlayerRegistry {
    detector = new _player_detector__WEBPACK_IMPORTED_MODULE_0__.PlayerDetector();
    playersById = new Map();
    refresh(root = document) {
        const detectedPlayers = this.detector.detect(root);
        const nextPlayers = new Map();
        for (const detected of detectedPlayers) {
            const existing = this.playersById.get(detected.id);
            if (existing && existing.isAlive()) {
                detected.dispose();
                nextPlayers.set(existing.id, existing);
            }
            else {
                if (existing)
                    existing.dispose();
                nextPlayers.set(detected.id, detected);
            }
        }
        for (const [id, previous] of this.playersById.entries()) {
            if (!nextPlayers.has(id)) {
                previous.dispose();
            }
        }
        this.playersById = nextPlayers;
        return this.getAll();
    }
    getById(id) {
        const player = this.playersById.get(id) ?? null;
        if (!player)
            return null;
        if (!player.isAlive()) {
            player.dispose();
            this.playersById.delete(id);
            return null;
        }
        return player;
    }
    getAll() {
        const alive = [];
        for (const [id, player] of this.playersById.entries()) {
            if (player.isAlive()) {
                alive.push(player);
            }
            else {
                player.dispose();
                this.playersById.delete(id);
            }
        }
        return alive;
    }
    dispose() {
        for (const player of this.playersById.values()) {
            player.dispose();
        }
        this.playersById.clear();
    }
}
let singleton = null;
function getPlayerRegistry() {
    singleton ??= new PlayerRegistry();
    return singleton;
}


/***/ }),

/***/ "./src/content/media/types.ts":
/*!************************************!*\
  !*** ./src/content/media/types.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CORE_MEDIA_ACTIONS: () => (/* binding */ CORE_MEDIA_ACTIONS),
/* harmony export */   PLAYLIST_MEDIA_ACTIONS: () => (/* binding */ PLAYLIST_MEDIA_ACTIONS),
/* harmony export */   isPlaylistAction: () => (/* binding */ isPlaylistAction),
/* harmony export */   parseMediaToolName: () => (/* binding */ parseMediaToolName)
/* harmony export */ });
const CORE_MEDIA_ACTIONS = [
    'play',
    'pause',
    'seek',
    'set-volume',
    'mute',
    'unmute',
    'get-state',
    'get-transcript',
];
const PLAYLIST_MEDIA_ACTIONS = [
    'next-track',
    'previous-track',
    'shuffle',
];
const ACTION_SET = new Set([
    ...CORE_MEDIA_ACTIONS,
    ...PLAYLIST_MEDIA_ACTIONS,
]);
function parseMediaToolName(name) {
    const match = /^media\.([a-z-]+)\.(.+)$/i.exec(name);
    if (!match)
        return null;
    const actionCandidate = match[1];
    if (!ACTION_SET.has(actionCandidate))
        return null;
    const playerId = match[2]?.trim();
    if (!playerId)
        return null;
    return {
        action: actionCandidate,
        playerId,
    };
}
function isPlaylistAction(action) {
    return PLAYLIST_MEDIA_ACTIONS.includes(action);
}


/***/ }),

/***/ "./src/content/merge.ts":
/*!******************************!*\
  !*** ./src/content/merge.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getSecurityTier: () => (/* binding */ getSecurityTier),
/* harmony export */   mergeToolSets: () => (/* binding */ mergeToolSets)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/**
 * Merge utilities: union-merge 3 tool tiers with priority,
 * plus security tier classification.
 */

/**
 * Union-merge tool sets from all 3 discovery tiers.
 * Priority: native > declarative > inferred (by name collision).
 */
function mergeToolSets(nativeTools, declarativeTools, inferredTools) {
    const byName = new Map();
    for (const tool of nativeTools) {
        byName.set(tool.name, { ...tool, _source: 'native' });
    }
    for (const tool of declarativeTools) {
        if (!byName.has(tool.name)) {
            byName.set(tool.name, { ...tool, _source: 'declarative' });
        }
    }
    for (const tool of inferredTools) {
        if (!byName.has(tool.name)) {
            byName.set(tool.name, { ...tool, _source: 'inferred' });
        }
    }
    return [...byName.values()];
}
/**
 * Compute the security tier for a tool based on category and name.
 *
 * Tier 0 (Safe): page-state, media (read ops)
 * Tier 1 (Navigation): navigation, search, schema-org search
 * Tier 2 (Mutation): form, auth, ecommerce, richtext, file-upload, social-action
 */
function getSecurityTier(tool) {
    const cat = tool.category;
    const name = tool.name;
    // Safe
    if (cat === 'page-state')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.SAFE;
    if (cat === 'media') {
        if (/^media\.(next-track|previous-track|shuffle)\./i.test(name)) {
            return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.NAVIGATION;
        }
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.SAFE;
    }
    // Navigation
    if (cat === 'navigation')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.NAVIGATION;
    if (cat === 'schema-org' && name.includes('search'))
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.NAVIGATION;
    // Mutations
    if (cat === 'form')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'auth')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'ecommerce')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'richtext')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'file-upload')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'social-action')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'interactive' && name.includes('.toggle-'))
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.MUTATION;
    if (cat === 'search')
        return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.NAVIGATION;
    // Default: navigation-level (cautious but not blocking)
    return _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SecurityTierLevel.NAVIGATION;
}


/***/ }),

/***/ "./src/content/message-handler.ts":
/*!****************************************!*\
  !*** ./src/content/message-handler.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createMessageHandler: () => (/* binding */ createMessageHandler)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./merge */ "./src/content/merge.ts");
/* harmony import */ var _page_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./page-context */ "./src/content/page-context.ts");
/* harmony import */ var _adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../adapters/indexeddb-tool-cache-adapter */ "./src/adapters/indexeddb-tool-cache-adapter.ts");
/**
 * Message handler — chrome.runtime.onMessage dispatcher for the
 * content script. Owns YOLO-mode cache and pending confirmations.
 */




function createMessageHandler(registry) {
    // ── YOLO mode (cached, updated on storage change) ──
    let yoloMode = true; // Default: YOLO on
    chrome.storage.local.get([_utils_constants__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEY_YOLO_MODE]).then((r) => {
        yoloMode = r[_utils_constants__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEY_YOLO_MODE] !== false;
    });
    chrome.storage.onChanged.addListener((changes) => {
        if (_utils_constants__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEY_YOLO_MODE in changes) {
            yoloMode = changes[_utils_constants__WEBPACK_IMPORTED_MODULE_0__.STORAGE_KEY_YOLO_MODE].newValue !== false;
        }
    });
    // Pending confirmation queue: executionId → { resolve, reject, tool, args, timeout }
    const pendingConfirmations = new Map();
    // ── Individual action handlers ──
    function handlePing(reply) {
        reply({ status: 'pong' });
        return false;
    }
    function handleSetLockMode(msg, reply) {
        const locked = msg.inputArgs?.locked ?? true;
        if (locked) {
            registry.stopDomObserver();
            console.debug('[WebMCP] DOM observer STOPPED (locked)');
        }
        else {
            registry.startDomObserver();
            console.debug('[WebMCP] DOM observer STARTED (live mode)');
        }
        reply({ locked });
        return false;
    }
    function handleGetPageContext(reply) {
        reply((0,_page_context__WEBPACK_IMPORTED_MODULE_2__.extractPageContext)());
        return false;
    }
    function handleGetToolsSync(reply) {
        registry.listToolsAlwaysAugment().then((tools) => {
            reply({ tools, url: location.href });
        }).catch(() => {
            reply({ tools: [], url: location.href });
        });
        return true; // async response
    }
    function handleListTools(reply) {
        registry.listToolsAlwaysAugment();
        if (navigator.modelContextTesting?.registerToolsChangedCallback) {
            navigator.modelContextTesting.registerToolsChangedCallback(() => { registry.listToolsAlwaysAugment(); });
        }
        reply({ queued: true });
        return false;
    }
    function handleExecuteTool(msg, reply) {
        const execMsg = msg;
        const toolName = execMsg.name;
        const inputArgs = execMsg.inputArgs;
        // Check inferred tools first
        const inferredTool = registry.inferredToolsMap.get(toolName);
        if (inferredTool) {
            console.debug(`[WebMCP] Execute INFERRED tool "${toolName}" with`, inputArgs);
            let parsedArgs;
            try {
                parsedArgs = typeof inputArgs === 'string'
                    ? JSON.parse(inputArgs)
                    : inputArgs;
            }
            catch {
                reply({ error: 'Invalid JSON arguments' });
                return true;
            }
            const tier = (0,_merge__WEBPACK_IMPORTED_MODULE_1__.getSecurityTier)(inferredTool);
            const tierInfo = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SECURITY_TIERS[tier];
            if (!tierInfo.autoExecute && !yoloMode) {
                const execId = `${toolName}_${Date.now()}`;
                const promise = new Promise((resolve, reject) => {
                    const timeout = setTimeout(() => {
                        pendingConfirmations.delete(execId);
                        reject(new Error('Confirmation timed out'));
                    }, 60_000);
                    pendingConfirmations.set(execId, {
                        resolve,
                        reject,
                        tool: inferredTool,
                        args: parsedArgs,
                        timeout,
                    });
                });
                chrome.runtime.sendMessage({
                    action: 'CONFIRM_EXECUTION',
                    toolName: execId,
                    description: inferredTool.description,
                    tier,
                });
                promise
                    .then((result) => reply(result))
                    .catch((err) => reply(JSON.stringify(err.message)));
                return true;
            }
            registry.executorRegistry
                .execute(inferredTool, parsedArgs)
                .then((result) => reply(result))
                .catch((err) => {
                console.error('[WebMCP] Inferred execution error:', err);
                reply(JSON.stringify(err.message || String(err)));
            });
            return true;
        }
        // Native/declarative tool execution
        if (!navigator.modelContextTesting) {
            reply(JSON.stringify('WebMCP native API not available for native tool execution'));
            return false;
        }
        // Validate tool exists in native API before executing
        try {
            const nativeTools = navigator.modelContextTesting.listTools() || [];
            const exists = nativeTools.some((t) => t.name === toolName);
            if (!exists) {
                reply(JSON.stringify(`Tool "${toolName}" not found`));
                return false;
            }
        }
        catch { /* proceed anyway if listTools fails */ }
        const normalizedArgs = registry.normalizeToolArgs(toolName, inputArgs);
        console.debug(`[WebMCP] Execute NATIVE tool "${toolName}" with`, normalizedArgs);
        let targetFrame = null;
        let loadPromise;
        const formTarget = document.querySelector(`form[toolname="${CSS.escape(toolName)}"]`)?.getAttribute('target');
        if (formTarget) {
            targetFrame = document.querySelector(`[name="${CSS.escape(formTarget)}"]`);
            if (targetFrame) {
                loadPromise = new Promise((resolve) => {
                    targetFrame.addEventListener('load', () => resolve(), {
                        once: true,
                    });
                });
            }
        }
        navigator.modelContextTesting
            .executeTool(toolName, normalizedArgs)
            .then(async (result) => {
            let finalResult = result;
            if (finalResult === null &&
                targetFrame &&
                loadPromise) {
                console.debug(`[WebMCP] Waiting for form target to load`);
                await loadPromise;
                finalResult =
                    await targetFrame.contentWindow
                        ?.navigator?.modelContextTesting
                        ?.getCrossDocumentScriptToolResult();
            }
            reply(finalResult);
        })
            .catch((err) => {
            console.error('[WebMCP] Execution error:', err);
            reply(JSON.stringify(err.message || String(err)));
        });
        return true;
    }
    function handleGetCrossDocumentResult(reply) {
        if (!navigator.modelContextTesting) {
            reply(JSON.stringify('WebMCP native API not available'));
            return false;
        }
        console.debug('[WebMCP] Get cross document script tool result');
        navigator.modelContextTesting
            .getCrossDocumentScriptToolResult()
            .then(reply)
            .catch((err) => reply(JSON.stringify(err.message)));
        return true;
    }
    function handleConfirmExecute(msg, reply) {
        const pending = pendingConfirmations.get(msg.toolName);
        if (pending) {
            clearTimeout(pending.timeout);
            pendingConfirmations.delete(msg.toolName);
            registry.executorRegistry
                .execute(pending.tool, pending.args)
                .then((result) => pending.resolve(result))
                .catch((err) => pending.reject(err));
        }
        reply({ confirmed: true });
        return false;
    }
    function handleCancelExecute(msg, reply) {
        const cancelled = pendingConfirmations.get(msg.toolName);
        if (cancelled) {
            clearTimeout(cancelled.timeout);
            pendingConfirmations.delete(msg.toolName);
            cancelled.reject(new Error('Execution cancelled by user'));
        }
        reply({ cancelled: true });
        return false;
    }
    function handleGetSiteManifest(reply) {
        const manifest = registry.getToolManifest();
        if (!manifest) {
            reply({ error: 'Tool manifest not available' });
            return false;
        }
        const site = (0,_adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_3__.extractSite)(location.href);
        reply({ manifest: manifest.toMCPJson(site) });
        return false;
    }
    // ── Register the message listener ──
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
        try {
            switch (msg.action) {
                case 'PING':
                    return handlePing(reply);
                case 'SET_LOCK_MODE':
                    return handleSetLockMode(msg, reply);
                case 'GET_PAGE_CONTEXT':
                    return handleGetPageContext(reply);
                case 'LIST_TOOLS':
                    return handleListTools(reply);
                case 'GET_TOOLS_SYNC':
                    return handleGetToolsSync(reply);
                case 'EXECUTE_TOOL':
                    return handleExecuteTool(msg, reply);
                case 'GET_CROSS_DOCUMENT_SCRIPT_TOOL_RESULT':
                    return handleGetCrossDocumentResult(reply);
                case 'CONFIRM_EXECUTE':
                    return handleConfirmExecute(msg, reply);
                case 'CANCEL_EXECUTE':
                    return handleCancelExecute(msg, reply);
                case 'CAPTURE_SCREENSHOT':
                    return false;
                case 'GET_SITE_MANIFEST':
                    return handleGetSiteManifest(reply);
                default:
                    return false;
            }
        }
        catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            chrome.runtime.sendMessage({ message });
            return false;
        }
    });
}


/***/ }),

/***/ "./src/content/page-context.ts":
/*!*************************************!*\
  !*** ./src/content/page-context.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extractPageContext: () => (/* binding */ extractPageContext)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _utils_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/dom */ "./src/utils/dom.ts");
/* harmony import */ var _live_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./live-state */ "./src/content/live-state/index.ts");
/**
 * Page context extraction — collects structured information about the
 * current page for the sidebar / AI layer.
 */



function extractPageContext() {
    let products;
    let cartCount;
    let formDefaults;
    let formFields;
    let mainHeading;
    let pageText;
    let headings;
    let links;
    let metaDescription;
    // Products via Schema.org microdata or data-mcp-type
    const productEls = document.querySelectorAll('[data-mcp-type="product"], [itemtype*="schema.org/Product"]');
    if (productEls.length) {
        products = [...productEls]
            .slice(0, _utils_constants__WEBPACK_IMPORTED_MODULE_0__.MAX_PAGE_CONTEXT_PRODUCTS)
            .map((el) => {
            const name = el
                .querySelector('[itemprop="name"], .product-name')
                ?.textContent?.trim();
            const price = el
                .querySelector('[itemprop="price"], .product-price')
                ?.textContent?.trim();
            const id = el.dataset?.productId ||
                el.id ||
                null;
            return { id, name, price };
        });
    }
    // Cart state
    const cartBadge = document.querySelector('#cart-count, [data-cart-count], .cart-count, .cart-badge');
    if (cartBadge) {
        cartCount = parseInt(cartBadge.textContent ?? '0', 10) || 0;
    }
    // Current form values for each tool form
    const forms = document.querySelectorAll('form[toolname]');
    if (forms.length) {
        formDefaults = {};
        forms.forEach((f) => {
            const toolName = f.getAttribute('toolname');
            if (toolName) {
                formDefaults[toolName] = (0,_utils_dom__WEBPACK_IMPORTED_MODULE_1__.getFormValues)(f);
            }
        });
    }
    // All visible forms with their fields (capped for token budget)
    const MAX_FORMS = 10;
    const MAX_FIELDS_PER_FORM = 30;
    const MAX_VALUE_LEN = 200;
    const formElements = document.querySelectorAll('form');
    if (formElements.length) {
        formFields = {};
        let formCount = 0;
        formElements.forEach((f, i) => {
            if (formCount >= MAX_FORMS)
                return;
            const htmlForm = f;
            const formId = htmlForm.id || htmlForm.getAttribute('toolname') || `form-${i}`;
            const inputs = htmlForm.querySelectorAll('input, select, textarea');
            const fields = {};
            let fieldCount = 0;
            inputs.forEach(inp => {
                if (fieldCount >= MAX_FIELDS_PER_FORM)
                    return;
                const el = inp;
                if (el.type === 'hidden')
                    return;
                const name = el.name || el.id || '';
                if (!name)
                    return;
                const raw = el.type === 'password' ? (el.value ? '••••' : '') : el.value;
                fields[name] = raw.length > MAX_VALUE_LEN ? raw.slice(0, MAX_VALUE_LEN) + '…' : raw;
                fieldCount++;
            });
            if (Object.keys(fields).length > 0) {
                formFields[formId] = fields;
                formCount++;
            }
        });
    }
    // Key heading
    const h1 = document.querySelector('h1');
    if (h1)
        mainHeading = h1.textContent?.trim();
    // Full visible page text via TreeWalker (avoids layout-triggering innerText)
    try {
        const MAX_TEXT_NODES = 5000;
        const MAX_TEXT_LEN = 8000;
        const chunks = [];
        let totalLen = 0;
        let nodeCount = 0;
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const parent = node.parentElement;
                if (!parent)
                    return NodeFilter.FILTER_REJECT;
                const tag = parent.tagName;
                if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT')
                    return NodeFilter.FILTER_REJECT;
                // Skip hidden elements (offsetParent is null for display:none, except for body/fixed)
                if (!parent.offsetParent && parent !== document.body && getComputedStyle(parent).position !== 'fixed')
                    return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            },
        });
        let textNode;
        while ((textNode = walker.nextNode())) {
            if (nodeCount++ >= MAX_TEXT_NODES)
                break;
            const t = textNode.textContent?.trim();
            if (!t)
                continue;
            chunks.push(t);
            totalLen += t.length;
            if (totalLen >= MAX_TEXT_LEN)
                break;
        }
        const rawText = chunks.join(' ');
        if (rawText) {
            pageText = rawText.length <= MAX_TEXT_LEN
                ? rawText
                : rawText.slice(0, MAX_TEXT_LEN) + ' […truncated]';
        }
    }
    catch { /* ignore */ }
    // All h1-h3 headings
    const headingEls = document.querySelectorAll('h1, h2, h3');
    if (headingEls.length) {
        headings = [...headingEls]
            .map((el) => el.textContent?.trim() ?? '')
            .filter(Boolean);
    }
    // Meta description
    const metaEl = document.querySelector('meta[name="description"]');
    if (metaEl?.content) {
        metaDescription = metaEl.content;
    }
    // Top 30 links from nav/main areas
    const linkEls = document.querySelectorAll('nav a[href], main a[href], header a[href], [role="navigation"] a[href]');
    const allLinks = linkEls.length > 0 ? linkEls : document.querySelectorAll('a[href]');
    if (allLinks.length) {
        const seen = new Set();
        links = [];
        for (const a of allLinks) {
            if (links.length >= 30)
                break;
            const anchor = a;
            const text = anchor.textContent?.trim();
            const href = anchor.href;
            if (text && href && !seen.has(href)) {
                seen.add(href);
                links.push({ text, href });
            }
        }
    }
    const liveState = (0,_live_state__WEBPACK_IMPORTED_MODULE_2__.getLiveStateManager)().getLatestSnapshot() ?? undefined;
    const ctx = {
        url: location.href,
        title: document.title,
        ...(products ? { products } : {}),
        ...(cartCount !== undefined ? { cartCount } : {}),
        ...(formDefaults ? { formDefaults } : {}),
        ...(formFields && Object.keys(formFields).length ? { formFields } : {}),
        ...(mainHeading ? { mainHeading } : {}),
        ...(pageText ? { pageText } : {}),
        ...(headings?.length ? { headings } : {}),
        ...(links?.length ? { links } : {}),
        ...(metaDescription ? { metaDescription } : {}),
        ...(liveState ? { liveState } : {}),
    };
    console.debug('[WebMCP] Page context extracted:', ctx);
    return ctx;
}


/***/ }),

/***/ "./src/content/scanners/auth-scanner.ts":
/*!**********************************************!*\
  !*** ./src/content/scanners/auth-scanner.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthScanner: () => (/* binding */ AuthScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Auth Scanner — discovers login forms (password inputs) and logout links/buttons.
 */

class AuthScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'auth';
    scan(root) {
        const tools = [];
        // ── Login forms (detect via password input) ──
        const passwordInputs = root.querySelectorAll('input[type="password"]');
        for (const pwd of passwordInputs) {
            const form = pwd.closest('form');
            if (!form || form.getAttribute('toolname'))
                continue;
            const emailInput = form.querySelector('input[type="email"], input[name*="email" i], input[name*="user" i], input[name*="login" i]');
            const fields = [];
            if (emailInput) {
                fields.push({
                    name: emailInput.name || 'email',
                    type: 'string',
                    description: 'Email or username',
                    required: true,
                });
            }
            fields.push({
                name: pwd.name || 'password',
                type: 'string',
                description: 'Password',
                required: true,
            });
            tools.push(this.createTool('auth.login', 'Sign in / Log in', form, this.makeInputSchema(fields), 0.95, {
                title: 'Sign In',
                annotations: this.makeAnnotations({ destructive: true, idempotent: false }),
            }));
        }
        // ── Logout links/buttons ──
        const logoutEls = root.querySelectorAll('a[href*="logout" i], a[href*="sign-out" i], a[href*="signout" i], ' +
            'button[class*="logout" i], [data-action="logout"]');
        for (const el of logoutEls) {
            tools.push(this.createTool('auth.logout', 'Sign out / Log out', el, this.makeInputSchema([]), 0.9, {
                title: 'Sign Out',
                annotations: this.makeAnnotations({ destructive: true, idempotent: true }),
            }));
            break; // Only one logout tool per page
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/base-scanner.ts":
/*!**********************************************!*\
  !*** ./src/content/scanners/base-scanner.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseScanner: () => (/* binding */ BaseScanner),
/* harmony export */   claimElement: () => (/* binding */ claimElement),
/* harmony export */   collectShadowRoots: () => (/* binding */ collectShadowRoots),
/* harmony export */   isElementClaimed: () => (/* binding */ isElementClaimed),
/* harmony export */   isSocialKeyword: () => (/* binding */ isSocialKeyword)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/constants */ "./src/utils/constants.ts");
/**
 * Abstract base class for all DOM scanners.
 * Provides shared helpers: confidence scoring, MCP-compliant naming,
 * visibility checks, label extraction, and element deduplication.
 */

// ── Global element dedup across all scanners ──
/** Elements already claimed by a scanner — first scanner wins */
const _claimedElements = new WeakSet();
/** Claim an element so no other scanner can emit it */
function claimElement(el) {
    _claimedElements.add(el);
}
/** Check whether an element has already been claimed */
function isElementClaimed(el) {
    return _claimedElements.has(el);
}
// ── Social keyword regex (shared by interactive & social scanners) ──
const SOCIAL_KEYWORDS_RE = /\b(like|mi piace|consiglia|upvote|heart|share|condividi|diffondi|repost|retweet|follow|segui|subscribe|iscriviti|comment|commenta|reply|rispondi)\b/i;
/** Test if a label indicates a social action (like, share, follow, comment) */
function isSocialKeyword(label) {
    return SOCIAL_KEYWORDS_RE.test(label);
}
// ── Shadow DOM traversal ──
/** Recursively collect open Shadow DOM roots from a root element */
function collectShadowRoots(root, maxDepth = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SHADOW_DOM_MAX_DEPTH) {
    const roots = [];
    if (maxDepth <= 0)
        return roots;
    const walk = (node, depth) => {
        if (depth > maxDepth)
            return;
        if ('shadowRoot' in node && node.shadowRoot) {
            const sr = node.shadowRoot;
            roots.push(sr);
            walk(sr, depth + 1);
        }
        const children = 'children' in node ? node.children : node.querySelectorAll('*');
        for (const child of Array.from(children)) {
            if (child.shadowRoot) {
                roots.push(child.shadowRoot);
                walk(child.shadowRoot, depth + 1);
            }
        }
    };
    walk(root, 0);
    return roots;
}
// ── Abstract Base Scanner ──
class BaseScanner {
    /** Per-category cap */
    maxTools = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.MAX_TOOLS_PER_CATEGORY;
    // ── Shared helpers ──
    /** Compute a confidence score from discrete signals */
    computeConfidence(signals) {
        let score = 0.4; // baseline
        if (signals.hasAria)
            score += 0.15;
        if (signals.hasLabel)
            score += 0.15;
        if (signals.hasName)
            score += 0.1;
        if (signals.hasRole)
            score += 0.1;
        if (signals.hasSemanticTag)
            score += 0.1;
        if (signals.isVisible === false)
            score -= 0.2;
        return Math.min(1, Math.max(0, score));
    }
    /** Build a Tool object with MCP-compliant naming */
    createTool(name, description, el, schema, confidence, opts = {}) {
        return {
            name,
            title: opts.title ?? description,
            description,
            category: this.category,
            inputSchema: schema,
            annotations: opts.annotations ?? this.makeAnnotations(),
            confidence,
            _source: 'inferred',
            _el: el,
            ...(opts.form !== undefined ? { _form: opts.form } : {}),
            ...(opts.schemaAction !== undefined ? { _schemaAction: opts.schemaAction } : {}),
        };
    }
    /** Slugify text for MCP-compliant tool name segments */
    slugify(text) {
        return (text || '')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '')
            .slice(0, 64);
    }
    /** Check if an element is visible in the viewport */
    isVisible(el) {
        const htmlEl = el;
        if (!htmlEl.offsetParent && htmlEl.style?.display !== 'fixed')
            return false;
        const style = getComputedStyle(el);
        return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
    }
    /** Check if an element has meaningful size (skips tiny/hidden utility buttons) */
    hasMeaningfulSize(el, minW = 24, minH = 24) {
        const rect = el.getBoundingClientRect?.();
        if (!rect)
            return true; // can't measure, assume ok
        return rect.width >= minW && rect.height >= minH;
    }
    /** Extract a human-readable label from an element */
    getLabel(el) {
        // 1. aria-label
        if (el.getAttribute('aria-label'))
            return el.getAttribute('aria-label').trim();
        // 2. aria-labelledby
        const labelledBy = el.getAttribute('aria-labelledby');
        if (labelledBy) {
            const ref = document.getElementById(labelledBy);
            if (ref)
                return ref.textContent?.trim() ?? '';
        }
        // 3. <label> with for= matching id
        if (el.id) {
            const lbl = document.querySelector(`label[for="${el.id}"]`);
            if (lbl)
                return lbl.textContent?.trim() ?? '';
        }
        // 4. title attribute
        const htmlEl = el;
        if (htmlEl.title)
            return htmlEl.title.trim();
        // 5. placeholder
        if (el.placeholder)
            return el.placeholder.trim();
        // 6. data-placeholder (used by many rich text editors)
        if (htmlEl.dataset?.placeholder)
            return htmlEl.dataset.placeholder.trim();
        // 7. innerText (capped, single line only — avoids garbage from nested elements)
        const txt = el.textContent?.trim();
        if (txt && txt.length < 60 && !txt.includes('\n'))
            return txt;
        return '';
    }
    /** Build an MCP-compliant inputSchema from a list of parameters */
    makeInputSchema(fields) {
        const props = {};
        const required = [];
        for (const f of fields) {
            const prop = {
                type: f.type || 'string',
                ...(f.description ? { description: f.description } : {}),
                ...(f.enum ? { enum: f.enum } : {}),
                ...(f.default !== undefined ? { default: f.default } : {}),
            };
            props[f.name] = prop;
            if (f.required)
                required.push(f.name);
        }
        return {
            type: 'object',
            properties: props,
            ...(required.length ? { required } : {}),
        };
    }
    /** Build MCP-compliant annotations */
    makeAnnotations(hints = {}) {
        return {
            readOnlyHint: hints.readOnly ?? false,
            destructiveHint: hints.destructive ?? false,
            idempotentHint: hints.idempotent ?? false,
            openWorldHint: hints.openWorld ?? true,
        };
    }
    /** Claim an element for cross-scanner dedup */
    claim(el) {
        claimElement(el);
    }
    /** Check if an element has already been claimed */
    isClaimed(el) {
        return isElementClaimed(el);
    }
}


/***/ }),

/***/ "./src/content/scanners/chatbot-scanner.ts":
/*!*************************************************!*\
  !*** ./src/content/scanners/chatbot-scanner.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatbotScanner: () => (/* binding */ ChatbotScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Chatbot Scanner — discovers AI chatbot input fields (ChatGPT, Claude, Gemini, Grok, etc.)
 * and their associated send buttons.
 */

/** Selectors for AI chatbot input fields, ordered from specific to generic */
const CHATBOT_INPUT_SELECTORS = [
    // ChatGPT
    '#prompt-textarea',
    'textarea[data-id="root"]',
    'div[contenteditable="true"][id*="prompt"]',
    // Claude
    'div[contenteditable="true"].ProseMirror',
    'div.ProseMirror[contenteditable]',
    // Gemini
    'div[contenteditable="true"][aria-label*="prompt" i]',
    'rich-textarea',
    // Grok / X.com — textarea inside complex React wrapper
    'textarea[autocapitalize="sentences"]',
    'textarea[placeholder*="Ask" i]',
    'textarea[placeholder*="Chiedi" i]',
    'textarea[placeholder*="Frag" i]',
    'textarea[placeholder*="Demande" i]',
    'textarea[placeholder*="Pregunta" i]',
    'textarea[placeholder*="anything" i]',
    'textarea[placeholder*="qualsiasi" i]',
    'div[contenteditable="true"][role="textbox"]',
    // Generic patterns
    'textarea[aria-label*="message" i]',
    'textarea[placeholder*="message" i]',
    'textarea[placeholder*="messag" i]',
].join(', ');
/** Selectors for send buttons — order: specific → generic */
const SEND_BUTTON_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[aria-label*="send" i]',
    'button[aria-label*="invia" i]',
    'button[aria-label*="envoyer" i]',
    'button[aria-label*="enviar" i]',
    'button[aria-label*="senden" i]',
    // Grok-specific: button with arrow SVG near the textarea (any language)
    'button[aria-label*="Grok" i]',
    'button[aria-label*="grok" i]',
];
class ChatbotScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'chatbot';
    scan(root) {
        const tools = [];
        let inputs = Array.from(root.querySelectorAll(CHATBOT_INPUT_SELECTORS));
        const seen = new Set();
        // Heuristic fallback: if no inputs matched, look for a lone visible textarea
        // with no name attribute (common in React chatbot UIs like Grok)
        if (inputs.length === 0) {
            const allTextareas = root.querySelectorAll('textarea');
            const visibleTextareas = Array.from(allTextareas).filter((ta) => !ta.getAttribute('name') && this.isVisible(ta));
            if (visibleTextareas.length === 1) {
                inputs = visibleTextareas;
            }
        }
        for (const inp of Array.from(inputs)) {
            if (seen.has(inp) || this.isClaimed(inp) || !this.isVisible(inp))
                continue;
            seen.add(inp);
            const siteName = this.getSiteName();
            const label = this.getLabel(inp) || 'chat input';
            // Type-prompt tool
            tools.push(this.createTool('chatbot.type-prompt', `Type a prompt in ${siteName} chat`, inp, this.makeInputSchema([
                {
                    name: 'text',
                    type: 'string',
                    description: 'The text to type in the chat input',
                    required: true,
                },
            ]), this.computeConfidence({
                hasAria: !!inp.getAttribute('aria-label'),
                hasLabel: !!label,
                hasName: !!inp.getAttribute('name'),
                isVisible: true,
                hasRole: !!inp.getAttribute('role'),
                hasSemanticTag: inp.tagName === 'TEXTAREA',
            })));
            this.claim(inp);
            // Find send button near the input
            const sendBtn = this.findSendButton(inp, root);
            if (sendBtn && !this.isClaimed(sendBtn)) {
                tools.push(this.createTool('chatbot.send-message', `Send message in ${siteName} chat`, sendBtn, this.makeInputSchema([]), this.computeConfidence({
                    hasAria: !!sendBtn.getAttribute('aria-label'),
                    hasLabel: !!this.getLabel(sendBtn),
                    hasName: false,
                    isVisible: this.isVisible(sendBtn),
                    hasRole: sendBtn.tagName === 'BUTTON',
                    hasSemanticTag: sendBtn.tagName === 'BUTTON',
                })));
                this.claim(sendBtn);
            }
            if (tools.length >= this.maxTools)
                break;
        }
        return tools;
    }
    /** Derive a human-friendly site name from the hostname */
    getSiteName() {
        try {
            const host = location.hostname.replace(/^www\./, '');
            if (host.includes('chat.openai') || host.includes('chatgpt'))
                return 'ChatGPT';
            if (host.includes('claude.ai'))
                return 'Claude';
            if (host.includes('gemini.google'))
                return 'Gemini';
            if (host.includes('grok') || host.includes('x.com'))
                return 'Grok';
            // Capitalize first segment
            return host.split('.')[0].charAt(0).toUpperCase() + host.split('.')[0].slice(1);
        }
        catch {
            return 'AI chatbot';
        }
    }
    /** Find the send button closest to a chatbot input */
    findSendButton(input, root) {
        // Check known selectors first
        for (const sel of SEND_BUTTON_SELECTORS) {
            const btn = root.querySelector(sel);
            if (btn && this.isVisible(btn))
                return btn;
        }
        // Walk up from the input to find the closest container with a button.
        // Grok nests textarea very deeply, so walk up to 12 levels.
        let container = input;
        for (let i = 0; i < 12 && container; i++) {
            container = container.parentElement;
            if (!container)
                break;
            // Look for submit-like buttons (including disabled ones — Grok disables until text is entered)
            const buttons = container.querySelectorAll('button');
            for (const btn of buttons) {
                const ariaLabel = btn.getAttribute('aria-label')?.toLowerCase() ?? '';
                const hasSvg = !!btn.querySelector('svg');
                // Match buttons that look like send buttons (have arrow SVG, or aria hint)
                if (ariaLabel.includes('send') ||
                    ariaLabel.includes('invia') ||
                    ariaLabel.includes('grok') ||
                    ariaLabel.includes('submit') ||
                    (hasSvg && btn.closest('form'))) {
                    return btn;
                }
            }
            // If we found a form or major container, try the first button with an SVG
            if (container.tagName === 'FORM' || container.querySelectorAll('textarea, [contenteditable]').length > 0) {
                const svgBtn = container.querySelector('button svg[viewBox]')?.closest('button');
                if (svgBtn)
                    return svgBtn;
            }
        }
        // Fallback: find a button with an SVG near the input's parent
        const fallback = input.closest('form') || input.parentElement?.parentElement;
        if (fallback) {
            const btn = fallback.querySelector('button svg[viewBox]')?.closest('button');
            if (btn && this.isVisible(btn))
                return btn;
        }
        return null;
    }
}


/***/ }),

/***/ "./src/content/scanners/ecommerce-scanner.ts":
/*!***************************************************!*\
  !*** ./src/content/scanners/ecommerce-scanner.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EcommerceScanner: () => (/* binding */ EcommerceScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * E-commerce Scanner — discovers add-to-cart buttons and quantity inputs.
 */

class EcommerceScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'ecommerce';
    scan(root) {
        const tools = [];
        // ── Add to Cart buttons ──
        const addToCart = root.querySelectorAll('[data-action="add-to-cart"], button[class*="add-to-cart" i], button[id*="add-to-cart" i], ' +
            'button[aria-label*="add to cart" i], [data-mcp-type="add-to-cart"]');
        for (const btn of addToCart) {
            const product = btn.closest('[itemtype*="Product"], [data-product-id], .product');
            const productName = product?.querySelector('[itemprop="name"]')?.textContent?.trim() || '';
            const productId = product?.dataset?.productId ||
                this.slugify(productName) ||
                'item';
            tools.push(this.createTool(`shop.add-to-cart-${this.slugify(productId)}`, `Add to cart: ${productName || productId}`, btn, this.makeInputSchema([
                {
                    name: 'quantity',
                    type: 'number',
                    description: 'Quantity to add',
                    default: 1,
                },
            ]), 0.9, {
                title: `Add to Cart: ${productName || productId}`,
                annotations: this.makeAnnotations({ destructive: true, idempotent: false }),
            }));
        }
        // ── Quantity inputs ──
        const qtyInputs = root.querySelectorAll('input[name*="quantity" i], input[name*="qty" i], [data-mcp-type="quantity"]');
        for (const inp of qtyInputs) {
            const product = inp.closest('[itemtype*="Product"], [data-product-id], .product');
            const label = product?.querySelector('[itemprop="name"]')?.textContent?.trim() || 'item';
            tools.push(this.createTool(`shop.set-quantity-${this.slugify(label)}`, `Set quantity for: ${label}`, inp, this.makeInputSchema([
                {
                    name: 'quantity',
                    type: 'number',
                    description: 'Desired quantity',
                    required: true,
                },
            ]), 0.8, {
                title: `Set Quantity: ${label}`,
                annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/file-upload-scanner.ts":
/*!*****************************************************!*\
  !*** ./src/content/scanners/file-upload-scanner.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileUploadScanner: () => (/* binding */ FileUploadScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * File Upload Scanner — discovers file inputs and drag-drop zones.
 * Does NOT use overbroad aria-label selectors (foto/photo/image)
 * which falsely matched profile images and photo buttons.
 */

class FileUploadScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'file-upload';
    scan(root) {
        const tools = [];
        // ── Standard file inputs (unambiguous) ──
        const fileInputs = root.querySelectorAll('input[type="file"]');
        for (const inp of fileInputs) {
            if (tools.length >= this.maxTools)
                break;
            if (this.isClaimed(inp))
                continue;
            const inputEl = inp;
            const label = this.getLabel(inp) || inputEl.accept || 'file';
            const slug = this.slugify(label);
            const accept = inputEl.accept || '*/*';
            this.claim(inp);
            tools.push(this.createTool(`upload.file-${slug}`, `Upload file (${accept}): ${label}`, inp, this.makeInputSchema([
                {
                    name: 'file_path',
                    type: 'string',
                    description: `Path to file to upload (accepts: ${accept})`,
                    required: true,
                },
            ]), 0.95, {
                title: `Upload: ${label}`,
                annotations: this.makeAnnotations({ destructive: true, idempotent: false }),
            }));
        }
        // ── Drop zones — only explicit drop-zone/upload patterns ──
        const dropZones = root.querySelectorAll('[class*="drop-zone" i], [class*="dropzone" i], [class*="upload-area" i], ' +
            '[data-testid*="upload" i], [data-testid*="dropzone" i]');
        for (const zone of dropZones) {
            if (tools.length >= this.maxTools)
                break;
            if (zone.tagName === 'INPUT' && zone.type === 'file')
                continue;
            if (this.isClaimed(zone))
                continue;
            if (!this.isVisible(zone))
                continue;
            const label = this.getLabel(zone) || 'upload area';
            // Skip garbage labels
            if (label.length > 60 || label.includes('\n'))
                continue;
            const slug = this.slugify(label);
            const hiddenInput = zone.querySelector('input[type="file"]') ||
                zone.parentElement?.querySelector('input[type="file"]');
            this.claim(zone);
            tools.push(this.createTool(`upload.drop-${slug}`, `Upload via drop zone: ${label}`, hiddenInput || zone, this.makeInputSchema([
                {
                    name: 'file_path',
                    type: 'string',
                    description: 'Path to file to upload',
                    required: true,
                },
            ]), 0.7, {
                title: `Upload: ${label}`,
                annotations: this.makeAnnotations({ destructive: true, idempotent: false }),
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/form-scanner.ts":
/*!**********************************************!*\
  !*** ./src/content/scanners/form-scanner.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FormScanner: () => (/* binding */ FormScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Form Scanner — discovers non-WMCP-native forms and their fields.
 * Only infers from forms that don't already have a `toolname` attribute.
 */

function resolveFormActionPath(form) {
    const attrAction = form.getAttribute('action')?.trim();
    if (attrAction) {
        try {
            const url = new URL(attrAction, location.href);
            const fromPath = url.pathname.split('/').pop()?.trim();
            if (fromPath)
                return fromPath;
            return url.hostname || 'form';
        }
        catch {
            const direct = attrAction.split('/').pop()?.trim();
            if (direct)
                return direct;
        }
    }
    const actionValue = form.action;
    if (typeof actionValue === 'string' && actionValue.trim().length > 0) {
        const direct = actionValue.split('/').pop()?.trim();
        if (direct)
            return direct;
    }
    return 'form';
}
class FormScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'form';
    scan(root) {
        const tools = [];
        const forms = root.querySelectorAll('form:not([toolname])');
        for (const form of forms) {
            const htmlForm = form;
            const name = this.slugify(form.getAttribute('aria-label') ||
                form.id ||
                resolveFormActionPath(htmlForm) ||
                'form') || 'unnamed-form';
            const inputs = form.querySelectorAll('input, select, textarea');
            if (inputs.length === 0)
                continue;
            const fields = [];
            for (const inp of inputs) {
                const inputEl = inp;
                if (inputEl.type === 'hidden' || inputEl.type === 'submit')
                    continue;
                const fieldName = inputEl.name || inputEl.id || this.slugify(this.getLabel(inp)) || 'field';
                const field = {
                    name: fieldName,
                    type: inputEl.type === 'number' ? 'number' : 'string',
                    description: this.getLabel(inp),
                    required: inputEl.required || inp.getAttribute('aria-required') === 'true',
                    // Enums for select
                    ...(inp.tagName === 'SELECT'
                        ? {
                            enum: [...inp.options]
                                .map(o => o.value)
                                .filter(Boolean),
                        }
                        : {}),
                };
                fields.push(field);
            }
            // Radio groups — collapse into a single enum field
            const radioGroups = new Map();
            for (const radio of form.querySelectorAll('input[type="radio"]')) {
                const gName = radio.name || 'radio';
                if (!radioGroups.has(gName))
                    radioGroups.set(gName, []);
                radioGroups.get(gName).push(radio.value);
            }
            for (const [gName, vals] of radioGroups) {
                const idx = fields.findIndex(f => f.name === gName);
                if (idx >= 0)
                    fields.splice(idx, 1);
                fields.push({ name: gName, type: 'string', enum: vals });
            }
            if (fields.length === 0)
                continue;
            const hasAriaLabel = !!form.getAttribute('aria-label');
            const label = this.getLabel(form) || name;
            tools.push(this.createTool(`form.submit-${name}`, `Submit form: ${label}`, form, this.makeInputSchema(fields), this.computeConfidence({
                hasAria: hasAriaLabel,
                hasLabel: !!this.getLabel(form),
                hasName: !!form.id,
                isVisible: this.isVisible(form),
                hasRole: false,
                hasSemanticTag: true,
            }), {
                title: `Submit: ${label}`,
                annotations: this.makeAnnotations({ destructive: true, idempotent: false }),
            }));
        }
        // ── Second pass: standalone (orphan) input fields not inside any <form> ──
        const orphanSelector = 'input:not([type="hidden"]):not([type="submit"]):not([type="button"]), select, textarea';
        const allInputs = root.querySelectorAll(orphanSelector);
        /** Track radio groups already emitted so we collapse them into one tool */
        const emittedRadioGroups = new Set();
        /** Track emitted slugs to avoid duplicate tool names */
        const emittedSlugs = new Set();
        for (const el of allInputs) {
            if (tools.length >= this.maxTools)
                break;
            if (el.closest('form'))
                continue;
            if (this.isClaimed(el))
                continue;
            if (!this.isVisible(el))
                continue;
            const inputEl = el;
            const inputType = inputEl.type?.toLowerCase() ?? '';
            // Radio groups — collapse into a single enum tool per group name
            if (inputType === 'radio') {
                const groupName = inputEl.name || 'radio';
                if (emittedRadioGroups.has(groupName))
                    continue;
                emittedRadioGroups.add(groupName);
                // Query all radios then filter by name in JS to avoid CSS selector injection
                const allRadios = root.querySelectorAll('input[type="radio"]');
                const vals = [];
                for (const r of allRadios) {
                    if (r.name === groupName && !r.closest('form')) {
                        vals.push(r.value);
                        this.claim(r);
                    }
                }
                if (vals.length === 0)
                    continue;
                const radioLabel = this.getLabel(el) || groupName;
                const radioSlug = this.slugify(groupName) || 'field';
                if (emittedSlugs.has(radioSlug))
                    continue;
                emittedSlugs.add(radioSlug);
                tools.push(this.createTool(`form.fill-${radioSlug}`, `Fill field: ${radioLabel}`, el, this.makeInputSchema([{ name: 'value', type: 'string', enum: vals }]), this.computeConfidence({
                    hasAria: !!el.getAttribute('aria-label'),
                    hasLabel: !!radioLabel,
                    hasName: !!inputEl.name,
                    isVisible: true,
                    hasRole: false,
                    hasSemanticTag: true,
                }), {
                    title: `Fill: ${radioLabel}`,
                    annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
                }));
                continue;
            }
            const fieldName = inputEl.name || inputEl.id || this.slugify(this.getLabel(el)) || 'field';
            const orphanLabel = this.getLabel(el) || fieldName;
            let slug = this.slugify(fieldName) || 'field';
            // Deduplicate slug names
            if (emittedSlugs.has(slug)) {
                let suffix = 2;
                while (emittedSlugs.has(`${slug}-${suffix}`))
                    suffix++;
                slug = `${slug}-${suffix}`;
            }
            emittedSlugs.add(slug);
            let field;
            if (el.tagName === 'SELECT') {
                const opts = [...el.options]
                    .map(o => o.value)
                    .filter(Boolean);
                field = { name: 'value', type: 'string', enum: opts };
            }
            else if (inputType === 'checkbox') {
                field = { name: 'value', type: 'boolean' };
            }
            else {
                field = {
                    name: 'value',
                    type: inputType === 'number' ? 'number' : 'string',
                };
            }
            this.claim(el);
            tools.push(this.createTool(`form.fill-${slug}`, `Fill field: ${orphanLabel}`, el, this.makeInputSchema([field]), this.computeConfidence({
                hasAria: !!el.getAttribute('aria-label'),
                hasLabel: !!orphanLabel,
                hasName: !!inputEl.name || !!inputEl.id,
                isVisible: true,
                hasRole: false,
                hasSemanticTag: true,
            }), {
                title: `Fill: ${orphanLabel}`,
                annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/index.ts":
/*!***************************************!*\
  !*** ./src/content/scanners/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseScanner: () => (/* reexport safe */ _base_scanner__WEBPACK_IMPORTED_MODULE_1__.BaseScanner),
/* harmony export */   ScannerRegistry: () => (/* binding */ ScannerRegistry),
/* harmony export */   claimElement: () => (/* reexport safe */ _base_scanner__WEBPACK_IMPORTED_MODULE_1__.claimElement),
/* harmony export */   collectShadowRoots: () => (/* reexport safe */ _base_scanner__WEBPACK_IMPORTED_MODULE_1__.collectShadowRoots),
/* harmony export */   isElementClaimed: () => (/* reexport safe */ _base_scanner__WEBPACK_IMPORTED_MODULE_1__.isElementClaimed),
/* harmony export */   isSocialKeyword: () => (/* reexport safe */ _base_scanner__WEBPACK_IMPORTED_MODULE_1__.isSocialKeyword)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/* harmony import */ var _form_scanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./form-scanner */ "./src/content/scanners/form-scanner.ts");
/* harmony import */ var _navigation_scanner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./navigation-scanner */ "./src/content/scanners/navigation-scanner.ts");
/* harmony import */ var _search_scanner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./search-scanner */ "./src/content/scanners/search-scanner.ts");
/* harmony import */ var _richtext_scanner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./richtext-scanner */ "./src/content/scanners/richtext-scanner.ts");
/* harmony import */ var _social_scanner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./social-scanner */ "./src/content/scanners/social-scanner.ts");
/* harmony import */ var _file_upload_scanner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./file-upload-scanner */ "./src/content/scanners/file-upload-scanner.ts");
/* harmony import */ var _interactive_scanner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./interactive-scanner */ "./src/content/scanners/interactive-scanner.ts");
/* harmony import */ var _media_scanner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./media-scanner */ "./src/content/scanners/media-scanner.ts");
/* harmony import */ var _ecommerce_scanner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ecommerce-scanner */ "./src/content/scanners/ecommerce-scanner.ts");
/* harmony import */ var _auth_scanner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./auth-scanner */ "./src/content/scanners/auth-scanner.ts");
/* harmony import */ var _page_state_scanner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./page-state-scanner */ "./src/content/scanners/page-state-scanner.ts");
/* harmony import */ var _schema_org_scanner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./schema-org-scanner */ "./src/content/scanners/schema-org-scanner.ts");
/* harmony import */ var _chatbot_scanner__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./chatbot-scanner */ "./src/content/scanners/chatbot-scanner.ts");
/**
 * Scanner Registry — registers all 13 category scanners, runs them
 * in priority order, deduplicates results, and supports cache invalidation.
 */

















/** Map from category name to scanner instance */
const SCANNER_MAP = new Map([
    ['form', new _form_scanner__WEBPACK_IMPORTED_MODULE_2__.FormScanner()],
    ['navigation', new _navigation_scanner__WEBPACK_IMPORTED_MODULE_3__.NavigationScanner()],
    ['search', new _search_scanner__WEBPACK_IMPORTED_MODULE_4__.SearchScanner()],
    ['richtext', new _richtext_scanner__WEBPACK_IMPORTED_MODULE_5__.RichTextScanner()],
    ['social-action', new _social_scanner__WEBPACK_IMPORTED_MODULE_6__.SocialScanner()],
    ['file-upload', new _file_upload_scanner__WEBPACK_IMPORTED_MODULE_7__.FileUploadScanner()],
    ['interactive', new _interactive_scanner__WEBPACK_IMPORTED_MODULE_8__.InteractiveScanner()],
    ['media', new _media_scanner__WEBPACK_IMPORTED_MODULE_9__.MediaScanner()],
    ['ecommerce', new _ecommerce_scanner__WEBPACK_IMPORTED_MODULE_10__.EcommerceScanner()],
    ['auth', new _auth_scanner__WEBPACK_IMPORTED_MODULE_11__.AuthScanner()],
    ['page-state', new _page_state_scanner__WEBPACK_IMPORTED_MODULE_12__.PageStateScanner()],
    ['schema-org', new _schema_org_scanner__WEBPACK_IMPORTED_MODULE_13__.SchemaOrgScanner()],
    ['chatbot', new _chatbot_scanner__WEBPACK_IMPORTED_MODULE_14__.ChatbotScanner()],
]);
class ScannerRegistry {
    scanners;
    constructor() {
        // Build scanner list in SCANNER_CATEGORIES priority order
        this.scanners = _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SCANNER_CATEGORIES.map(cat => {
            const scanner = SCANNER_MAP.get(cat);
            if (!scanner)
                throw new Error(`No scanner registered for category: ${cat}`);
            return scanner;
        });
    }
    /**
     * Run all 13 scanners on a root node (+ open Shadow DOM roots).
     * Deduplicates by tool name, keeping the highest-confidence entry.
     */
    scanAll(root = document) {
        const allTools = [];
        // Scan main root with per-scanner timing
        for (const scanner of this.scanners) {
            try {
                const t0 = performance.now();
                const results = scanner.scan(root);
                const elapsed = performance.now() - t0;
                if (elapsed > 10) {
                    console.debug(`[ScannerRegistry] Scanner "${scanner.category}" took ${elapsed.toFixed(1)}ms (${results.length} tools)`);
                }
                allTools.push(...results);
            }
            catch (e) {
                console.warn(`[ScannerRegistry] Scanner "${scanner.category}" failed:`, e.message);
            }
        }
        // Scan open Shadow DOM roots
        const shadowRoots = (0,_base_scanner__WEBPACK_IMPORTED_MODULE_1__.collectShadowRoots)(root);
        if (shadowRoots.length > 0) {
            for (const sr of shadowRoots) {
                for (const scanner of this.scanners) {
                    try {
                        const t0 = performance.now();
                        const results = scanner.scan(sr);
                        const elapsed = performance.now() - t0;
                        if (elapsed > 10) {
                            console.debug(`[ScannerRegistry] Shadow scanner "${scanner.category}" took ${elapsed.toFixed(1)}ms`);
                        }
                        allTools.push(...results);
                    }
                    catch (e) {
                        console.warn(`[ScannerRegistry] Shadow scanner "${scanner.category}" failed:`, e.message);
                    }
                }
            }
        }
        // Deduplicate by name — keep highest confidence
        const deduped = new Map();
        for (const tool of allTools) {
            const existing = deduped.get(tool.name);
            if (!existing || (tool.confidence ?? 0) > (existing.confidence ?? 0)) {
                deduped.set(tool.name, tool);
            }
        }
        return [...deduped.values()];
    }
    /** Get a specific scanner by category */
    getScanner(category) {
        return SCANNER_MAP.get(category);
    }
}


/***/ }),

/***/ "./src/content/scanners/interactive-scanner.ts":
/*!*****************************************************!*\
  !*** ./src/content/scanners/interactive-scanner.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InteractiveScanner: () => (/* binding */ InteractiveScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Interactive Scanner — discovers buttons, tabs, toggles, dropdowns.
 * Runs AFTER social-action, richtext, and file-upload scanners so that
 * _claimedElements dedup prevents double-counting.
 */

class InteractiveScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'interactive';
    scan(root) {
        const tools = [];
        // ── Buttons ──
        const buttons = root.querySelectorAll('button:not(form[toolname] button), [role="button"]:not(a), input[type="button"]');
        for (const btn of buttons) {
            if (tools.length >= this.maxTools)
                break;
            const inputBtn = btn;
            if (inputBtn.type === 'submit' && btn.closest('form:not([toolname])'))
                continue;
            if (this.isClaimed(btn))
                continue;
            if (!this.isVisible(btn))
                continue;
            if (!this.hasMeaningfulSize(btn, 30, 20))
                continue;
            const label = this.getLabel(btn);
            if (!label || label.length < 2 || label.length > 60)
                continue;
            // Skip social actions — they belong to the social-action scanner
            if ((0,_base_scanner__WEBPACK_IMPORTED_MODULE_0__.isSocialKeyword)(label))
                continue;
            // Skip generic accessibility skip-links
            if (/^(vai a|skip to|go to content)/i.test(label))
                continue;
            this.claim(btn);
            tools.push(this.createTool(`ui.click-${this.slugify(label)}`, `Click: ${label}`, btn, this.makeInputSchema([]), this.computeConfidence({
                hasAria: !!btn.getAttribute('aria-label'),
                hasLabel: true,
                hasName: !!btn.id,
                isVisible: true,
                hasRole: btn.getAttribute('role') === 'button' || btn.tagName === 'BUTTON',
                hasSemanticTag: btn.tagName === 'BUTTON',
            }), {
                annotations: this.makeAnnotations({ destructive: false, idempotent: false }),
            }));
        }
        // ── Tabs ──
        const tabs = root.querySelectorAll('[role="tab"]');
        for (const tab of tabs) {
            if (this.isClaimed(tab))
                continue;
            const label = this.getLabel(tab);
            if (!label)
                continue;
            this.claim(tab);
            tools.push(this.createTool(`ui.select-tab-${this.slugify(label)}`, `Select tab: ${label}`, tab, this.makeInputSchema([]), 0.85, {
                title: `Tab: ${label}`,
                annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
            }));
        }
        // ── Toggle switches ──
        const toggles = root.querySelectorAll('[role="switch"], input[type="checkbox"][role="switch"]');
        for (const toggle of toggles) {
            if (this.isClaimed(toggle))
                continue;
            const label = this.getLabel(toggle);
            if (!label)
                continue;
            this.claim(toggle);
            tools.push(this.createTool(`ui.toggle-${this.slugify(label)}`, `Toggle: ${label}`, toggle, this.makeInputSchema([
                { name: 'checked', type: 'boolean', description: 'Desired state' },
            ]), 0.9, {
                annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
            }));
        }
        // ── Dropdowns / comboboxes ──
        const combos = root.querySelectorAll('[role="combobox"], [role="listbox"]');
        for (const combo of combos) {
            if (this.isClaimed(combo))
                continue;
            const label = this.getLabel(combo);
            if (!label)
                continue;
            this.claim(combo);
            const options = [...combo.querySelectorAll('[role="option"]')].map(o => o.textContent?.trim() ?? '');
            tools.push(this.createTool(`ui.select-${this.slugify(label)}`, `Select option from: ${label}`, combo, this.makeInputSchema([
                {
                    name: 'value',
                    type: 'string',
                    description: 'Option to select',
                    ...(options.length ? { enum: options } : {}),
                },
            ]), 0.85, {
                title: `Select: ${label}`,
                annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
            }));
        }
        // ── Custom clickable elements (non-semantic divs acting as buttons) ──
        // Catches elements like LinkedIn's "Start a post" trigger that use
        // tabindex + aria-label instead of <button> or role="button".
        const clickables = root.querySelectorAll('[tabindex="0"][aria-label]' +
            ':not(button):not(a):not(input):not(select):not(textarea)' +
            ':not([role="button"]):not([role="tab"]):not([role="switch"])' +
            ':not([role="combobox"]):not([role="listbox"])' +
            ':not([role="textbox"]):not([contenteditable="true"])');
        for (const el of clickables) {
            if (tools.length >= this.maxTools)
                break;
            if (this.isClaimed(el))
                continue;
            if (!this.isVisible(el))
                continue;
            if (!this.hasMeaningfulSize(el, 30, 20))
                continue;
            const label = this.getLabel(el);
            if (!label || label.length < 2 || label.length > 60)
                continue;
            if ((0,_base_scanner__WEBPACK_IMPORTED_MODULE_0__.isSocialKeyword)(label))
                continue;
            if (/^(vai a|skip to|go to content)/i.test(label))
                continue;
            this.claim(el);
            tools.push(this.createTool(`ui.click-${this.slugify(label)}`, `Click: ${label}`, el, this.makeInputSchema([]), this.computeConfidence({
                hasAria: true,
                hasLabel: true,
                hasName: !!el.id,
                isVisible: true,
                hasRole: !!el.getAttribute('role'),
                hasSemanticTag: false,
            }), {
                annotations: this.makeAnnotations({ destructive: false, idempotent: false }),
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/media-scanner.ts":
/*!***********************************************!*\
  !*** ./src/content/scanners/media-scanner.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MediaScanner: () => (/* binding */ MediaScanner)
/* harmony export */ });
/* harmony import */ var _media__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../media */ "./src/content/media/index.ts");
/* harmony import */ var _live_state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../live-state */ "./src/content/live-state/index.ts");
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Media Scanner — unified semantic media tool discovery.
 */



class MediaScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_2__.BaseScanner {
    category = 'media';
    scan(root) {
        const registry = (0,_media__WEBPACK_IMPORTED_MODULE_0__.getPlayerRegistry)();
        const players = registry.refresh(root);
        const tools = [];
        for (const player of players) {
            for (const action of _media__WEBPACK_IMPORTED_MODULE_0__.CORE_MEDIA_ACTIONS) {
                if (!this.supportsAction(player, action))
                    continue;
                tools.push(this.createMediaTool(player, action));
            }
            for (const action of _media__WEBPACK_IMPORTED_MODULE_0__.PLAYLIST_MEDIA_ACTIONS) {
                if (!this.supportsAction(player, action))
                    continue;
                tools.push(this.createMediaTool(player, action));
            }
        }
        return tools;
    }
    createMediaTool(player, action) {
        const label = this.getPlayerLabel(player);
        const { description, title } = this.getActionText(action, label);
        const enriched = description + this.getLiveStateHint(player.id, action);
        const schema = this.getActionSchema(action);
        const confidence = player.platform === 'youtube' ? 0.95 : 0.9;
        return this.createTool(`media.${action}.${player.id}`, enriched, player.anchorElement, schema, confidence, {
            title,
            annotations: this.getActionAnnotations(action),
        });
    }
    getPlayerLabel(player) {
        const anchor = player.anchorElement;
        const explicit = anchor ? this.getLabel(anchor) : '';
        const readableId = player.id.replace(/-/g, ' ').trim();
        return explicit || readableId || player.platform;
    }
    getActionSchema(action) {
        if (action === 'seek') {
            return this.makeInputSchema([
                { name: 'time', type: 'number', description: 'Time in seconds', required: true },
            ]);
        }
        if (action === 'set-volume') {
            return this.makeInputSchema([
                { name: 'level', type: 'number', description: 'Volume from 0.0 to 1.0', required: true },
            ]);
        }
        return this.makeInputSchema([]);
    }
    getActionAnnotations(action) {
        if (action === 'get-state' || action === 'get-transcript') {
            return this.makeAnnotations({ readOnly: true, idempotent: true });
        }
        const idempotent = action === 'pause' || action === 'mute' || action === 'unmute';
        return this.makeAnnotations({ readOnly: false, idempotent });
    }
    getActionText(action, label) {
        const map = {
            play: {
                description: `Play media: ${label}`,
                title: `Play: ${label}`,
            },
            pause: {
                description: `Pause media: ${label}`,
                title: `Pause: ${label}`,
            },
            seek: {
                description: `Seek media timeline: ${label}`,
                title: `Seek: ${label}`,
            },
            'set-volume': {
                description: `Set media volume: ${label}`,
                title: `Set volume: ${label}`,
            },
            mute: {
                description: `Mute media: ${label}`,
                title: `Mute: ${label}`,
            },
            unmute: {
                description: `Unmute media: ${label}`,
                title: `Unmute: ${label}`,
            },
            'get-state': {
                description: `Get media state: ${label}`,
                title: `Get state: ${label}`,
            },
            'get-transcript': {
                description: `Get media transcript: ${label}`,
                title: `Get transcript: ${label}`,
            },
            'next-track': {
                description: `Next track: ${label}`,
                title: `Next track: ${label}`,
            },
            'previous-track': {
                description: `Previous track: ${label}`,
                title: `Previous track: ${label}`,
            },
            shuffle: {
                description: `Shuffle playlist: ${label}`,
                title: `Shuffle: ${label}`,
            },
        };
        return map[action];
    }
    supportsAction(player, action) {
        switch (action) {
            case 'play':
                return player.capabilities.play;
            case 'pause':
                return player.capabilities.pause;
            case 'seek':
                return player.capabilities.seek;
            case 'set-volume':
                return player.capabilities.setVolume;
            case 'mute':
                return player.capabilities.mute;
            case 'unmute':
                return player.capabilities.unmute;
            case 'get-state':
                return player.capabilities.getState;
            case 'get-transcript':
                return player.platform === 'youtube';
            case 'next-track':
                return player.capabilities.nextTrack;
            case 'previous-track':
                return player.capabilities.previousTrack;
            case 'shuffle':
                return player.capabilities.shuffle;
            default:
                return false;
        }
    }
    /** Return a live-state hint suffix for the tool description, or empty string. */
    getLiveStateHint(playerId, action) {
        const mediaStates = (0,_live_state__WEBPACK_IMPORTED_MODULE_1__.getLiveStateManager)().getLatestSnapshot()?.media;
        if (!mediaStates)
            return '';
        const state = mediaStates.find((m) => m.playerId === playerId);
        if (!state)
            return '';
        const time = this.fmtTimeSec(state.currentTime);
        switch (action) {
            case 'play':
                return state.paused ? '' : ` ⚠️ Already playing at ${time}. Use seek(0) to restart`;
            case 'pause':
                return state.paused ? ` ℹ️ Already paused at ${time}` : '';
            case 'mute':
                return state.muted ? ' ℹ️ Already muted' : '';
            case 'unmute':
                return state.muted ? '' : ' ℹ️ Already unmuted';
            case 'get-state': {
                const status = state.paused ? 'paused' : 'playing';
                return ` (current: ${status} at ${time}, vol ${Math.round(state.volume * 100)}%)`;
            }
            default:
                return '';
        }
    }
    fmtTimeSec(seconds) {
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    }
}


/***/ }),

/***/ "./src/content/scanners/navigation-scanner.ts":
/*!****************************************************!*\
  !*** ./src/content/scanners/navigation-scanner.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NavigationScanner: () => (/* binding */ NavigationScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Navigation Scanner — discovers ALL clickable links on the page as navigation tools.
 * Groups links by semantic page section (header, nav, main, sidebar, footer, etc.).
 */

class NavigationScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'navigation';
    maxTools = 200;
    scan(root) {
        const tools = [];
        const seen = new Set();
        const allLinks = root.querySelectorAll('a[href]');
        for (const link of allLinks) {
            const href = link.getAttribute('href');
            if (!href ||
                href === '#' ||
                href.startsWith('javascript:') ||
                href.startsWith('mailto:') ||
                href.startsWith('tel:'))
                continue;
            const label = this.getLabel(link) || link.textContent?.trim() || '';
            if (!label || label.length < 2)
                continue;
            const absoluteHref = link.href;
            if (seen.has(absoluteHref))
                continue;
            seen.add(absoluteHref);
            const section = this.detectSection(link);
            const inNav = section === 'nav' || section === 'header';
            tools.push(this.createTool(`nav.${section}.go-${this.slugify(label)}`, `Navigate to: ${label} [${section}] (${absoluteHref})`, link, this.makeInputSchema([]), this.computeConfidence({
                hasAria: !!link.getAttribute('aria-label'),
                hasLabel: true,
                hasName: true,
                isVisible: this.isVisible(link),
                hasRole: inNav,
                hasSemanticTag: inNav,
            }), {
                title: `[${section}] ${label}`,
                annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
            }));
        }
        return tools;
    }
    /** Detect the semantic section a link belongs to */
    detectSection(el) {
        // Walk up the DOM to find the nearest semantic container
        const nav = el.closest('nav, [role="navigation"]');
        if (nav)
            return 'nav';
        const header = el.closest('header, [role="banner"]');
        if (header)
            return 'header';
        const footer = el.closest('footer, [role="contentinfo"]');
        if (footer)
            return 'footer';
        const aside = el.closest('aside, [role="complementary"]');
        if (aside)
            return 'sidebar';
        const main = el.closest('main, [role="main"], article, [role="article"]');
        if (main)
            return 'main';
        // Heuristic: check parent IDs/classes for common patterns
        let parent = el.parentElement;
        for (let i = 0; i < 5 && parent; i++) {
            const id = parent.id?.toLowerCase() || '';
            const cls = parent.className?.toString?.()?.toLowerCase() || '';
            const combined = `${id} ${cls}`;
            if (/header|top-bar|masthead|banner/.test(combined))
                return 'header';
            if (/footer|bottom|colophon/.test(combined))
                return 'footer';
            if (/nav|menu|navigation|breadcrumb/.test(combined))
                return 'nav';
            if (/sidebar|side-bar|aside|panel/.test(combined))
                return 'sidebar';
            if (/main|content|body|article/.test(combined))
                return 'main';
            parent = parent.parentElement;
        }
        return 'page';
    }
}


/***/ }),

/***/ "./src/content/scanners/page-state-scanner.ts":
/*!****************************************************!*\
  !*** ./src/content/scanners/page-state-scanner.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageStateScanner: () => (/* binding */ PageStateScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Page State Scanner — discovers scroll, print, theme toggle controls.
 * Always emits scroll-to-top and scroll-to-bottom (virtual tools).
 */

class PageStateScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'page-state';
    scan(root) {
        const tools = [];
        // Always-available virtual scroll tools
        tools.push(this.createTool('page.scroll-to-top', 'Scroll to the top of the page', null, this.makeInputSchema([]), 1.0, {
            title: 'Scroll to Top',
            annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
        }));
        tools.push(this.createTool('page.scroll-to-bottom', 'Scroll to the bottom of the page', null, this.makeInputSchema([]), 1.0, {
            title: 'Scroll to Bottom',
            annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
        }));
        // ── Back to top button ──
        const backToTop = root.querySelector('[aria-label*="back to top" i], [class*="back-to-top" i], #back-to-top');
        if (backToTop) {
            tools.push(this.createTool('page.click-back-to-top', 'Click the back-to-top button', backToTop, this.makeInputSchema([]), 0.9, {
                title: 'Back to Top Button',
                annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
            }));
        }
        // ── Theme toggle ──
        const themeToggle = root.querySelector('[aria-label*="dark mode" i], [aria-label*="theme" i], ' +
            'button[class*="theme" i], [data-action="toggle-theme"]');
        if (themeToggle) {
            tools.push(this.createTool('page.toggle-theme', 'Toggle dark/light mode', themeToggle, this.makeInputSchema([]), 0.85, {
                title: 'Toggle Theme',
                annotations: this.makeAnnotations({ readOnly: false, idempotent: false }),
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/richtext-scanner.ts":
/*!**************************************************!*\
  !*** ./src/content/scanners/richtext-scanner.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RichTextScanner: () => (/* binding */ RichTextScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Rich Text Scanner — discovers contenteditable surfaces, WYSIWYG editors,
 * social media post composers, and role="textbox" outside <form>.
 */

/** All rich text editing surface selectors */
const RICH_TEXT_SELECTORS = [
    // Generic contenteditable
    '[contenteditable="true"]',
    '[contenteditable="plaintext-only"]',
    // ARIA textbox not inside a standard form
    '[role="textbox"]:not(input):not(textarea)',
    // Platform-specific selectors
    '[data-testid*="tweetTextarea" i]',
    '[data-testid^="tweetTextarea_"]',
    '[data-testid*="dmComposerTextInput" i]',
    '[data-testid*="dmComposer" i]',
    '[data-testid="post-composer" i]',
    '[aria-label*="post" i][contenteditable]',
    '[aria-label*="post your reply" i]',
    '[aria-label*="post your message" i]',
    '[aria-label*="direct message" i]',
    '[aria-label*="What\'s on your mind" i]',
    '[aria-label*="Start a post" i]',
    '[aria-label*="Avvia un post" i]',
    '[aria-label*="write a comment" i]',
    '[aria-label*="write a reply" i]',
    '[aria-label*="scrivi un post" i]',
    '[aria-label*="componi" i]',
    '[aria-label*="comment" i]',
    '[aria-label*="reply" i]',
    '[aria-label*="message" i]',
    '[placeholder*="comment" i]',
    '[placeholder*="reply" i]',
    '[placeholder*="message" i]',
    // Textareas / textboxes for comment/message composers
    'textarea[aria-label*="comment" i]',
    'textarea[aria-label*="reply" i]',
    'textarea[placeholder*="comment" i]',
    'textarea[placeholder*="reply" i]',
    'textarea[placeholder*="message" i]',
    'textarea[data-testid*="comment" i]',
    // YouTube comment UI
    'ytd-comment-simplebox-renderer #contenteditable-root',
    'ytd-comment-simplebox-renderer #simplebox-placeholder',
    // WhatsApp composer surface
    'div[contenteditable="true"][data-tab]',
    'div[data-testid*="conversation-compose-box-input" i]',
    // Popular WYSIWYG editors
    '.DraftEditor-root [contenteditable]',
    '.ProseMirror',
    '.ql-editor',
    '.tox-edit-area__iframe',
    '.ck-editor__editable',
    '[data-slate-editor="true"]',
    '.CodeMirror-code',
    '.monaco-editor .inputarea',
];
/** Map of hostnames to platform display names */
const PLATFORM_MAP = [
    [/linkedin/i, 'LinkedIn'],
    [/twitter|x\.com/i, 'X/Twitter'],
    [/facebook|fb\.com/i, 'Facebook'],
    [/instagram/i, 'Instagram'],
    [/threads\.net/i, 'Threads'],
    [/reddit/i, 'Reddit'],
    [/mastodon|fosstodon/i, 'Mastodon'],
];
class RichTextScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'richtext';
    scan(root) {
        const tools = [];
        const seen = new Set(); // Local dedup
        const elements = root.querySelectorAll(RICH_TEXT_SELECTORS.join(', '));
        for (const el of elements) {
            if (tools.length >= this.maxTools)
                break;
            if (this.isClaimed(el))
                continue;
            // Skip tiny elements (likely hidden or utility)
            const rect = el.getBoundingClientRect?.();
            if (rect && (rect.width < 50 || rect.height < 20))
                continue;
            // Skip if inside a form with toolname
            if (el.closest('form[toolname]'))
                continue;
            // Skip elements that are NOT actual editing surfaces — aria-label selectors
            // (e.g. "[aria-label*='Start a post']") can match trigger buttons
            const label = this.getLabel(el);
            const semanticText = this.buildSemanticText(el, label);
            const isComment = /comment|reply|risposta|commento|rispondi|tweetdetail/i.test(semanticText);
            const isMessage = /message|messaggio|dm|chat|invia messaggio|composer/i.test(semanticText);
            const editable = this.isEditableSurface(el);
            const isCommentTrigger = isComment && this.isLikelyEditorTrigger(el);
            const isMessageTrigger = isMessage && this.isLikelyEditorTrigger(el);
            if (!editable && !isCommentTrigger && !isMessageTrigger)
                continue;
            // Build a unique key for local dedup
            const elId = el.id || el.getAttribute('data-testid') || '';
            const dedupKey = `${label}::${elId}::${el.tagName}`;
            if (seen.has(dedupKey))
                continue;
            seen.add(dedupKey);
            const slug = this.slugify(label || elId || 'editor');
            // Detect platform from hostname
            const host = location.hostname;
            let platform = '';
            for (const [re, name] of PLATFORM_MAP) {
                if (re.test(host)) {
                    platform = name;
                    break;
                }
            }
            const descPrefix = platform ? `${platform} — ` : '';
            const toolType = isComment ? 'comment' : isMessage ? 'message' : 'compose';
            this.claim(el);
            tools.push(this.createTool(`richtext.${toolType}-${slug}`, `${descPrefix}Write text in: ${label || 'rich text editor'}`, el, this.makeInputSchema([
                {
                    name: 'text',
                    type: 'string',
                    description: `Content to write${platform ? ` on ${platform}` : ''}`,
                    required: true,
                },
            ]), this.computeConfidence({
                hasAria: !!el.getAttribute('aria-label'),
                hasLabel: !!label,
                hasName: !!elId,
                isVisible: true,
                hasRole: el.getAttribute('role') === 'textbox' ||
                    el.isContentEditable,
                hasSemanticTag: false,
            }), {
                title: `${descPrefix}${isComment ? 'Comment' : isMessage ? 'Message' : 'Compose'}: ${label || 'text editor'}`,
                annotations: this.makeAnnotations({ destructive: false, idempotent: true }),
            }));
        }
        return tools;
    }
    isEditableSurface(el) {
        const htmlEl = el;
        if (htmlEl.isContentEditable)
            return true;
        if (el.getAttribute('role') === 'textbox')
            return true;
        if (el.matches('textarea, input[type="text"], .CodeMirror-code, .ProseMirror, .ql-editor')) {
            return true;
        }
        if (el.querySelector('[contenteditable="true"], [contenteditable="plaintext-only"]')) {
            return true;
        }
        return false;
    }
    isLikelyEditorTrigger(el) {
        if (el.isContentEditable)
            return false;
        if (el.matches('button, [role="button"], [tabindex], ytd-comment-simplebox-renderer #simplebox-placeholder')) {
            return true;
        }
        return false;
    }
    buildSemanticText(el, label) {
        const ariaLabel = el.getAttribute('aria-label') || '';
        const placeholder = el.placeholder || '';
        const ariaPlaceholder = el.getAttribute('aria-placeholder') || '';
        const testId = el.getAttribute('data-testid') || '';
        const className = el.getAttribute('class') || '';
        return [
            label,
            ariaLabel,
            placeholder,
            ariaPlaceholder,
            testId,
            className,
        ]
            .join(' ')
            .toLowerCase();
    }
}


/***/ }),

/***/ "./src/content/scanners/schema-org-scanner.ts":
/*!****************************************************!*\
  !*** ./src/content/scanners/schema-org-scanner.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchemaOrgScanner: () => (/* binding */ SchemaOrgScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Schema.org Scanner — discovers potentialAction entries in JSON-LD.
 */

class SchemaOrgScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'schema-org';
    scan(root) {
        const tools = [];
        const ldScripts = root.querySelectorAll('script[type="application/ld+json"]');
        for (const script of ldScripts) {
            try {
                const data = JSON.parse(script.textContent || '');
                const items = Array.isArray(data) ? data : [data];
                for (const item of items) {
                    if (!item.potentialAction)
                        continue;
                    const actions = Array.isArray(item.potentialAction)
                        ? item.potentialAction
                        : [item.potentialAction];
                    for (const action of actions) {
                        const actionType = action['@type'] || 'Action';
                        const target = action.target;
                        const name = this.slugify(action.name || actionType);
                        const fields = [];
                        if (typeof target === 'object' && target['query-input']) {
                            const match = target['query-input'].match(/name=(\w+)/);
                            fields.push({
                                name: match ? match[1] : 'query',
                                type: 'string',
                                description: `Input for ${actionType}`,
                                required: true,
                            });
                        }
                        else if (typeof target === 'string' && target.includes('{')) {
                            const placeholders = target.match(/\{([^}]+)\}/g) || [];
                            for (const ph of placeholders) {
                                fields.push({
                                    name: ph.replace(/[{}]/g, ''),
                                    type: 'string',
                                    description: `Parameter: ${ph.replace(/[{}]/g, '')}`,
                                    required: true,
                                });
                            }
                        }
                        const title = `${actionType}: ${action.name || ''}`.trim();
                        tools.push(this.createTool(`schema.${name}`, title, null, this.makeInputSchema(fields), 0.95, {
                            title,
                            annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
                            schemaAction: action,
                        }));
                    }
                }
            }
            catch {
                // Invalid JSON-LD, skip
            }
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/search-scanner.ts":
/*!************************************************!*\
  !*** ./src/content/scanners/search-scanner.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchScanner: () => (/* binding */ SearchScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Search Scanner — discovers search inputs (type="search", role="search", etc.).
 */

class SearchScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'search';
    scan(root) {
        const tools = [];
        const searchInputs = root.querySelectorAll('input[type="search"], [role="search"] input, input[name*="search" i], input[name*="query" i], input[name="q"], input[name="s"]');
        for (const inp of searchInputs) {
            const form = inp.closest('form');
            const name = this.slugify(inp.getAttribute('aria-label') ||
                inp.placeholder ||
                'search');
            tools.push(this.createTool(`search.query-${name}`, `Search: ${this.getLabel(inp) || 'site search'}`, inp, this.makeInputSchema([
                {
                    name: 'query',
                    type: 'string',
                    description: 'Search query',
                    required: true,
                },
            ]), this.computeConfidence({
                hasAria: !!inp.getAttribute('aria-label'),
                hasLabel: !!this.getLabel(inp),
                hasName: true,
                isVisible: this.isVisible(inp),
                hasRole: !!inp.closest('[role="search"]'),
                hasSemanticTag: inp.type === 'search',
            }), {
                annotations: this.makeAnnotations({ readOnly: true, idempotent: true }),
                form,
            }));
        }
        return tools;
    }
}


/***/ }),

/***/ "./src/content/scanners/social-scanner.ts":
/*!************************************************!*\
  !*** ./src/content/scanners/social-scanner.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SocialScanner: () => (/* binding */ SocialScanner)
/* harmony export */ });
/* harmony import */ var _base_scanner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base-scanner */ "./src/content/scanners/base-scanner.ts");
/**
 * Social Action Scanner — discovers social media actions across platforms
 * (Facebook, Instagram, WhatsApp, X, LinkedIn, Threads, etc.).
 */

const LIKE_RE = /\b(reagisci|like|mi piace|consiglia|upvote|heart|reaction|react|love)\b/i;
const SHARE_RE = /\b(share|condividi|diffondi|repost|retweet|forward|inoltra|send to|invia a)\b/i;
const FOLLOW_RE = /\b(follow|segui|subscribe|iscriviti|segui già|following)\b/i;
const COMMENT_RE = /\b(comment|commenta|reply|rispondi|risposta|add comment|leave a comment)\b/i;
const MESSAGE_RE = /\b(message|messaggio|chat|invia messaggio|send message|whatsapp|dm|direct message)\b/i;
const SAVE_RE = /\b(save|salva|bookmark|preferiti|saved)\b/i;
const JOIN_RE = /\b(join|unisciti|iscriviti al gruppo|partecipa)\b/i;
const DESCRIPTIONS = {
    like: 'Like/React',
    share: 'Share/Repost',
    follow: 'Follow/Subscribe',
    comment: 'Open comment/reply composer',
    message: 'Open message/chat action',
    save: 'Save/Bookmark content',
    join: 'Join community/channel/group',
};
const TITLES = {
    like: 'Like',
    share: 'Share',
    follow: 'Follow',
    comment: 'Comment',
    message: 'Message',
    save: 'Save',
    join: 'Join',
};
const PLATFORM_MAP = [
    { re: /facebook|fb\.com/i, name: 'facebook' },
    { re: /instagram/i, name: 'instagram' },
    { re: /whatsapp/i, name: 'whatsapp' },
    { re: /twitter|x\.com/i, name: 'x' },
    { re: /linkedin/i, name: 'linkedin' },
    { re: /threads\.net/i, name: 'threads' },
    { re: /tiktok/i, name: 'tiktok' },
    { re: /reddit/i, name: 'reddit' },
    { re: /youtube/i, name: 'youtube' },
];
const X_TESTID_RULES = [
    { token: 'reply', action: 'comment' },
    { token: 'retweet', action: 'share' },
    { token: 'unretweet', action: 'share' },
    { token: 'quote', action: 'share' },
    { token: 'share', action: 'share' },
    { token: 'like', action: 'like' },
    { token: 'unlike', action: 'like' },
    { token: 'userfollow', action: 'follow' },
    { token: 'userunfollow', action: 'follow' },
    { token: 'follow', action: 'follow' },
    { token: 'bookmark', action: 'save' },
    { token: 'removebookmark', action: 'save' },
    { token: 'dm', action: 'message' },
    { token: 'message', action: 'message' },
    { token: 'senddm', action: 'message' },
];
class SocialScanner extends _base_scanner__WEBPACK_IMPORTED_MODULE_0__.BaseScanner {
    category = 'social-action';
    scan(root) {
        const tools = [];
        const seen = new Set();
        const candidates = root.querySelectorAll([
            'button',
            '[role="button"]',
            'a[aria-label]',
            '[aria-label][tabindex]',
            '[data-testid*="like" i]',
            '[data-testid*="share" i]',
            '[data-testid*="retweet" i]',
            '[data-testid*="unretweet" i]',
            '[data-testid*="follow" i]',
            '[data-testid*="userfollow" i]',
            '[data-testid*="userunfollow" i]',
            '[data-testid*="comment" i]',
            '[data-testid*="reply" i]',
            '[data-testid*="message" i]',
            '[data-testid*="dm" i]',
            '[data-testid*="save" i]',
            '[data-testid*="bookmark" i]',
            '[data-icon="send"]',
            '[aria-label*="whatsapp" i]',
        ].join(', '));
        const platform = this.detectPlatform(location.hostname);
        for (const btn of candidates) {
            if (tools.length >= this.maxTools)
                break;
            if (this.isClaimed(btn))
                continue;
            if (!this.isVisible(btn))
                continue;
            if (!this.hasMeaningfulSize(btn))
                continue;
            if (btn.isContentEditable)
                continue;
            if (btn.getAttribute('role') === 'textbox')
                continue;
            const label = (btn.getAttribute('aria-label') || '').trim();
            const testId = this.resolveTestId(btn);
            const text = (btn.textContent || '').trim();
            const className = (btn.getAttribute('class') || '').toLowerCase();
            const href = (btn.getAttribute('href') || '').toLowerCase();
            const dataIcon = (btn.getAttribute('data-icon') || '').toLowerCase();
            if (!label && !testId && !text && !className && !href && !dataIcon)
                continue;
            // Classify by label or data-testid
            const actionType = this.classify({
                platform,
                label,
                text,
                testId,
                className,
                href,
                dataIcon,
            });
            if (!actionType)
                continue;
            // Build a short, clean slug
            const shortLabel = (label || text).slice(0, 48) || actionType;
            const slug = this.slugify(`${platform}-${shortLabel}`) || `${platform}-${actionType}`;
            const key = `${platform}-${actionType}-${slug}`;
            if (seen.has(key))
                continue;
            seen.add(key);
            this.claim(btn);
            tools.push(this.createTool(`social.${actionType}-${slug}`, `[${platform}] ${DESCRIPTIONS[actionType]}: ${shortLabel}`, btn, this.makeInputSchema([]), 0.86, {
                title: `[${platform}] ${TITLES[actionType]}: ${shortLabel}`,
                annotations: this.socialAnnotations(actionType),
            }));
        }
        return tools;
    }
    /** Classify a candidate element into a social action type */
    classify(ctx) {
        if (ctx.platform === 'x') {
            for (const rule of X_TESTID_RULES) {
                if (ctx.testId.includes(rule.token)) {
                    return rule.action;
                }
            }
        }
        const joined = [
            ctx.label,
            ctx.text,
            ctx.testId,
            ctx.className,
            ctx.href,
            ctx.dataIcon,
        ]
            .join(' ')
            .toLowerCase();
        if (LIKE_RE.test(joined) || joined.includes('heart') || joined.includes('reaction')) {
            return 'like';
        }
        if (SHARE_RE.test(joined) || joined.includes('retweet') || joined.includes('repost')) {
            return 'share';
        }
        if (FOLLOW_RE.test(joined) || joined.includes('subscribe')) {
            return 'follow';
        }
        if (COMMENT_RE.test(joined) || joined.includes('reply') || joined.includes('comment')) {
            return 'comment';
        }
        if (MESSAGE_RE.test(joined) ||
            joined.includes('data-icon="send"') ||
            joined.includes('direct message') ||
            joined.includes('dm')) {
            return 'message';
        }
        if (SAVE_RE.test(joined)) {
            return 'save';
        }
        if (JOIN_RE.test(joined)) {
            return 'join';
        }
        return null;
    }
    socialAnnotations(actionType) {
        return this.makeAnnotations({
            destructive: actionType !== 'comment' && actionType !== 'message',
            idempotent: actionType === 'comment' || actionType === 'message',
        });
    }
    detectPlatform(hostname) {
        const lower = hostname.toLowerCase();
        for (const row of PLATFORM_MAP) {
            if (row.re.test(lower))
                return row.name;
        }
        return 'social';
    }
    resolveTestId(el) {
        const own = el.getAttribute('data-testid');
        if (own)
            return own.toLowerCase();
        const closest = el.closest('[data-testid]');
        const closestTestId = closest?.getAttribute('data-testid');
        if (closestTestId)
            return closestTestId.toLowerCase();
        const child = el.querySelector('[data-testid]');
        const childTestId = child?.getAttribute('data-testid');
        if (childTestId)
            return childTestId.toLowerCase();
        return '';
    }
}


/***/ }),

/***/ "./src/content/spa-detector.ts":
/*!*************************************!*\
  !*** ./src/content/spa-detector.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initSpaDetection: () => (/* binding */ initSpaDetection)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/**
 * SPA navigation detection — patches History API and listens for
 * popstate events so the extension re-scans on client-side navigations.
 */

function initSpaDetection(callback) {
    let lastSpaUrl = location.href;
    let spaDebounce = null;
    function onSpaNavigation() {
        if (location.href === lastSpaUrl)
            return;
        lastSpaUrl = location.href;
        if (spaDebounce)
            clearTimeout(spaDebounce);
        spaDebounce = setTimeout(() => {
            console.debug('[WebMCP] SPA navigation detected →', location.href);
            callback();
        }, _utils_constants__WEBPACK_IMPORTED_MODULE_0__.SPA_NAVIGATION_DEBOUNCE_MS);
    }
    // Safely patch pushState/replaceState — guard against pages that override these
    try {
        const origPushState = history.pushState.bind(history);
        history.pushState = function (...args) {
            origPushState(...args);
            onSpaNavigation();
        };
        const origReplaceState = history.replaceState.bind(history);
        history.replaceState = function (...args) {
            origReplaceState(...args);
            onSpaNavigation();
        };
    }
    catch (e) {
        console.warn('[WebMCP] Could not patch history API:', e);
    }
    window.addEventListener('popstate', onSpaNavigation);
}


/***/ }),

/***/ "./src/content/tool-registry.ts":
/*!**************************************!*\
  !*** ./src/content/tool-registry.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolRegistry: () => (/* binding */ ToolRegistry)
/* harmony export */ });
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/constants */ "./src/utils/constants.ts");
/* harmony import */ var _scanners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scanners */ "./src/content/scanners/index.ts");
/* harmony import */ var _executors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./executors */ "./src/content/executors/index.ts");
/* harmony import */ var _merge__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./merge */ "./src/content/merge.ts");
/* harmony import */ var _ai_classifier__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ai-classifier */ "./src/content/ai-classifier.ts");
/* harmony import */ var _adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../adapters/indexeddb-tool-cache-adapter */ "./src/adapters/indexeddb-tool-cache-adapter.ts");
/**
 * ToolRegistry — owns scanner/executor registries, 3-tier tool
 * discovery, schema enrichment, DOM observation, and result caching.
 *
 * Supports an optional IToolCachePort for persistent cross-session
 * caching of tool manifests per site (WebMCP cache layer).
 */






const SCANNER_CACHE_TTL_MS = 2000;
class ToolRegistry {
    scannerRegistry = new _scanners__WEBPACK_IMPORTED_MODULE_1__.ScannerRegistry();
    executorRegistry = new _executors__WEBPACK_IMPORTED_MODULE_2__.ExecutorRegistry();
    aiClassifier = new _ai_classifier__WEBPACK_IMPORTED_MODULE_4__.AIClassifier();
    /** Inferred tools keyed by name — used for execution routing */
    inferredToolsMap = new Map();
    // DOM observer state
    domObserver = null;
    domObserverDebounce = null;
    // Scanner result cache (in-memory, 2s TTL)
    scannerCacheTime = 0;
    scannerCacheResult = null;
    /** Optional persistent tool cache (IndexedDB) */
    toolCache = null;
    /** Optional tool manifest for MCP JSON export */
    toolManifest = null;
    /** Track if a background diff is already running to avoid duplicates */
    diffInProgress = false;
    /** Callback invoked after manifest updates */
    manifestUpdateCallback = null;
    /** Optional persistent manifest storage (IndexedDB) */
    manifestPersistence = null;
    constructor() {
        void this.aiClassifier;
    }
    /** Inject a persistent tool cache adapter. */
    setToolCache(cache) {
        this.toolCache = cache;
    }
    /** Inject a tool manifest adapter. */
    setToolManifest(manifest) {
        this.toolManifest = manifest;
    }
    /** Inject a manifest persistence adapter. */
    setManifestPersistence(persistence) {
        this.manifestPersistence = persistence;
    }
    /** Get the tool manifest port (for message handler access). */
    getToolManifest() {
        return this.toolManifest;
    }
    /** Register a callback invoked after each manifest update. */
    onManifestUpdate(callback) {
        this.manifestUpdateCallback = callback;
    }
    /**
     * Load persisted manifest into the in-memory adapter on startup.
     * Call after setToolManifest and setManifestPersistence.
     */
    async loadPersistedManifest() {
        if (!this.manifestPersistence || !this.toolManifest)
            return;
        const site = (0,_adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_5__.extractSite)(location.href);
        try {
            const persisted = await this.manifestPersistence.load(site);
            if (persisted) {
                // Replay each page into the in-memory manifest adapter
                for (const [, page] of Object.entries(persisted.pages)) {
                    const pageTools = persisted.tools.filter(t => page.tools.includes(t.name));
                    const asClean = pageTools.map(t => ({
                        name: t.name,
                        description: t.description,
                        inputSchema: t.inputSchema,
                        category: t.category,
                        annotations: t.annotations,
                        _source: 'manifest',
                    }));
                    // Use a synthetic URL from the pattern to restore state
                    this.toolManifest.updatePage(site, `https://${site}${page.urlPattern}`, asClean);
                }
                this.manifestUpdateCallback?.();
                console.debug(`[WebMCP] Restored persisted manifest for ${site}`);
            }
        }
        catch (e) {
            console.warn('[WebMCP] Failed to load persisted manifest:', e);
        }
    }
    /** Update manifest and persist in background. */
    updateManifestAndPersist(site, url, tools) {
        if (!this.toolManifest)
            return;
        const manifest = this.toolManifest.updatePage(site, url, tools);
        this.manifestUpdateCallback?.();
        if (this.manifestPersistence) {
            this.manifestPersistence.save(site, manifest).catch(e => {
                console.warn('[WebMCP] Manifest persistence save failed:', e);
            });
        }
    }
    // ── Public API ──
    invalidateCache() {
        this.scannerCacheResult = null;
    }
    async listToolsAlwaysAugment() {
        const currentUrl = location.href;
        const site = (0,_adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_5__.extractSite)(currentUrl);
        // ── Fast path: persistent cache hit ──
        if (this.toolCache) {
            try {
                const cached = await this.toolCache.get(site, currentUrl);
                if (cached && cached.length > 0) {
                    console.debug(`[WebMCP] Cache hit for ${site} (${cached.length} tools)`);
                    // Populate inferredToolsMap so tool execution routing works
                    // before background diff completes. Inferred tools need DOM
                    // elements for execution, so trigger a background diff that
                    // will run fullScan() and re-populate with live DOM refs.
                    this.inferredToolsMap.clear();
                    for (const t of cached) {
                        if (t._source === 'inferred') {
                            this.inferredToolsMap.set(t.name, t);
                        }
                    }
                    chrome.runtime.sendMessage({ tools: cached, url: currentUrl });
                    // Update manifest with cached tools
                    this.updateManifestAndPersist(site, currentUrl, cached);
                    this.scheduleBackgroundDiff(site, currentUrl);
                    return cached;
                }
            }
            catch (e) {
                console.warn('[WebMCP] Cache read failed, falling back to scan:', e);
            }
        }
        // ── Full scan path ──
        let nativeTools = [];
        let declarativeTools = [];
        let inferredTools = [];
        // Tier 1: WMCP Native API
        if (navigator.modelContextTesting) {
            try {
                const raw = navigator.modelContextTesting.listTools() || [];
                nativeTools = this.enrichToolSchemas(raw);
            }
            catch (e) {
                console.warn('[WebMCP] Native API failed:', e);
            }
        }
        // Tier 2: Declarative HTML (form[toolname])
        const declForms = document.querySelectorAll('form[toolname]');
        if (declForms.length > 0) {
            declarativeTools = [...declForms].map((f) => {
                const form = f;
                return {
                    name: form.getAttribute('toolname') ?? '',
                    description: form.getAttribute('tooldescription') ?? '',
                    inputSchema: ToolRegistry.extractFormSchema(form),
                };
            });
            declarativeTools = this.enrichToolSchemas(declarativeTools);
        }
        // Tier 3: Auto-Inference — use cache if fresh
        const now = Date.now();
        if (this.scannerCacheResult && (now - this.scannerCacheTime) < SCANNER_CACHE_TTL_MS) {
            inferredTools = this.scannerCacheResult;
            console.debug('[WebMCP] Using cached scanner results');
        }
        else {
            try {
                const scanStart = performance.now();
                inferredTools = this.scannerRegistry.scanAll();
                const scanMs = (performance.now() - scanStart).toFixed(1);
                console.debug(`[WebMCP] Scanner scan completed in ${scanMs}ms (${inferredTools.length} tools)`);
                this.scannerCacheResult = inferredTools;
                this.scannerCacheTime = now;
            }
            catch (e) {
                console.warn('[WebMCP] Inference scan failed:', e);
            }
        }
        // Store inferred tools for execution routing
        this.inferredToolsMap.clear();
        for (const t of inferredTools) {
            this.inferredToolsMap.set(t.name, t);
        }
        // Union merge (native wins on name collision)
        let tools = (0,_merge__WEBPACK_IMPORTED_MODULE_3__.mergeToolSets)(nativeTools, declarativeTools, inferredTools);
        // Post-merge cleanup: deduplicate by name (keep highest confidence),
        // filter out low-confidence tools, sort by category
        const dedupMap = new Map();
        for (const tool of tools) {
            const existing = dedupMap.get(tool.name);
            if (!existing || (tool.confidence ?? 0) > (existing.confidence ?? 0)) {
                dedupMap.set(tool.name, tool);
            }
        }
        tools = [...dedupMap.values()]
            .filter((t) => (t.confidence ?? 1) >= 0.3)
            .sort((a, b) => (a.category ?? '').localeCompare(b.category ?? ''));
        // Strip internal properties before sending to sidebar
        const cleanTools = tools.map(({ _el, _form, _schemaAction, ...rest }) => rest);
        const sources = {
            native: cleanTools.filter((t) => t._source === 'native').length,
            declarative: cleanTools.filter((t) => t._source === 'declarative')
                .length,
            inferred: cleanTools.filter((t) => t._source === 'inferred').length,
            manifest: cleanTools.filter((t) => t._source === 'manifest').length,
        };
        console.debug(`[WebMCP] ${cleanTools.length} tools (${sources.native}N + ${sources.declarative}D + ${sources.inferred}I + ${sources.manifest}M)`, cleanTools);
        chrome.runtime.sendMessage({ tools: cleanTools, url: location.href });
        // ── Persist to cache in background ──
        if (this.toolCache) {
            this.toolCache.put(site, currentUrl, cleanTools).catch((e) => {
                console.warn('[WebMCP] Cache write failed:', e);
            });
        }
        // ── Update tool manifest ──
        this.updateManifestAndPersist(site, currentUrl, cleanTools);
        return cleanTools;
    }
    // ── Background Diff ──
    /**
     * Schedules a background diff: scans DOM and compares with cached tools.
     * If differences found, updates the cache and broadcasts updated tools.
     */
    scheduleBackgroundDiff(site, url) {
        if (this.diffInProgress || !this.toolCache)
            return;
        this.diffInProgress = true;
        queueMicrotask(async () => {
            try {
                const liveTools = await this.fullScan();
                const diff = await this.toolCache.diff(site, url, liveTools);
                const hasChanges = diff.added.length > 0 || diff.removed.length > 0 || diff.changed.length > 0;
                if (hasChanges) {
                    console.debug(`[WebMCP] Diff: +${diff.added.length} -${diff.removed.length} ~${diff.changed.length} =${diff.unchanged}`);
                    await this.toolCache.applyDiff(site, url, diff);
                    chrome.runtime.sendMessage({ tools: liveTools, url });
                    // Update manifest with live tools after diff
                    this.updateManifestAndPersist(site, url, liveTools);
                }
            }
            catch (e) {
                console.warn('[WebMCP] Background diff failed:', e);
            }
            finally {
                this.diffInProgress = false;
            }
        });
    }
    /** Run full 3-tier scan and return clean tools (no caching side effects). */
    fullScan() {
        let nativeTools = [];
        let declarativeTools = [];
        let inferredTools = [];
        if (navigator.modelContextTesting) {
            try {
                const raw = navigator.modelContextTesting.listTools() || [];
                nativeTools = this.enrichToolSchemas(raw);
            }
            catch { /* ignore */ }
        }
        const declForms = document.querySelectorAll('form[toolname]');
        if (declForms.length > 0) {
            declarativeTools = [...declForms].map((f) => {
                const form = f;
                return {
                    name: form.getAttribute('toolname') ?? '',
                    description: form.getAttribute('tooldescription') ?? '',
                    inputSchema: ToolRegistry.extractFormSchema(form),
                };
            });
            declarativeTools = this.enrichToolSchemas(declarativeTools);
        }
        inferredTools = this.scannerRegistry.scanAll();
        this.inferredToolsMap.clear();
        for (const t of inferredTools)
            this.inferredToolsMap.set(t.name, t);
        let tools = (0,_merge__WEBPACK_IMPORTED_MODULE_3__.mergeToolSets)(nativeTools, declarativeTools, inferredTools);
        const dedupMap = new Map();
        for (const tool of tools) {
            const existing = dedupMap.get(tool.name);
            if (!existing || (tool.confidence ?? 0) > (existing.confidence ?? 0)) {
                dedupMap.set(tool.name, tool);
            }
        }
        tools = [...dedupMap.values()]
            .filter((t) => (t.confidence ?? 1) >= 0.3)
            .sort((a, b) => (a.category ?? '').localeCompare(b.category ?? ''));
        return tools.map(({ _el, _form, _schemaAction, ...rest }) => rest);
    }
    // ── DOM Observer ──
    startDomObserver() {
        if (this.domObserver)
            return;
        this.domObserver = new MutationObserver((mutations) => {
            const relevant = mutations.some((m) => {
                for (const node of [...m.addedNodes, ...m.removedNodes]) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const el = node;
                        if (el.matches?.('form[toolname]') ||
                            el.querySelector?.('form[toolname]'))
                            return true;
                        if (el.matches?.('[contenteditable="true"]') ||
                            el.querySelector?.('[contenteditable="true"]'))
                            return true;
                        if (el.matches?.('[role="textbox"]') ||
                            el.querySelector?.('[role="textbox"]'))
                            return true;
                        if (el.matches?.('input[type="file"]') ||
                            el.querySelector?.('input[type="file"]'))
                            return true;
                        if (el.matches?.('[aria-label*="like" i], [aria-label*="share" i], [aria-label*="follow" i]'))
                            return true;
                    }
                }
                if (m.type === 'attributes' &&
                    m.target.closest?.('form[toolname]'))
                    return true;
                if (m.type === 'attributes' &&
                    (m.attributeName === 'contenteditable' ||
                        m.attributeName === 'role'))
                    return true;
                if (m.type === 'characterData' &&
                    m.target.parentElement?.closest?.('form[toolname]'))
                    return true;
                return false;
            });
            if (relevant) {
                if (this.domObserverDebounce)
                    clearTimeout(this.domObserverDebounce);
                this.domObserverDebounce = setTimeout(() => {
                    console.debug('[WebMCP] DOM change detected, refreshing tools...');
                    this.listToolsAlwaysAugment();
                }, _utils_constants__WEBPACK_IMPORTED_MODULE_0__.DOM_OBSERVER_DEBOUNCE_MS);
            }
        });
        this.domObserver.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            characterData: true,
            attributeFilter: [
                'toolname',
                'tooldescription',
                'name',
                'value',
                'type',
            ],
        });
        console.debug('[WebMCP] DOM observer initialized');
    }
    stopDomObserver() {
        if (this.domObserver) {
            this.domObserver.disconnect();
            this.domObserver = null;
        }
        if (this.domObserverDebounce)
            clearTimeout(this.domObserverDebounce);
    }
    // ── Tool argument normalisation ──
    normalizeToolArgs(toolName, inputArgs) {
        try {
            const args = typeof inputArgs === 'string' ? JSON.parse(inputArgs) : inputArgs;
            const form = document.querySelector(`form[toolname="${CSS.escape(toolName)}"]`);
            if (!form)
                return typeof inputArgs === 'string'
                    ? inputArgs
                    : JSON.stringify(inputArgs);
            const normalized = { ...args };
            for (const [key, value] of Object.entries(normalized)) {
                if (typeof value !== 'string')
                    continue;
                const select = form.querySelector(`select[name="${CSS.escape(key)}"]`);
                if (select) {
                    const match = [...select.options].find((opt) => opt.value.toLowerCase() === value.toLowerCase());
                    if (match) {
                        normalized[key] = match.value;
                        continue;
                    }
                }
                const radios = form.querySelectorAll(`input[type="radio"][name="${CSS.escape(key)}"]`);
                if (radios.length > 0) {
                    const match = [...radios].find((r) => r.value.toLowerCase() === value.toLowerCase());
                    if (match) {
                        normalized[key] = match.value;
                        continue;
                    }
                }
            }
            return JSON.stringify(normalized);
        }
        catch (e) {
            console.warn('[WebMCP] Normalization failed, using original args:', e);
            return typeof inputArgs === 'string'
                ? inputArgs
                : JSON.stringify(inputArgs);
        }
    }
    // ── Private helpers ──
    enrichToolSchemas(tools) {
        return tools.map((tool) => {
            const form = document.querySelector(`form[toolname="${CSS.escape(tool.name)}"]`);
            if (!form || !tool.inputSchema)
                return tool;
            let schema;
            try {
                schema =
                    typeof tool.inputSchema === 'string'
                        ? JSON.parse(tool.inputSchema)
                        : tool.inputSchema;
            }
            catch {
                return tool;
            }
            if (!schema.properties)
                return tool;
            const mutableProps = {
                ...schema.properties,
            };
            for (const [propName, propDef] of Object.entries(mutableProps)) {
                const select = form.querySelector(`select[name="${CSS.escape(propName)}"]`);
                if (select) {
                    const vals = [...select.options]
                        .map((o) => o.value)
                        .filter(Boolean);
                    if (vals.length) {
                        mutableProps[propName] = { ...propDef, enum: vals };
                    }
                    continue;
                }
                const radios = form.querySelectorAll(`input[type="radio"][name="${CSS.escape(propName)}"]`);
                if (radios.length) {
                    const vals = [...radios].map((r) => r.value).filter(Boolean);
                    mutableProps[propName] = { ...propDef, enum: vals };
                }
            }
            const enrichedSchema = {
                ...schema,
                properties: mutableProps,
            };
            return {
                ...tool,
                inputSchema: JSON.stringify(enrichedSchema),
            };
        });
    }
    static extractFormSchema(form) {
        const props = {};
        const required = [];
        for (const inp of form.querySelectorAll('input, select, textarea')) {
            if (inp.type === 'hidden' ||
                inp.type === 'submit')
                continue;
            const name = inp.name || inp.id;
            if (!name)
                continue;
            const prop = {
                type: inp.type === 'number' ? 'number' : 'string',
            };
            if (inp.tagName === 'SELECT') {
                const selectEl = inp;
                const enumVals = [...selectEl.options]
                    .map((o) => o.value)
                    .filter(Boolean);
                if (enumVals.length) {
                    props[name] = { ...prop, enum: enumVals };
                }
                else {
                    props[name] = prop;
                }
            }
            else {
                props[name] = prop;
            }
            if (inp.required)
                required.push(name);
        }
        return JSON.stringify({
            type: 'object',
            properties: props,
            ...(required.length ? { required } : {}),
        });
    }
}


/***/ }),

/***/ "./src/content/wmcp-server.ts":
/*!************************************!*\
  !*** ./src/content/wmcp-server.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WmcpServer: () => (/* binding */ WmcpServer)
/* harmony export */ });
/**
 * WmcpServer — IWmcpServerPort implementation via DOM injection.
 *
 * Exposes the MCP manifest to external tools by:
 * 1. Injecting a <script type="application/wmcp+json" id="wmcp-manifest"> element
 * 2. Listening for CustomEvent('wmcp-request') and responding with
 *    CustomEvent('wmcp-response') containing the manifest JSON
 */
const ELEMENT_ID = 'wmcp-manifest';
const ELEMENT_TYPE = 'application/wmcp+json';
const REQUEST_EVENT = 'wmcp-request';
const RESPONSE_EVENT = 'wmcp-response';
class WmcpServer {
    scriptEl = null;
    requestListener = null;
    exposeManifest(json) {
        if (!this.scriptEl) {
            this.scriptEl = document.createElement('script');
            this.scriptEl.type = ELEMENT_TYPE;
            this.scriptEl.id = ELEMENT_ID;
            document.head.appendChild(this.scriptEl);
        }
        this.scriptEl.textContent = json;
    }
    onRequest(handler) {
        // Remove previous listener if any
        if (this.requestListener) {
            document.removeEventListener(REQUEST_EVENT, this.requestListener);
        }
        this.requestListener = (e) => {
            const url = e.detail?.url ?? '';
            const response = handler(url);
            document.dispatchEvent(new CustomEvent(RESPONSE_EVENT, { detail: { manifest: response } }));
        };
        document.addEventListener(REQUEST_EVENT, this.requestListener);
    }
    dispose() {
        if (this.scriptEl) {
            this.scriptEl.remove();
            this.scriptEl = null;
        }
        if (this.requestListener) {
            document.removeEventListener(REQUEST_EVENT, this.requestListener);
            this.requestListener = null;
        }
    }
}


/***/ }),

/***/ "./src/utils/constants.ts":
/*!********************************!*\
  !*** ./src/utils/constants.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AI_CLASSIFIER_CONFIG: () => (/* binding */ AI_CLASSIFIER_CONFIG),
/* harmony export */   AI_CLASSIFIER_TITLE: () => (/* binding */ AI_CLASSIFIER_TITLE),
/* harmony export */   AI_CONFIDENCE_THRESHOLD: () => (/* binding */ AI_CONFIDENCE_THRESHOLD),
/* harmony export */   AI_MAX_RETRIES: () => (/* binding */ AI_MAX_RETRIES),
/* harmony export */   AI_RETRY_DELAY_MS: () => (/* binding */ AI_RETRY_DELAY_MS),
/* harmony export */   CONTENT_SCRIPTS: () => (/* binding */ CONTENT_SCRIPTS),
/* harmony export */   DEFAULT_CLASSIFIER_MODEL: () => (/* binding */ DEFAULT_CLASSIFIER_MODEL),
/* harmony export */   DEFAULT_MODEL: () => (/* binding */ DEFAULT_MODEL),
/* harmony export */   DOM_OBSERVER_DEBOUNCE_MS: () => (/* binding */ DOM_OBSERVER_DEBOUNCE_MS),
/* harmony export */   INFERENCE_CACHE_TTL: () => (/* binding */ INFERENCE_CACHE_TTL),
/* harmony export */   MAX_PAGE_CONTEXT_PRODUCTS: () => (/* binding */ MAX_PAGE_CONTEXT_PRODUCTS),
/* harmony export */   MAX_TOOLS_PER_CATEGORY: () => (/* binding */ MAX_TOOLS_PER_CATEGORY),
/* harmony export */   MIN_CONFIDENCE: () => (/* binding */ MIN_CONFIDENCE),
/* harmony export */   OPENROUTER_BASE_URL: () => (/* binding */ OPENROUTER_BASE_URL),
/* harmony export */   OPENROUTER_CHAT_ENDPOINT: () => (/* binding */ OPENROUTER_CHAT_ENDPOINT),
/* harmony export */   OPENROUTER_DEFAULT_MAX_INPUT_TOKENS: () => (/* binding */ OPENROUTER_DEFAULT_MAX_INPUT_TOKENS),
/* harmony export */   OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS: () => (/* binding */ OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS),
/* harmony export */   OPENROUTER_MAX_HISTORY_MESSAGES: () => (/* binding */ OPENROUTER_MAX_HISTORY_MESSAGES),
/* harmony export */   OPENROUTER_MODELS_ENDPOINT: () => (/* binding */ OPENROUTER_MODELS_ENDPOINT),
/* harmony export */   OPENROUTER_REFERER: () => (/* binding */ OPENROUTER_REFERER),
/* harmony export */   OPENROUTER_TITLE: () => (/* binding */ OPENROUTER_TITLE),
/* harmony export */   SCANNER_CATEGORIES: () => (/* binding */ SCANNER_CATEGORIES),
/* harmony export */   SECURITY_TIERS: () => (/* binding */ SECURITY_TIERS),
/* harmony export */   SHADOW_DOM_MAX_DEPTH: () => (/* binding */ SHADOW_DOM_MAX_DEPTH),
/* harmony export */   SPA_NAVIGATION_DEBOUNCE_MS: () => (/* binding */ SPA_NAVIGATION_DEBOUNCE_MS),
/* harmony export */   STORAGE_KEY_API_KEY: () => (/* binding */ STORAGE_KEY_API_KEY),
/* harmony export */   STORAGE_KEY_CONVERSATIONS: () => (/* binding */ STORAGE_KEY_CONVERSATIONS),
/* harmony export */   STORAGE_KEY_LOCK_MODE: () => (/* binding */ STORAGE_KEY_LOCK_MODE),
/* harmony export */   STORAGE_KEY_MODEL: () => (/* binding */ STORAGE_KEY_MODEL),
/* harmony export */   STORAGE_KEY_ORCHESTRATOR_MODE: () => (/* binding */ STORAGE_KEY_ORCHESTRATOR_MODE),
/* harmony export */   STORAGE_KEY_PLAN_MODE: () => (/* binding */ STORAGE_KEY_PLAN_MODE),
/* harmony export */   STORAGE_KEY_SCREENSHOT_ENABLED: () => (/* binding */ STORAGE_KEY_SCREENSHOT_ENABLED),
/* harmony export */   STORAGE_KEY_YOLO_MODE: () => (/* binding */ STORAGE_KEY_YOLO_MODE),
/* harmony export */   SecurityTierLevel: () => (/* binding */ SecurityTierLevel)
/* harmony export */ });
/**
 * Constants extracted from the JS source files.
 * Single source of truth for magic numbers, strings, and configuration.
 */
// ── Inference Engine ──
/** Maximum number of tools a single category scanner can emit */
const MAX_TOOLS_PER_CATEGORY = 15;
/** Inference cache TTL in milliseconds (30 seconds) */
const INFERENCE_CACHE_TTL = 30_000;
/** Confidence threshold: below this tools are sent to AI classifier */
const AI_CONFIDENCE_THRESHOLD = 0.7;
/** Minimum confidence: below this tools are discarded entirely */
const MIN_CONFIDENCE = 0.5;
// ── Security Tiers ──
/** Security tier metadata definitions */
const SECURITY_TIERS = {
    0: { label: 'Safe', autoExecute: true },
    1: { label: 'Navigation', autoExecute: true },
    2: { label: 'Mutation', autoExecute: false },
};
/** Security tier enum values for convenience */
const SecurityTierLevel = {
    SAFE: 0,
    NAVIGATION: 1,
    MUTATION: 2,
};
// ── Scanner Categories ──
/** All 13 scanner categories in priority order (specialized before generic) */
const SCANNER_CATEGORIES = [
    'form',
    'navigation',
    'search',
    'richtext',
    'social-action',
    'file-upload',
    'interactive',
    'media',
    'ecommerce',
    'auth',
    'page-state',
    'schema-org',
    'chatbot',
];
// ── AI Classifier ──
/** Default AI classifier configuration */
const AI_CLASSIFIER_CONFIG = {
    confidenceThreshold: 0.65,
    batchSize: 15,
    model: 'google/gemini-2.0-flash-lite-001',
    cacheTTL: 5 * 60 * 1000, // 5 minutes
};
// ── OpenRouter API ──
/** OpenRouter API base URL */
const OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';
/** OpenRouter chat completions endpoint */
const OPENROUTER_CHAT_ENDPOINT = `${OPENROUTER_BASE_URL}/chat/completions`;
/** OpenRouter models list endpoint */
const OPENROUTER_MODELS_ENDPOINT = `${OPENROUTER_BASE_URL}/models`;
/** Default model for chat interactions */
const DEFAULT_MODEL = 'google/gemini-2.0-flash-001';
/** Default model for AI classifier (lightweight) */
const DEFAULT_CLASSIFIER_MODEL = 'google/gemini-2.0-flash-lite-001';
/** Default max output tokens for chat completions */
const OPENROUTER_DEFAULT_MAX_OUTPUT_TOKENS = 65_000;
/** Internal input budget cap used for local history trimming */
const OPENROUTER_DEFAULT_MAX_INPUT_TOKENS = 1_000_000;
/** Max retained messages in chat history before additional input-budget trimming */
const OPENROUTER_MAX_HISTORY_MESSAGES = 200;
// ── Storage Keys ──
/** localStorage key for conversation data */
const STORAGE_KEY_CONVERSATIONS = 'wmcp_conversations';
/** localStorage key for lock mode state */
const STORAGE_KEY_LOCK_MODE = 'wmcp_lock_mode';
/** localStorage key for OpenRouter API key */
const STORAGE_KEY_API_KEY = 'openrouter_api_key';
/** localStorage key for selected model */
const STORAGE_KEY_MODEL = 'openrouter_model';
/** Storage key for screenshot toggle */
const STORAGE_KEY_SCREENSHOT_ENABLED = 'wmcp_screenshot_enabled';
/** Storage key for plan mode toggle */
const STORAGE_KEY_PLAN_MODE = 'wmcp_plan_mode';
/** Key for YOLO mode (auto-execute all tools without confirmation) */
const STORAGE_KEY_YOLO_MODE = 'wmcp_yolo_mode';
/** Key for orchestrator mode (use hexagonal AgentOrchestrator instead of legacy tool-loop) */
const STORAGE_KEY_ORCHESTRATOR_MODE = 'wmcp_orchestrator_mode';
// ── Timing ──
/** Debounce delay for DOM mutation observer (ms) */
const DOM_OBSERVER_DEBOUNCE_MS = 300;
/** Debounce delay for SPA navigation detection (ms) */
const SPA_NAVIGATION_DEBOUNCE_MS = 500;
/** Max retry attempts for empty AI responses */
const AI_MAX_RETRIES = 3;
/** Delay between AI retry attempts (ms) */
const AI_RETRY_DELAY_MS = 1000;
// ── HTTP Headers ──
/** HTTP-Referer header for OpenRouter requests */
const OPENROUTER_REFERER = 'https://github.com/miguelspizza/webmcp';
/** X-Title header for OpenRouter requests */
const OPENROUTER_TITLE = 'Model Context Tool Inspector (OpenRouter)';
/** X-Title header for AI classifier requests */
const AI_CLASSIFIER_TITLE = 'WMCP AI Classifier';
// ── Content Script ──
/** Content scripts injected on install (bundled into single file by webpack) */
const CONTENT_SCRIPTS = [
    'content.js',
];
/** Max products to extract from page context */
const MAX_PAGE_CONTEXT_PRODUCTS = 20;
/** Shadow DOM max traversal depth */
const SHADOW_DOM_MAX_DEPTH = 5;


/***/ }),

/***/ "./src/utils/dom.ts":
/*!**************************!*\
  !*** ./src/utils/dom.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getFormValues: () => (/* binding */ getFormValues),
/* harmony export */   getLabel: () => (/* binding */ getLabel),
/* harmony export */   isVisible: () => (/* binding */ isVisible),
/* harmony export */   querySelectorDeep: () => (/* binding */ querySelectorDeep),
/* harmony export */   slugify: () => (/* binding */ slugify)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./src/utils/constants.ts");
/**
 * DOM utility functions extracted from content.js and wmcp-inference-engine.js.
 */

/** Check if an element is visible (not display:none, visibility:hidden, or opacity:0) */
function isVisible(el) {
    const htmlEl = el;
    if (!htmlEl.offsetParent && htmlEl.style?.display !== 'fixed')
        return false;
    const style = getComputedStyle(el);
    return (style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        style.opacity !== '0');
}
/**
 * Get an accessible label for an element.
 * Checks: aria-label → aria-labelledby → label[for] → title → placeholder →
 * data-placeholder → short textContent.
 */
function getLabel(el) {
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel)
        return ariaLabel.trim();
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
        const ref = document.getElementById(labelledBy);
        if (ref)
            return ref.textContent?.trim() ?? '';
    }
    if (el.id) {
        const lbl = document.querySelector(`label[for="${el.id}"]`);
        if (lbl)
            return lbl.textContent?.trim() ?? '';
    }
    const htmlEl = el;
    if (htmlEl.title)
        return htmlEl.title.trim();
    const inputEl = el;
    if (inputEl.placeholder)
        return inputEl.placeholder.trim();
    const dataset = el.dataset;
    if (dataset?.placeholder)
        return dataset.placeholder.trim();
    const txt = el.textContent?.trim();
    if (txt && txt.length < 60 && !txt.includes('\n'))
        return txt;
    return '';
}
/** Convert text to a URL/tool-name-safe slug (max 64 chars) */
function slugify(text) {
    return (text || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 64);
}
/**
 * Traverse shadow DOM boundaries to query elements.
 * Searches up to `maxDepth` shadow roots deep.
 */
function querySelectorDeep(root, selector, maxDepth = _constants__WEBPACK_IMPORTED_MODULE_0__.SHADOW_DOM_MAX_DEPTH) {
    const results = [];
    function walk(node, depth) {
        const matches = node.querySelectorAll(selector);
        for (const el of matches) {
            results.push(el);
        }
        if (depth >= maxDepth)
            return;
        const allElements = node.querySelectorAll('*');
        for (const el of allElements) {
            if (el.shadowRoot) {
                walk(el.shadowRoot, depth + 1);
            }
        }
    }
    walk(root, 0);
    return results;
}
/**
 * Extract all form field name/value pairs from a form element.
 * Uses FormData for standard form serialization.
 * Password values are masked for security.
 */
function getFormValues(form) {
    const passwordFields = new Set();
    form.querySelectorAll('input[type="password"]').forEach(el => {
        const name = el.name;
        if (name)
            passwordFields.add(name);
    });
    const result = {};
    for (const [key, val] of new FormData(form).entries()) {
        result[key] = passwordFields.has(key) && val ? '••••' : String(val);
    }
    return result;
}


/***/ }),

/***/ "../onecrawl/dist/chunk-7CKWZJNS.js":
/*!******************************************!*\
  !*** ../onecrawl/dist/chunk-7CKWZJNS.js ***!
  \******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SemanticScrapingAdapter: () => (/* binding */ SemanticScrapingAdapter),
/* harmony export */   hashTools: () => (/* binding */ hashTools),
/* harmony export */   urlToPattern: () => (/* binding */ urlToPattern)
/* harmony export */ });
// src/adapters/semantic-scraping/semantic-scraping.adapter.ts
function urlToPattern(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.replace(/\/+$/, "") || "/";
    if (!u.search) return path;
    const params = new URLSearchParams(u.search);
    const wildcarded = [...params.keys()].sort().map((k) => `${k}=*`);
    return `${path}?${wildcarded.join("&")}`;
  } catch {
    return url;
  }
}
function hashTools(tools) {
  const keys = tools.map(
    (t) => `${t.name}:${t.description ?? ""}:${JSON.stringify(t.inputSchema ?? {})}`
  ).sort();
  let h = 0;
  const s = keys.join("|");
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i) | 0;
  }
  return h.toString(36);
}
function parseSchema(schema) {
  if (typeof schema === "string") {
    try {
      return JSON.parse(schema);
    } catch {
      return { type: "object", properties: {} };
    }
  }
  return schema;
}
function toManifestTool(tool, pattern) {
  const schema = parseSchema(tool.inputSchema);
  const annotations = tool.annotations ? { ...tool.annotations } : void 0;
  return {
    name: tool.name,
    description: tool.description,
    inputSchema: schema,
    category: tool.category,
    annotations,
    pagePatterns: [pattern]
  };
}
function rebuildTools(pages, toolsByName) {
  const consolidated = /* @__PURE__ */ new Map();
  for (const [, entry] of toolsByName) {
    const existing = consolidated.get(entry.tool.name);
    if (existing) {
      for (const p of entry.patterns) existing.patterns.add(p);
    } else {
      consolidated.set(entry.tool.name, {
        tool: entry.tool,
        patterns: new Set(entry.patterns)
      });
    }
  }
  const activeToolNames = /* @__PURE__ */ new Set();
  for (const page of Object.values(pages)) {
    for (const name of page.tools) activeToolNames.add(name);
  }
  const result = [];
  for (const [name, entry] of consolidated) {
    if (!activeToolNames.has(name)) continue;
    result.push({
      ...entry.tool,
      pagePatterns: [...entry.patterns].sort()
    });
  }
  return result.sort((a, b) => a.name.localeCompare(b.name));
}
var SemanticScrapingAdapter = class {
  manifests = /* @__PURE__ */ new Map();
  getManifest(origin) {
    return this.manifests.get(origin)?.manifest ?? null;
  }
  updatePage(origin, url, tools) {
    const pattern = urlToPattern(url);
    const hash = hashTools(
      tools.map((t) => ({
        ...t,
        inputSchema: parseSchema(t.inputSchema)
      }))
    );
    const now = Date.now();
    const existing = this.manifests.get(origin);
    const toolIndex = existing?.toolIndex ?? /* @__PURE__ */ new Map();
    const oldPages = existing?.manifest.pages ?? {};
    const oldPage = oldPages[pattern];
    if (oldPage) {
      for (const toolName of oldPage.tools) {
        const entry = toolIndex.get(toolName);
        if (entry) {
          entry.patterns.delete(pattern);
          if (entry.patterns.size === 0) toolIndex.delete(toolName);
        }
      }
    }
    const toolNames = [];
    for (const tool of tools) {
      toolNames.push(tool.name);
      const entry = toolIndex.get(tool.name);
      if (entry) {
        entry.patterns.add(pattern);
        entry.tool = toManifestTool(tool, pattern);
      } else {
        toolIndex.set(tool.name, {
          tool: toManifestTool(tool, pattern),
          patterns: /* @__PURE__ */ new Set([pattern])
        });
      }
    }
    const pageToolSet = {
      urlPattern: pattern,
      tools: toolNames,
      lastScanned: now,
      hash
    };
    const pages = {
      ...oldPages,
      [pattern]: pageToolSet
    };
    const deduped = rebuildTools(pages, toolIndex);
    const manifest = {
      origin,
      version: (existing?.manifest.version ?? 0) + 1,
      generatedAt: now,
      pages,
      tools: deduped
    };
    this.manifests.set(origin, { manifest, toolIndex });
    return manifest;
  }
  applyDiff(origin, url, added, removed) {
    const pattern = urlToPattern(url);
    const now = Date.now();
    const existing = this.manifests.get(origin);
    const toolIndex = existing?.toolIndex ?? /* @__PURE__ */ new Map();
    const oldPages = existing?.manifest.pages ?? {};
    const oldPage = oldPages[pattern];
    const currentTools = new Set(oldPage?.tools ?? []);
    for (const name of removed) {
      currentTools.delete(name);
      const entry = toolIndex.get(name);
      if (entry) {
        entry.patterns.delete(pattern);
        if (entry.patterns.size === 0) toolIndex.delete(name);
      }
    }
    for (const tool of added) {
      currentTools.add(tool.name);
      const entry = toolIndex.get(tool.name);
      if (entry) {
        entry.patterns.add(pattern);
        entry.tool = toManifestTool(tool, pattern);
      } else {
        toolIndex.set(tool.name, {
          tool: toManifestTool(tool, pattern),
          patterns: /* @__PURE__ */ new Set([pattern])
        });
      }
    }
    const toolNames = [...currentTools];
    const hash = hashTools(
      toolNames.map((n) => toolIndex.get(n)?.tool).filter(Boolean).map((t) => ({
        name: t.name,
        description: t.description,
        inputSchema: t.inputSchema
      }))
    );
    const pageToolSet = {
      urlPattern: pattern,
      tools: toolNames,
      lastScanned: now,
      hash
    };
    const pages = {
      ...oldPages,
      [pattern]: pageToolSet
    };
    const deduped = rebuildTools(pages, toolIndex);
    const manifest = {
      origin,
      version: (existing?.manifest.version ?? 0) + 1,
      generatedAt: now,
      pages,
      tools: deduped
    };
    this.manifests.set(origin, { manifest, toolIndex });
    return manifest;
  }
  toMCPJson(origin) {
    const manifest = this.getManifest(origin);
    if (!manifest) return JSON.stringify({ tools: [] });
    const mcpTools = manifest.tools.map((t) => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
      ...t.annotations ? { annotations: t.annotations } : {}
    }));
    return JSON.stringify({
      tools: mcpTools,
      _meta: {
        origin: manifest.origin,
        version: manifest.version,
        generatedAt: manifest.generatedAt,
        pageCount: Object.keys(manifest.pages).length,
        toolCount: manifest.tools.length
      }
    });
  }
  getToolsForUrl(origin, url) {
    const manifest = this.getManifest(origin);
    if (!manifest) return [];
    const pattern = urlToPattern(url);
    const page = manifest.pages[pattern];
    if (!page) return [];
    const toolNames = new Set(page.tools);
    return manifest.tools.filter((t) => toolNames.has(t.name));
  }
};


//# sourceMappingURL=chunk-7CKWZJNS.js.map

/***/ }),

/***/ "../onecrawl/dist/scraping/index.js":
/*!******************************************!*\
  !*** ../onecrawl/dist/scraping/index.js ***!
  \******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SemanticScrapingAdapter: () => (/* reexport safe */ _chunk_7CKWZJNS_js__WEBPACK_IMPORTED_MODULE_0__.SemanticScrapingAdapter),
/* harmony export */   hashTools: () => (/* reexport safe */ _chunk_7CKWZJNS_js__WEBPACK_IMPORTED_MODULE_0__.hashTools),
/* harmony export */   urlToPattern: () => (/* reexport safe */ _chunk_7CKWZJNS_js__WEBPACK_IMPORTED_MODULE_0__.urlToPattern)
/* harmony export */ });
/* harmony import */ var _chunk_7CKWZJNS_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../chunk-7CKWZJNS.js */ "../onecrawl/dist/chunk-7CKWZJNS.js");


//# sourceMappingURL=index.js.map

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/content/index.ts ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tool_registry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tool-registry */ "./src/content/tool-registry.ts");
/* harmony import */ var _message_handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./message-handler */ "./src/content/message-handler.ts");
/* harmony import */ var _spa_detector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./spa-detector */ "./src/content/spa-detector.ts");
/* harmony import */ var _live_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./live-state */ "./src/content/live-state/index.ts");
/* harmony import */ var _adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/indexeddb-tool-cache-adapter */ "./src/adapters/indexeddb-tool-cache-adapter.ts");
/* harmony import */ var _adapters_tool_manifest_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../adapters/tool-manifest-adapter */ "./src/adapters/tool-manifest-adapter.ts");
/* harmony import */ var _adapters_manifest_persistence_adapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../adapters/manifest-persistence-adapter */ "./src/adapters/manifest-persistence-adapter.ts");
/* harmony import */ var _wmcp_server__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./wmcp-server */ "./src/content/wmcp-server.ts");
/**
 * Content script entry — thin orchestrator.
 *
 * Wires together ToolRegistry, message handling, SPA detection,
 * custom page events, and the LiveState polling engine.
 */








// ── Guard against duplicate injection ──
if (window.__wmcp_loaded) {
    console.debug('[WebMCP] Content script already loaded, skipping');
}
else {
    window.__wmcp_loaded = true;
    console.debug('[WebMCP] Content script injected');
    const registry = new _tool_registry__WEBPACK_IMPORTED_MODULE_0__.ToolRegistry();
    registry.setToolCache(new _adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_4__.IndexedDBToolCacheAdapter());
    registry.setToolManifest(new _adapters_tool_manifest_adapter__WEBPACK_IMPORTED_MODULE_5__.ToolManifestAdapter());
    registry.setManifestPersistence(new _adapters_manifest_persistence_adapter__WEBPACK_IMPORTED_MODULE_6__.ManifestPersistenceAdapter());
    // Restore persisted manifest for instant availability
    void registry.loadPersistedManifest();
    // ── WebMCP JSON server via DOM injection ──
    const wmcpServer = new _wmcp_server__WEBPACK_IMPORTED_MODULE_7__.WmcpServer();
    const site = (0,_adapters_indexeddb_tool_cache_adapter__WEBPACK_IMPORTED_MODULE_4__.extractSite)(location.href);
    const manifestAdapter = registry.getToolManifest();
    wmcpServer.onRequest((url) => {
        if (url) {
            const tools = manifestAdapter.getToolsForUrl(site, url);
            return JSON.stringify({ origin: site, url, tools }, null, 2);
        }
        return manifestAdapter.toMCPJson(site);
    });
    registry.onManifestUpdate(() => {
        wmcpServer.exposeManifest(manifestAdapter.toMCPJson(site));
    });
    (0,_message_handler__WEBPACK_IMPORTED_MODULE_1__.createMessageHandler)(registry);
    (0,_spa_detector__WEBPACK_IMPORTED_MODULE_2__.initSpaDetection)(() => {
        registry.invalidateCache();
        registry.listToolsAlwaysAugment();
    });
    // ── LiveState polling ──
    const liveManager = (0,_live_state__WEBPACK_IMPORTED_MODULE_3__.getLiveStateManager)();
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.MediaStateProvider());
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.FormStateProvider());
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.NavigationStateProvider());
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.AuthStateProvider());
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.InteractiveStateProvider());
    liveManager.registerProvider(new _live_state__WEBPACK_IMPORTED_MODULE_3__.VisibilityStateProvider());
    const pollingEngine = new _live_state__WEBPACK_IMPORTED_MODULE_3__.PollingEngine(liveManager, {
        pollingIntervalMs: 1000,
        activePollingIntervalMs: 200,
        enabled: true,
    });
    liveManager.start();
    pollingEngine.start();
    // ── Custom events from the page ──
    window.addEventListener('toolactivated', ((e) => {
        const detail = e.detail;
        console.debug(`[WebMCP] Tool "${detail?.toolName ?? ''}" started execution.`);
    }));
    window.addEventListener('toolcancel', ((e) => {
        const detail = e.detail;
        console.debug(`[WebMCP] Tool "${detail?.toolName ?? ''}" execution is cancelled.`);
    }));
}

})();

/******/ })()
;
//# sourceMappingURL=content.js.map